#!/bin/bash
#
#
# Copyright (C) 2016-2026 Dan Landon
# Licensed under the Unassigned Devices - Next Personal Use License v1.0
# See LICENSE.md for full license terms.
#

#
# Copy config files to ram tmpfs.
#
/usr/bin/rm /tmp/unassigned.devices/config/*.cfg
/usr/bin/cp /boot/config/plugins/unassigned.devices/*.cfg /tmp/unassigned.devices/config/ 2>/dev/null

#
# Clear run status, ping, UD, and udev device stats.
#
/usr/local/emhttp/plugins/unassigned.devices/scripts/get_ud_stats clear_stats
