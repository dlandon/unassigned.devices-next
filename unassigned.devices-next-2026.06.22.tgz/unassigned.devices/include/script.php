<?php
/*
Copyright (C) 2016-2026 Dan Landon
Licensed under the Unassigned Devices - Next Personal Use License v1.0
See LICENSE.md for full license terms.
*/

/* Load the UD library file if it is not already loaded. */
require_once("plugins/unassigned.devices/include/lib.php");

/* Add translations. */
require_once(DOCROOT."/webGui/include/Translations.php");

readfile("logging.htm");

/* Write text to the pop up dialog. */
function write_log($string) {
	if ($string !== false && $string !== "") {
		$string = str_replace("\n", "<br>", $string);
		echo "<script>addLog(".json_encode(trim($string)).");</script>";
		@flush();
	}
}

/* Main entry point. */
if (isset($_GET['device']) && isset($_GET['type'])) {
	$device		= urldecode($_GET['device']);
	$info		= get_partition_info($device, true);
	$command	= execute_script($info, "ADD", true);

	if ($command != "") {
		putenv("OWNER=udev");

		write_log(_("Note").": "._("This window may be closed at any time. The script will continue running in the background. Use Device Settings to abort the script if necessary.")."<br><br>");

		write_log(_("Executing").": ".basename($info['command'])."<br><br>");

		$proc = popen($command." 2>&1", "r");

		if ($proc) {
			while (! feof($proc)) {
				write_log(fgets($proc));
			}

			pclose($proc);
		} else {
			write_log(_("Unable to execute script")."!<br>");
		}
	} else if ($command !== false) {
		write_log(_("No script file to execute")."!<br>");
	} else {
		write_log(_("Script is already running")."!<br>");
	}
}
?>
