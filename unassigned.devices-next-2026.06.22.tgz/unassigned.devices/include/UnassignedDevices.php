<?php
/*
Copyright (C) 2016-2026 Dan Landon
Licensed under the Unassigned Devices - Next Personal Use License v1.0
See LICENSE.md for full license terms.
*/

$_SERVER['REQUEST_URI'] = "unassigneddevices";

/* Load the UD library file if it is not already loaded. */
require_once("plugins/unassigned.devices/include/lib.php");

/* Get the diskio scale based on the current setting. */
function my_diskio($data) {
	return my_scale($data, $unit, 1)." $unit/s";
}

/* Get the used and free space for a partition and render for html. */
function render_used_and_free($partition) {
	$out = "<td></td><td></td>";

	if ($partition['mounted']) {
		$out = render_used_and_free_values(
			(int)($partition['size'] ?? 0),
			(int)($partition['used'] ?? 0),
			(int)($partition['avail'] ?? 0)
		);
	}

	return $out;
}

/* Get the used and free space for a disk and render for html. */
function render_used_and_free_disk($disk, $mounted) {
	$out = "<td></td><td></td>";

	if ($mounted) {
		$size	= 0;
		$avail	= 0;
		$used	= 0;

		foreach (($disk['partitions'] ?? []) as $partition) {
			if ($partition['mounted']) {
				$size	+= (int)($partition['size'] ?? 0);
				$avail	+= (int)($partition['avail'] ?? 0);
				$used	+= (int)($partition['used'] ?? 0);
			}
		}

		$out = render_used_and_free_values($size, $used, $avail);
	}

	return $out;
}

/* Render used and free values as either text or usage bars. */
function render_used_and_free_values($size, $used, $avail) {
	global $display;

	$unit			= "";
	$free_pct		= $size ? max(0, min(100, round(100 * $avail / $size))) : 0;
	$used_pct		= 100 - $free_pct;
	$show_used_text	= (($display['text'] % 10) == 0);
	$show_free_text	= ($display['text'] < 10) ? (($display['text'] % 10) == 0) : (($display['text'] % 10) != 0);

	if ($show_used_text) {
		$out = "<td>".my_scale($used, $unit)." $unit</td>";
	} else {
		$out = "<td><div class='usage-disk'><span style='margin:0;width:$used_pct%' class='".usage_color($display, $used_pct, false)."'></span><span>".my_scale($used, $unit)." $unit</span></div></td>";
	}

	$unit = "";

	if ($show_free_text) {
		$out .= "<td>".my_scale($avail, $unit)." $unit</td>";
	} else {
		$out .= "<td><div class='usage-disk'><span style='margin:0;width:$free_pct%' class='".usage_color($display, $free_pct, true)."'></span><span>".my_scale($avail, $unit)." $unit</span></div></td>";
	}

	return $out;
}

/* Get the partition information and render for html. */
function render_partition($disk, $partition, $disk_line = false) {
	global $paths, $shares_enabled, $format_enabled, $show_diskio, $unraid_7_plus;

	$out = [];
	if ($disk['partitions']) {
		$mounted		= $partition['mounted'];
		$not_unmounted	= $partition['not_unmounted'];
		$not_udev		= $partition['not_udev'];
		$cmd			= $partition['command'];
		$device			= $partition['fstype'] == "crypto_LUKS" ? $partition['luks'] : $partition['device'];
		$is_mounting	= $partition['mounting'];
		$is_unmounting	= $partition['unmounting'];
		$is_formatting	= $partition['formatting'];
		$is_clearing	= $partition['clearing'];
		$disabled		= ($is_mounting || $is_unmounting || $partition['running'] || ! $partition['fstype'] || $disk['array_disk']);
		$disk_device	= basename($disk['device']);

		/* Get the lsblk file system to compare to udev. */
		$crypto_fs_type	= $partition['file_system'];

		/* Set up icons for file system check/scrub and script execution. */
		$fstype = ($partition['fstype'] == "crypto_LUKS") ? $crypto_fs_type : $partition['fstype'];
		if (((! $disabled) && (! $mounted) && ($fstype != "apfs") && ($fstype != "btrfs") && ($fstype != "zfs")) || ((! $disabled) && ($mounted) && ($fstype == "btrfs" || $fstype == "zfs"))) {
			$file_system_check = (($fstype != "btrfs") && ($fstype != "zfs")) ? _('File System Check') : _('File System Scrub');
			$fscheck 	= "<a class='exec ud-tooltip' data-tooltip='".$file_system_check."' onclick='openWindowFsck(\"/plugins/".UNASSIGNED_PLUGIN."/include/fsck.php?device=".urlencode($partition['device'])."&fs=".urlencode($partition['fstype'])."&luks=".urlencode($partition['luks'])."&serial=".urlencode($partition['serial'])."&mountpoint=".urlencode($partition['mountpoint'])."&check_type=ro&type="._('Done')."\",\"Check filesystem\",600,900);'><i class='fa fa-check partition-hdd'></i></a>";
		} else {
			$fscheck 	= "<i class='fa fa-check partition-hdd'></i>";
		}
		$fscheck		.= $partition['part'];

		if ($mounted && is_file($cmd)) {
			if (! $disabled) {
				$fscheck .= "<a class='exec ud-tooltip' data-tooltip='"._("Execute Script as udev simulating a device being installed")."' onclick='openWindowFsck(\"/plugins/".UNASSIGNED_PLUGIN."/include/script.php?device=".urlencode($device)."&type="._('Done')."\",\"Execute Script\",600,900);'><i class='fa fa-flash partition-script'></i></a>";
			} else {
				$fscheck .= "<i class='fa fa-flash partition-script'></i>";
			}
		} else if ($mounted) {
			$fscheck 	.= "<i class='fa fa-flash partition-script'></i>";
		}

		/* Add remove partition icon if destructive mode is enabled and parted is installed. */
		$remove_partition	= (($format_enabled) && (! $is_mounting) && (! $is_unmounting) && (! $is_formatting) && (! $is_clearing) && (! $disk['pass_through']) && (! $disk['partitions'][0]['disable_mount']) && (! $disk['array_disk']) && ($fstype) && ($fstype != "zfs")) ? "<a device='".$partition['device']."' class='exec ud-tooltip' data-tooltip='"._("Remove Partition")."' style='color:#CC0000;' onclick='remove_partition(this,\"".$partition['serial']."\",\"".$disk['device']."\",\"".$partition['part']."\");'><i class='fa fa-remove clear-hdd'></i></a>" : "";
		$mpoint				= "<span>".$fscheck;

		/* Add script log icon. */
		if ($cmd) {
			$mpoint			.= "<a class='ud-tooltip' data-tooltip='"._("View Device Script Log")."' href='/Main/ScriptLog?serial=".$partition['serial']."&partition=".$partition['part']."'><i class='fa fa-align-left partition-log'></i></a>";
		} else {
			$mpoint			.= "<i class='fa fa-align-left partition-log' disabled></i>";
		}

		$mount_point		= basename($partition['mountpoint']);

		/* Add change mount point or browse disk share icon if disk is mounted. */
		if (($not_unmounted) || ($not_udev)) {
			$mpoint			.= $mount_point."</span>";
		} else if (($mounted) && (! $is_mounting) && (! $is_unmounting)) {
			/* If the partition is zfs and has zfs attribute issues, indicate that on the mount point with a tooltip. */
			$zfs_attributes	= "";

			if (($fstype == "zfs") && ($partition['zfs_indicator'])) {
				/* Build tooltip text from ZFS indicator tokens. */
				$tooltip_text = '';

				switch ($partition['zfs_indicator']) {

					case 'ACL_OFF':
						$tooltip_text = _('ZFS ACLs are disabled. SMB permission handling may be limited.');
						break;

					case 'ACL_NFSV4':
						$tooltip_text = _('ZFS dataset uses NFSv4 ACLs. Permission semantics differ from Unraid defaults.');
						break;

					case 'XATTR_OFF':
						$tooltip_text = _('ZFS extended attributes are disabled. Some features may not work as expected.');
						break;

					case 'POOL_LEGACY':
						$tooltip_text = _('ZFS pool uses a legacy feature set.');
						break;

					case 'CASE_MIXED':
						$tooltip_text = _('ZFS dataset uses mixed or insensitive case handling.');
						break;

					case 'ACL_OFF|POOL_LEGACY':
						$tooltip_text = _('ZFS ACLs are disabled and the pool uses a legacy feature set.');
						break;

					case 'ACL_NFSV4|POOL_LEGACY':
						$tooltip_text = _('ZFS dataset uses NFSv4 ACLs and the pool uses a legacy feature set.');
						break;

					default:
						$tooltip_text = _('ZFS attribute configuration may not match Unraid defaults.');
						break;
				}

				if ($partition['zfs_indicator']) {
					$tooltip		= htmlspecialchars($tooltip_text, ENT_QUOTES, 'UTF-8');

					$zfs_attributes = "<span class='ud-tooltip zfs-warning' data-tooltip='{$tooltip}'> (ZFS!)</span>";
				}
			}

			/* If the partition is mounted read only, indicate that on the mount point. */
			$read_only = '';

			/* Disk partition is mounted read only. */
			if ($partition['part_read_only']) {
				/* Read only option switch is set. */
				if ($partition['read_only']) {
					$tooltip	= htmlspecialchars(_('Read Only option is enabled for this disk.'), ENT_QUOTES, 'UTF-8');
				} else {
					$tooltip	= htmlspecialchars(_('Partition is mounted read-only due to filesystem or device state. Check system log.'), ENT_QUOTES, 'UTF-8');
				}
				$read_only	= "<span class='ud-tooltip ud-ro' data-tooltip='{$tooltip}'> (RO)</span>";
			}

			/* Add the icon inside the anchor tag */
			$mpoint			.= "<a class='exec underline-icon ud-tooltip' data-tooltip='"._("Browse Disk Share")."' href='/Main/Browse?dir=".htmlspecialchars($partition['mountpoint'])."'><i class='fa fa-external-link'></i> ".htmlspecialchars($mount_point)."</a>".$read_only.$zfs_attributes;
		} else {
			$mount_point	= basename($partition['mountpoint']);
			$disk_label		= $partition['disk_label'];
			if ((! $disk['array_disk']) && (! $mounted) && (! $is_mounting) && (! $is_unmounting)) {
				$mpoint		.= "<a class='exec underline-icon ud-tooltip' data-tooltip='"._("Change Disk Mount Point")."' onclick='change_mountpoint(\"".$partition['serial']."\",\"".$partition['part']."\",\"".$device."\",\"".$partition['fstype']."\",\"".htmlspecialchars($mount_point)."\",\"".$disk_label."\");'><i class='fa fa-pencil'></i> ".htmlspecialchars($mount_point)."</a>";
			} else {
				$mpoint		.= "<i class='fa fa-pencil partition-hdd'></i>".htmlspecialchars($mount_point);
			}
			$mpoint			.= $remove_partition."</span>";
		}

		/* Make the mount button. */
		$mbutton = make_mount_button($partition);

		/* Show disk partitions if partitions enabled. */
		$style				= ((! $disk['show_partitions']) || ($disk['pass_through'])) ? "style='display:none;'" : "";
		$out[]				= "<tr class='toggle-parts toggle-".$disk_device."' name='toggle-".$disk_device."' $style>";
		$out[]				= "<td></td>";
		$out[]				= "<td>".$mpoint."</td>";
		$out[]				= ((count($disk['partitions']) > 1) && ($mounted)) ? "<td class='mount'>".$mbutton."</td>" : "<td></td>";

		/* Determine the file type of the disk by getting the first partition with a fstype. */
		$fstype	= $partition['fstype'];
		if ($disk_line) {
			foreach ($disk['partitions'] as $part) {
				if ($part['fstype']) {
					$fstype = $part['fstype'];
					break;
				}
			}
		}

		/* Disk read and write totals or rate. */
		if ($disk_line) {
			if ($show_diskio) {
				if ($unraid_7_plus) {
					$out[]		= "<td>".my_number($disk['reads'])."</td>";
					$out[]		= "<td>".my_number($disk['writes'])."</td>";
				} else {
					$out[]		= "<td>".my_diskio($disk['read_rate'])."</td>";
					$out[]		= "<td>".my_diskio($disk['write_rate'])."</td>";
				}
			} else {
				if ($unraid_7_plus) {
					$out[]		= "<td>".my_diskio($disk['read_rate'])."</td>";
					$out[]		= "<td>".my_diskio($disk['write_rate'])."</td>";
				} else {
					$out[]		= "<td>".my_number($disk['reads'])."</td>";
					$out[]		= "<td>".my_number($disk['writes'])."</td>";
				}
			}
		} else {
			$out[]			= "<td></td>";
			$out[]			= "<td></td>";
		}

		/* Set up the device settings and script settings tooltip. */
		$title				= _("Device Settings and Script");
		if ($disk_line) {
			$title			.= "<br>"._("Passed Through").": ";
			$title			.= $partition['pass_through'] ? "Yes" : "No";
			$title			.= "<br>"._("Disable Mount Button").": ";
			$title			.= $partition['disable_mount'] ? "Yes" : "No";
			$title			.= "<br>"._("Read Only").": ";
			$title			.= $partition['read_only'] ? "Yes" : "No";
			$title			.= "<br>"._("Automount").": ";
			$title			.= $disk['automount'] ? "Yes" : "No";
		}
		$title .= "<br>"._("Share").": ";

		$title .= $shares_enabled ? (($partition['shared']) ? "Yes" : "No") : "Not Enabled";
		if ($disk_line) {
			$title			.= "<br>"._("Show Partitions").": ";
			$title			.= $disk['show_partitions'] ? "Yes" : "No";
		} else {
			$title			.= "<br>"._("Script Enabled").": ";
			$title			.= $partition['enable_script'] != "false" ? "Yes" : "No";
		}

		/* Get the mounted, mounting, and unmounting status of all partitions to determine the status of the disk. */
		$mounted_disk		= $mounted;
		$mounting_disk		= $is_mounting;
		$unmounting_disk	= $is_unmounting;
		if ($disk_line) {
			foreach ($disk['partitions'] as $part) {
				if ($part['mounted']) {
					$mounted_disk = true;
				}
				if ($part['mounting']) {
					$mounting_disk = true;
				}
				if ($part['unmounting']) {
					$unmounting_disk = true;
				}
			}
		} else {
			$out[] = "<td></td>";
		}

		$device				= MiscUD::base_device(basename($device)) ;
		$serial				= $partition['serial'];
		$id_bus				= $disk['id_bus'];
		if (! $disk['array_disk']) {
			$out[]			= "<td><a class='ud-tooltip' data-tooltip='".htmlspecialchars($title, ENT_QUOTES, 'UTF-8')."' href='/Main/DeviceSettings?type=".urlencode('disk')."&serial=".urlencode($serial)."&device=".urlencode($device)."&fstype=".urlencode($fstype)."&mountpoint=".urlencode($partition['mountpoint'])."&mounted=".($mounted_disk || $mounting_disk || $unmounting_disk)."&partition=".urlencode($partition['part'])."&info=".json_encode($partition)."&switches=".$disk_line."&id_bus=".urlencode($id_bus)."'><i class='fa fa-gears'></i></a></td>";
		} else {
			$out[]			= "<td><i class='fa fa-gears' disabled></i></td>";
		}

		/* Show disk and partition usage. */
		$luks_lock			= $mounted ? "<i class='fa fa-unlock-alt green-orb fa-encrypted ud-tooltip' data-tooltip='Encrypted and unlocked'></i>" : "<i class='fa fa-lock grey-orb fa-encrypted ud-tooltip' data-tooltip='Encrypted and locked'></i>";
		$out[]				= "<td>".($fstype == "crypto_LUKS" ? $luks_lock.$crypto_fs_type : $fstype)."</td>";
		if ($disk_line) {
			$out[]			= (! $not_unmounted) ? render_used_and_free_disk($disk, $mounted_disk) : "<td></td>";
		} else {
			$out[]			= "<td>".my_scale($partition['size'], $unit)." $unit</td>";
			$out[]			= (! $not_unmounted) ? render_used_and_free($partition) : "<td></td>";
		}

		/* Show any zvol devices. */
		if (! empty($disk['zvol'] ?? [])) {
			foreach ($disk['zvol'] as $k => $z) {
				$show_zvols	= (get_config("Config", "zvols") == "yes");
				if (($show_zvols) || ($z['mounted'])) { 
					$mbutton		= $z['active'] ? make_mount_button($z) : "";
					$fstype			= $z['file_system'];
					$out[]			= "<tr class='toggle-parts toggle-".$disk_device."' name='toggle-".$disk_device."' $style>";
					$out[]			= "<td></td><td>"._("ZFS Volume").":";

					/* Put together the file system check icon. */
					if (((! $z['mounted']) && ($fstype) && ($fstype != "btrfs")) || (($z['mounted']) && ($fstype == "btrfs" || $fstype == "zfs"))) {
						$file_system_check = (($fstype != "btrfs") && ($fstype != "zfs")) ? _('File System Check') : _('File System Scrub');
						$fscheck	= "<a class='exec ud-tooltip' data-tooltip='".$file_system_check."' onclick='openWindowFsck(\"/plugins/".UNASSIGNED_PLUGIN."/include/fsck.php?device=".urlencode($z['device'])."&fs=".urlencode($fstype)."&luks=".urlencode($z['device'])."&serial=".urlencode($z['volume'])."&mountpoint=".urlencode($z['mountpoint'])."&check_type=ro&type="._('Done')."\",\"Check filesystem\",600,900);'><i class='fa fa-check zfs-volume-hdd'></i></a>";
					} else {
						$fscheck	= "<i class='fa fa-check zfs-volume-hdd'></i>";
					}

					if ($z['mounted']) {
						/* If the partition is mounted read only, indicate that on the mount point. */
						$read_only = '';

						if ($z['zfs_read_only']) {
							/* Zvol is mounted read only. */
							if ($z['zfs_read_only']) {
								/* Read only option switch is set. */
								if ($z['read_only']) {
									$tooltip	= htmlspecialchars(_('Read Only option is enabled for this zvol.'), ENT_QUOTES, 'UTF-8');
								} else {
									$tooltip	= htmlspecialchars(_('Partition is mounted read-only due to filesystem or device state. Check system log.'), ENT_QUOTES, 'UTF-8');
								}
								$read_only	= "<span class='ud-tooltip ud-ro' data-tooltip='{$tooltip}'> (RO)</span>";
							}
						}
	
						$out[]		= $fscheck."<a class='exec underline-icon ud-tooltip' data-tooltip='"._("Browse ZFS Volume")."' href='/Main/Browse?dir=".htmlspecialchars($z['mountpoint'])."'><i class='fa fa-external-link'></i> ".basename($z['mountpoint'])."</a>".$read_only;
					} elseif ($z['active']) {
						$out[]		= "<span>".$fscheck.basename($z['mountpoint'])."</span>";
					} else {
						$out[]		= "<span>".basename($z['mountpoint'])."</span>";
					}
					$out[]			= "<td class='mount'>".$mbutton."</td>";
					$out[]			= "<td></td>";
					$out[]			= "<td></td>";
					$out[]			= "<td></td>";

					/* Set up the device settings and script settings tooltip. */
					$title			= _("ZFS Volume Settings");
					$title			.= "<br>"._("Passed Through").": ";
					$title			.= $z['pass_through'] ? "Yes" : "No";
					$title			.= "<br>"._("Disable Mount Button").": ";
					$title			.= $z['disable_mount'] ? "Yes" : "No";
					$title			.= "<br>"._("Read Only").": ";
					$title			.= $z['read_only'] ? "Yes" : "No";

					$device			= basename($z['device']) ;
					$serial			= $disk['serial'];
					$volume			= $k;
					$id_bus			= "";

					if (($z['active']) && ($fstype)) {
						$out[]		= "<td><a class='ud-tooltip' data-tooltip='".htmlspecialchars($title, ENT_QUOTES, 'UTF-8')."' href='/Main/DeviceSettings?type=".urlencode('disk')."&serial=".urlencode($serial)."&fstype=".urlencode($z['fstype'])."&mountpoint=".urlencode($z['mountpoint'])."&mounted=".urlencode($z['mounted'])."&zfs_volume=".urlencode($volume)."&info=".json_encode($z)."&switches=".true."&id_bus=".urlencode($id_bus)."'><i class='fa fa-gears'></i></a></td>";
						$out[]		= "<td>".$fstype."</td>";
						$out[]		= "<td>".my_scale($z['size'], $unit)." $unit</td>";
					} else {
						$out[]		= "<td></td>";
						$out[]		= "<td></td>";
						$out[]		= "<td></td>";
					}
					$out[]			= render_used_and_free($z);
				}
			}
		}

		$out[] = "</tr>";
	}

	return $out;
}

/* Format the mount button based on status of the device. */
function make_mount_button($device) {
	global $paths, $format_enabled;

	/* If the device array has partitions, this is the disk device array. */
	if (isset($device['partitions'])) {
		/* Disk device mount button. */
		$context		= "disk";

		/* A partition on the disk is mounted. */
		$mounted		= $device['mounted'];

		/* The disk was not unmounted before being removed and the reinstalled. */
		$not_unmounted	= $device['not_unmounted'];

		/* A disk partition is mounting. */
		$is_mounting	= $device['mounting'];

		/* A disk partition is unmounting. */
		$is_unmounting	= $device['unmounting'];

		/* Disk is formatting. */
		$is_formatting	= $device['formatting'];

		/* Disk is clearing. */
		$is_clearing	= $device['clearing'];

		/* Disk is preclearing. */
		$preclearing	= $device['preclearing'];

		/* Disk script or user script is running. */
		$is_running		= $device['running'];

		/* Disk is a pool disk. */
		$pool_disk		= $device['pool_disk'];

		/* Udev and lsblk do not agree on the file system type. */
		$not_udev		= $device['not_udev'];

		/* Disable mount button enabled. */
		$disable_mount	= $device['disable_mount'];

		/* Is this device enabled with valid partitions. */
		$disable_device	= $device['disable'];

		/* Disk can be formatted if there are no partitions. */
		$pass_through	= $device['pass_through'];
		$format			= ((! count($device['partitions'])) && (! $pass_through));

		/* This is not an unformatted zvol partition. */
		$empty_zvol		= false;

		/* A pool disk can be part of a disk pool or a disk with a file system and no partition. */
		$no_partition	= ($device['fstype'] && $format);
	} else {
		/* Partition mount button. */
		$context		= "partition";

		/* The partition is mounted. */
		$mounted		= $device['mounted'];

		/* Mount button is disabled if there is no file system present. */
		$disable_device	= (! $device['fstype']);

		/* Find conditions to disable the 'Mount' button. */
		$disable_mount	= $device['disable_mount'];

		/* Is the disk not unmounted properly? */
		$not_unmounted = $device['not_unmounted'];

		/* Is the disk file system not matching udev file system? */
		$not_udev		= $device['not_udev'];

		/* Check the state of mounting, unmounting, and running. */
		$is_mounting	= $device['mounting'];
		$is_unmounting	= $device['unmounting'];
		$is_running		= $device['running'];

		/* Is this a zvol partition with no file system? */
		$empty_zvol		= (($device['size'] == 0) && (empty($device['file_system'])));

		/* The partition is set as passed through. */
		$pass_through	= $device['pass_through'];

		/* Things not related to a partition. */
		$is_formatting	= false;
		$is_clearing	= false;
		$preclearing	= false;
		$format			= false;
		$pool_disk		= false;
		$no_partition	= false;
	}

	/* Set up the mount button operation and text. */
	$buttonFormat = "<button device=".htmlspecialchars($device['device'], ENT_QUOTES, 'UTF-8')." class='mount' context='%s' data-action='%s' %s><i class='%s'></i>%s</button>";

	/* Initialize variables. */
	$action				= "";
	$text				= "";
	$class				= "";
	$spinner_class		= "fa fa-spinner fa-spin orb";
	$ban_class			= "fa fa-ban orb";
	$disable			= true;

	switch (true) {
		case ($pass_through):
			$class		= $ban_class;
			$text		= _('Passed');
			break;

		case ($no_partition):
			$class		= $ban_class;
			$text		= _('Partition');
			break;

		case ($pool_disk):
			$text		= _('Pool');
			break;

		case ($empty_zvol):
			$text		= _('Mount');
			break;

		case ($device['array_disk']):
			$class		= $ban_class;
			$text		= _('Array');
			break;

		case (! $device['ud_device']):
			$class		= $ban_class;
			$text		= _('UD Device');
			break;

		case ($not_udev):
			$class		= $ban_class;
			$text		= _('Udev');
			break;

		case ($not_unmounted):
			$class		= $ban_class;
			$text		= _('Reboot');
			break;

		case ($preclearing):
			$text		= _('Preclear');
			break;

		case ($is_formatting):
			$class		= $spinner_class;
			$text		= _('Formatting');
			break;

		case ($is_clearing):
			$class		= $spinner_class;
			$text		= _('Clearing');
			break;

		case ($is_mounting):
			$class		= $spinner_class;
			$text		= _('Mounting');
			break;

		case ($is_unmounting):
			$class		= $spinner_class;
			$text		= _('Unmounting');
			break;

		case ($format):
			$disable 	= ! $format_enabled;
			$class		= $disable ? $ban_class : "";
			$action		= 'format';
			$text		= _('Format');
			break;

		case ($mounted):
			if ($is_running) {
				$class		= $spinner_class;
				$text		= _('Running');
			} else {
				$class		= $disable_mount ? $ban_class : "";
				$action		= 'umount';
				$disable 	= $disable_mount ? true : $disable_device;
				$text		= _('Unmount');
			}
			break;

		default:
			$class		= $disable_mount ? $ban_class : "";
			$action		= 'mount';
			$disable 	= $disable_mount ? true : $disable_device;
			$text 		= _('Mount');
			break;
	}

	/* Build the mount button. */
	$button = sprintf($buttonFormat, $context, $action, ($disable ? "disabled" : ""), $class, $text);

	return $button;
}

switch ($_POST['action']) {
	case 'get_ud_content':
		/* Update the UD webpage content. */
		static $disk_names_cache  = null;
		static $disk_names_mtime  = 0;

		static $share_names_cache  = null;
		static $share_names_mtime  = 0;

		/* Start time for disk ops. Used for debugging. */
		$time		= -microtime(true); 

		unassigned_log("Debug: Begin - Refreshing content...", $UPDATE_DEBUG);

		/* Apply any hotplug event. */
		run_hotplug_apply_if_needed();

		/* Get all updated unassigned disks and update devX designations for newly found unassigned devices. */
		$all_disks = get_all_disks_info();
		foreach ($all_disks as $disk) {
			/* This is the device label and is either a 'devX' designation or a disk alias. */
			$unassigned_dev	= $disk['unassigned_dev'] ?? "";

			/* If the unassigned_dev value is not set or is 'dev' or 'sd', and not equal to ud_dev value the then assign it the 'devX' value. */
			if (((! $unassigned_dev) || (is_sd_device($unassigned_dev))) || ((is_dev_device($unassigned_dev)) && ($unassigned_dev != $disk['ud_dev']))) {
				set_config($disk['serial'], "unassigned_dev", $disk['ud_dev']);
			}
		}

		/* Create empty array of share names for duplicate share checking. */
		$share_names	= [];
		$disk_uuid		= [];

		/* Create array of disk names. */
		$disk_names		= [];

		/* Disk devices. */
		$o_disks		= "";

		/* Are any disks preclearing? */
		$preclear_active	= false;

		unassigned_log("Debug: Update disk devices...", $UPDATE_DEBUG);

		/* Get updated disks info. */
		if ( count($all_disks) ) {
			foreach ($all_disks as $disk) {
				/* Only get disk parameters if they are defined. */
				if ($disk) {
					$disk_device		= basename($disk['device']);
					$disk_dev			= $disk['ud_dev'];
					$disk_name			= $disk['unassigned_dev'] ?: $disk['ud_dev'];
					$preclearing		= $disk['preclearing'];
					$temp				= my_temp($disk['temperature']);

					/* Refresh page if preclear is active on any disk. */
					if ($preclearing) {
						$preclear_active	= true;
					}

					/* Get partitions. */
					$rendered_partitions = [];
					$parts = false;

					if ((! $disk['clearing']) && ($disk['partitions']) && ($disk['file_system'])) {
						foreach ($disk['partitions'] as $partition) {
							$rendered_partitions[] = render_partition($disk, $partition);
						}

						$parts = render_partition($disk, $disk['partitions'][0], true);
					}

					/* See if any partitions are mounted. */
					$mounted			= $disk['mounted'];

					/* Was the disk unmounted properly? */
					$not_unmounted		= $disk['not_unmounted'];

					/* See if any partitions have a file system. */
					$file_system		= $disk['file_system'];

					/* Create the mount button. */
					$mbutton			= make_mount_button($disk);

					/* Does this disk have a file system that UD recognizes? */
					$has_filesys		= (($disk['file_system']) || ($disk['partitions'] && (! $disk['file_system'])));

					/* Set up the preclear link for preclearing a disk. */
					$preclear_link		= (($Preclear) && ($disk['size'] !== 0) && (! $parts) && (! $mounted) && (! $disk['formatting']) && (! $disk['clearing']) && (! $preclearing) && (! $disk['array_disk']) && (! $disk['pass_through']) && (! $has_filesys)) ? "<span class='clear-preclear'>".$Preclear->Link($disk_device, "icon")."</scan>" : "";

					/* Add the clear disk icon if destructive mode is enabled and parted is installed. */
					$first_part				= $disk['partitions'][0] ?? [];
					$first_part_pool		= $first_part['pool'] ?? false;
					$first_part_disable_mnt	= $first_part['disable_mount'] ?? true;
					$clear_disk 			= (($format_enabled) && (! $mounted) && (! $disk['mounting']) && (! $disk['unmounting']) && (! $disk['formatting']) && (! $disk['clearing']) && (! $disk['pass_through']) && (! $disk['array_disk']) && (! $preclearing) && ($has_filesys) && (! $first_part_pool) && (! $first_part_disable_mnt)) ? "<a device='".$disk['device']."' class='exec ud-tooltip' data-tooltip='"._("Clear Disk")."' style='color:#CC0000;' onclick='clear_disk(this,\"".$disk['serial']."\",\"".$disk['device']."\");'><i class='fa fa-remove clear-hdd'></i></a>" : "";

					/* Show disk icon based on SSD or spinner disk. */
					$disk_icon = $disk['ssd'] ? "icon-nvme" : "fa fa-hdd-o";

					/* Disk log. */
					$hdd_serial = "<a class='ud-tooltip' data-tooltip='"._("Disk Log Information")."' onclick=\"openTerminal('disklog', '".$disk_device."')\"><i class='".$disk_icon." icon partition-log'></i></a>";
					if ($parts) {
						$add_toggle = true;
						if ($disk['pass_through']) {
							$hdd_serial		.="<span><i class='fa fa-plus-square fa-append grey-orb orb'></i></span>";
						} else if (! $disk['show_partitions']) {
							$hdd_serial		.="<span title ='"._("Click to view/hide partitions and mount points")."'class='exec toggle-hdd' hdd='".$disk_device."'><i class='fa fa-plus-square fa-append'></i></span>";
						} else {
							$hdd_serial		.="<span><i class='fa fa-minus-square fa-append grey-orb orb'></i></span>";
						}
					} else {
						$add_toggle			= false;
						$hdd_serial			.= "<span class='toggle-hdd' hdd='".$disk_device."'></span>";
					}

					$device		= $disk['ud_device'] ? " (".$disk_device.")" : "";
					$hdd_serial .= $disk['serial'].$device.$clear_disk.$preclear_link."<span id='preclear_".$disk['serial_short']."' style='display:block;'></span>";

					$o_disks .= "<tr class='toggle-disk'>";
					if (! $disk['ud_unassigned_dev']) {
						if (! $disk['array_disk']) {
							$disk_display = $disk_name;
						} else {
							$disk_display = $disk['ud_dev'];
						}
					} else {
						$disk_display = substr($disk_name, 0, 3)." ".substr($disk_name, 3);
						$disk_display = my_disk($disk_display);
					}

					/* Device table element. */
					$o_disks .= "<td>";
					if (! $disk['ud_device']) {
						$str		= "New?name";
						$o_disks	.= "<i class='fa fa-circle ".($disk['running'] ? "green-orb" : "grey-orb" )." orb'></i>";
					} else {
						$str		= "Device?name";
						$orb		= (($disk['spinning']) ? "green-orb" : "grey-orb")." orb";
						if (! $preclearing) {
							if (! is_disk_spin($disk['ud_dev'], $disk['spinning'])) {
								if ($disk['spinning']) {
									$spin		= "spinDownDisk";
									$tool_tip	= _("Click to spin down device");
								} else {
									$spin		= "spinUpDisk";
									$tool_tip	= _("Click to spin up device");
								}
								$o_disks		.= "<a class='exec ud-tooltip' data-tooltip='".$tool_tip."' onclick='".$spin."(\"".$disk_dev."\")'><i id='disk_orb-".$disk_dev."' class='fa fa-circle ".$orb."'></i></a>";
							} else {
								$o_disks		.= "<i class='fa fa-refresh fa-spin ".$orb."'></i>";
							}
						} else {
							$o_disks			.= "<i class='fa fa-circle ".$orb."'></i>";
						}
					}
					$o_disks		.= "<a href='/Main/".$str."=".$disk_dev."'>".$disk_display."</a>";
					$o_disks		.= "</td>";

					/* Device serial number. */
					$o_disks		.= "<td>".$hdd_serial."</td>";

					/* Mount button. */
					$o_disks		.= "<td class='mount'>".$mbutton."</td>";


					/* Disk temperature. */
					$o_disks		.= "<td>".$temp."</td>";

					if (! $parts) {
						$rw = get_disk_reads_writes($disk['ud_dev'], $disk['device']);
						if ($show_diskio) {
							$reads	= my_number($rw[0]);
							$writes	= my_number($rw[1]);
						} else {
							$reads	= my_diskio($rw[2]);
							$writes	= my_diskio($rw[3]);
						}
					}

					/* Reads. */
					$o_disks		.= ($parts) ? $parts[4] : "<td>".$reads."</td>";

					/* Writes. */
					$o_disks		.= ($parts) ? $parts[5] : "<td>".$writes."</td>";

					/* Settings. */
					$o_disks		.= ($parts) ? $parts[6] : "<td></td>";

					/* File system. */
					$o_disks		.= ($parts) ? $parts[7] : "<td>".$disk['fstype']."</td>";

					/* Disk size. */
					$o_disks		.= "<td>".my_scale($disk['size'], $unit)." ".$unit."</td>";

					/* Disk used and free space. */
					$o_disks		.= (($parts) && (! $not_unmounted)) ? $parts[8] : "<td></td><td></td>";

					$o_disks		.= "</tr>";

					if ($add_toggle)
					{
						$o_disks	.= "<tr>";
						foreach ($rendered_partitions as $rendered_partition) {
							foreach ($rendered_partition as $l) {
								$o_disks .= $l;
							}
						}
						$o_disks	.= "</tr>";
					}
					
					if ((! $disk['formatting']) && (! $disk['clearing'])) {
						$partition_count = count($disk['partitions']);

						for ($i = 0; $i < $partition_count; $i++) {
							if (($disk['unassigned_dev']) && (! in_array($disk['unassigned_dev'], $disk_names, true))) {
								$disk_names[$disk_device] = $disk['unassigned_dev'];
							}

							if ($disk['partitions'][$i]['fstype']) {
								$dev		= ($disk['partitions'][$i]['fstype'] == "crypto_LUKS") ? $disk['partitions'][$i]['luks'] : $disk['partitions'][$i]['device'];

								/* Check if this disk uuid has already been entered in the share_names array. */
								$mountpoint	= basename($disk['partitions'][$i]['mountpoint']);
								$uuid		= $disk['partitions'][$i]['uuid'];

								if (($uuid) && (isset($disk_uuid[$uuid]))) {
									$disk_uuid[$uuid] = $disk_uuid[$uuid].",".$dev;
								} else if ($uuid) {
									$disk_uuid[$uuid] = $dev;
								}

								/* Determine the value to assign to the share name. */
								$value = $disk_uuid[$uuid] ?? $dev;

								/* Add this device/mountpoint to the duplicate share name check. */
								if (($mountpoint) && (is_string($value) || is_int($value))) {
									$share_names[$value] = $mountpoint;
								}
							}
						}
					}
				}
			}
		} else {
			$o_disks .= "<tr><td colspan='11' style='text-align:center;'>"._('No Unassigned Disks available').".</td></tr>";
		}

		$time		+= microtime(true);
		unassigned_log("Debug: Update Disks took ".sprintf('%f', $time)."s!", $UPDATE_DEBUG);

		unassigned_log("Debug: Update Remote Mounts...", $UPDATE_DEBUG);

		/* SAMBA Mounts. */
		$o_remotes = "";

		/* Start time for remote shares ops. */
		$time = -microtime(true);

		/* Get all the samba mounts. */
		$samba_mounts = get_samba_mounts();
		if (! empty($samba_mounts)) {
			foreach ($samba_mounts as $mount)
			{
				$is_alive		= $mount['alive'];
				$is_available	= $mount['available'];
				$mounted		= $mount['mounted'];

				$device_attr	= htmlspecialchars($mount['device'], ENT_QUOTES, 'UTF-8');
				$name_html		= htmlspecialchars($mount['name'], ENT_QUOTES, 'UTF-8');
				$name_js		= htmlspecialchars($mount['name'], ENT_QUOTES, 'UTF-8');

				/* Is the device mounting or unmounting. */
				$is_mounting	= $mount['mounting'];
				$is_unmounting	= $mount['unmounting'];

				/* Disk script or user script is running. */
				$is_running		= $mount['running'];

				/* Populate the table row for this device. */
				$o_remotes		.= "<tr>";

				/* What type of mount is this? */
				$protocol		= $mount['protocol'];

				/* Orb and Protocol table element. */
				$o_remotes		.= sprintf( "<td><a class='ud-tooltip' data-tooltip='"._("Remote Share is")." %s'><i class='fa fa-circle %s orb'></i></a>%s</td>", ( $is_alive ? _("online") : _("offline") ), ( $is_alive ? "green-orb" : "grey-orb" ), $protocol);

				/* Source table element. */
				$o_remotes		.= "<td>".$name_html."</td>";
				$mount_point	= (! $mount['invalid']) ? basename($mount['mountpoint']) : "-- "._("Invalid Configuration - Remove and Re-add")." --";

				/* Mount point table element. */
				$o_remotes		.= "<td>";

				/* Add the view log icon. */
				if ($mount['command']) {
					$o_remotes	.= "<a class='ud-tooltip' data-tooltip='"._("View SMB Script Log")."/"._("View NFS Script Log")."' href='/Main/ScriptLog?samba=".$device_attr."'><i class='fa fa-align-left samba-log'></i></a>";
				} else {
					$o_remotes	.= "<i class='fa fa-align-left samba-log'></i>";
				}

				if (($mounted) && ($is_alive) && ($is_available) && (! $is_mounting) && (! $is_unmounting)) {
					/* If the remote is mounted read only, indicate that on the mount point. */
					$read_only = '';

					/* Disk partition is mounted read only. */
					if ($mount['remote_read_only']) {
						/* Read only option switch is set. */
						if ($mount['read_only']) {
							$tooltip	= htmlspecialchars(_('Read Only option is enabled for this Remote Share.'), ENT_QUOTES, 'UTF-8');
						} else {
							$tooltip	= htmlspecialchars(_('Remote Share is mounted read-only due to filesystem or device state. Check system log.'), ENT_QUOTES, 'UTF-8');
						}
						$read_only	= "<span class='ud-tooltip ud-ro' data-tooltip='{$tooltip}'> (RO)</span>";
					}

					$o_remotes	.= "<a class='exec underline-icon ud-tooltip' data-tooltip='"._("Browse Remote SMB")."/"._("NFS Share")."' href='/Main/Browse?dir=".htmlspecialchars($mount['mountpoint'])."'><i class='fa fa-external-link'></i> ".htmlspecialchars($mount_point)."</a>".$read_only;
				} else if (($is_alive) && ($is_available) && (! $is_mounting) && (! $is_unmounting) && (! $mount['invalid'])) {
					$o_remotes	.= "<a class='exec underline-icon ud-tooltip' data-tooltip='"._("Change Remote SMB")."/"._("NFS Mount Point")."' class='exec' onclick='change_samba_mountpoint(\"".$name_js."\",\"".htmlspecialchars($mount_point)."\");'><i class='fa fa-pencil'></i> ".htmlspecialchars($mount_point)."</a>";
				} else {
					$o_remotes	.= $mount_point;
				}
				$o_remotes		.= "</td>";

				/* Mount button table element. */
				/* Make the mount button. */
				$disable		= (($mount['fstype'] == "root") && (($var['shareDisk'] == "yes") || ($var['shareUserExclusive'] == "yes") || ($var['mdState'] != "STARTED")));
				$disable		= $disable || ((! $is_alive) && (! $mounted));
				$disable		= $disable || $mount['invalid'];
				if ($mount['disable_mount']) {
					$disable_mount	= true;
					$disable		= true;
				} else {
					$disable_mount	= false;
				}
				
				/* Set up the mount button action and text. */
				$buttonFormat	= "<td><button class='mount' device='".$device_attr."' onclick=\"diskOperation(this, '%s', '".$device_attr."');\" %s><i class='%s'></i>%s</button></td>";

				/* Initilize variables. */
				$action			= "";
				$text			= "";
				$class			= "";
				$spinner_class	= "fa fa-spinner fa-spin orb";
				$ban_class		= "fa fa-ban orb";

				switch (true) {
					case ($is_mounting):
						$disable_mount	= true;
						$class			= $spinner_class;
						$text			= _('Mounting');
						break;

					case ($is_unmounting):
						$disable_mount	= true;
						$class			= $spinner_class;
						$text			= _('Unmounting');
						break;

					default:
						if ($mounted) {
							if ($is_running) {
								$disable_mount	= true;
								$class		= $spinner_class;
								$text		= _('Running');
							} else {
								$action		= "umount";
								$class		= $disable_mount ? $ban_class : "";
								$text		= _('Unmount');
							}
						} else {
							$action	= "mount";
							$class		= $disable_mount ? $ban_class : "";
							$text		= _('Mount');
						}
						break;
				}

				/* Build the mount button. */
				$button = sprintf($buttonFormat, $action, ($disable || $disable_mount ? "disabled" : ""), $class, $text);

				$o_remotes			.= $button;

				$display_name		= $mount['name'];

				/* Remove SMB/NFS remote share table element. */
				$o_remotes			.= "<td>";
				$o_remotes			.= ($mounted || $is_mounting || $is_unmounting) ? "<i class='fa fa-remove'></i>" : "<a class='exec ud-tooltip' data-tooltip='"._("Remove Remote SMB")."/"._("NFS Share")."' style='color:#CC0000;' onclick='remove_samba_config(\"".$device_attr."\", \"".$display_name."\", \"".$protocol."\");'><i class='fa fa-remove'></i></a>";
				$o_remotes			.= "</td>";

				/* Empty table element. */
				$o_remotes			.= "<td></td>";

				$title 				= _("Remote SMB")."/"._("NFS Settings and Script");
				$title 				.= "<br>"._("Disable Mount Button").": ";
				$title 				.= ($mount['disable_mount']) ? "Yes" : "No";
				$title 				.= "<br>"._("Read Only").": ";

				/* Root share is always mounted read only. */
				if ($mount['fstype'] == "root") {
					$title			.= "Yes";
				} else {
					$title 			.= $mount['read_only'] ? "Yes" : "No";
				}
				$title 				.= "<br>"._("Automount").": ";
				$title 				.= $mount['automount'] ? "Yes" : "No";
				$title 				.= "<br>"._("Share").": ";
				$title 				.= $shares_enabled ? (($mount['smb_share']) ? "Yes" : "No") : "Not Enabled";
				$title				.= "<br>"._("Script Enabled").": ";
				$title				.= $mount['enable_script'] != "false" ? "Yes" : "No";

				/* Settings icon table element. */
				$o_remotes			.= "<td>";
				if (! $mount['invalid']) {
				$o_remotes			.= "<a class='ud-tooltip' data-tooltip='".htmlspecialchars($title, ENT_QUOTES, 'UTF-8')."' href='/Main/DeviceSettings?type=".urlencode('samba')."&device=".urlencode($mount['device'])."&mountpoint=".urlencode($mount['mountpoint'])."&mounted=".($mounted || $is_mounting || $is_unmounting)."&source=".urlencode($mount['name'])."&fstype=".urlencode($mount['fstype'])."&info=".json_encode($mount)."'><i class='fa fa-gears'></i></a>";
				} else {
					$o_remotes		.= "<i class='fa fa-gears disabled'></i>";
				}
				$o_remotes			.= "</td>";

				/* Empty table element. */
				$o_remotes			.= "<td></td>";

				/* Size, used, and free table elements. */
				$o_remotes			.= "<td>".my_scale($mount['size'], $unit)." $unit</td>";
				$o_remotes			.= render_used_and_free($mount);

				/* End of table row, */
				$o_remotes			.= "</tr>";

				/* Add to the share names. */
				$share_names[$mount['name']] = $mount_point;
			}
		}

		$time		+= microtime(true);
		unassigned_log("Debug: Upadte Remote Mounts took ".sprintf('%f', $time)."s!", $UPDATE_DEBUG);

		unassigned_log("Debug: Update ISO mounts...", $UPDATE_DEBUG);

		/* ISO file Mounts. */

		/* Start time for ISO file ops. */
		$time = -microtime(true);

		$iso_mounts = get_iso_mounts();
		if (! empty($iso_mounts)) {
			foreach ($iso_mounts as $mount) {
				$device			= $mount['device'];
				$mounted		= $mount['mounted'];
				$device_attr	= htmlspecialchars($mount['device'], ENT_QUOTES, 'UTF-8');
				$mountpt_html	= htmlspecialchars($mount['mountpoint'], ENT_QUOTES, 'UTF-8');

				/* Is the device mounting or unmounting. */
				$is_mounting	= $mount['mounting'];
				$is_unmounting	= $mount['unmounting'];
				$is_running		= $mount['running'];

				/* Is the iso file online. */
				$is_alive		= $mount['alive'];

				/* Populate the iso line for this device. */
				$o_remotes		.= "<tr>";

				/* Device table element. */
				$o_remotes		.= sprintf( "<td><a class='ud-tooltip' data-tooltip='"._("ISO File is")." %s'><i class='fa fa-circle %s orb'></i></a>ISO</td>", ( $is_alive ? _("online") : _("offline") ), ( $is_alive ? "green-orb" : "grey-orb" ));
				$o_remotes		.= "<td>".$device_attr."</td>";
				
				/* Mount point table element. */
				$o_remotes			.= "<td>";

				$mount_point	= (! $mount['invalid']) ? basename($mount['mountpoint']) : "-- "._("Invalid Configuration - Remove and Re-add")." --";
				if ($mount['command']) {
					$o_remotes .= "<a class='ud-tooltip' data-tooltip='"._("View ISO File Script Log")."' href='/Main/ScriptLog?iso=".$device_attr."'><i class='fa fa-align-left samba-log'></i></a>";
				} else {
					$o_remotes .= "<i class='fa fa-align-left samba-log' disabled></i>";
				}

				if ((! $is_mounting) && (! $is_unmounting) && ($mounted)) {
					$o_remotes .= "<a class='exec underline-icon ud-tooltip' data-tooltip='"._("Browse ISO File Share")."' href='/Main/Browse?dir=".$mountpt_html."'><i class='fa fa-external-link'></i> ".htmlspecialchars($mount_point)."</a>";
				} else {
					if ((! $is_mounting) && (! $is_unmounting)) {
						$o_remotes	.= "<a class='exec underline-icon ud-tooltip' data-tooltip='"._("Change ISO File Mount Point")."' onclick='change_iso_mountpoint(\"".$device_attr."\",\"".htmlspecialchars($mount_point)."\");'><i class='fa fa-pencil'></i> ".htmlspecialchars($mount_point)."</a>";
					} else {
						$o_remotes	.= $mount_point;
					}
				}
				$o_remotes			.= "</td>";

				/* Remove ISO mount table element. */
				$disable		= (! $is_alive);

				/* Set up the mount button action and text. */
				$buttonFormat	= "<td><button class='mount' device='".$device_attr."' onclick=\"diskOperation(this, '%s', '".$device_attr."');\" %s><i class='%s'></i>%s</button></td>";

				/* Initilize variables. */
				$action			= "";
				$text			= "";
				$class			= "";
				$spinner_class	= "fa fa-spinner fa-spin orb";

				switch (true) {
					case ($is_running):
						$disable	= true;
						$class		= $spinner_class;
						$text		= _('Running');
						break;

					case ($is_mounting):
						$disable	= true;
						$class		= $spinner_class;
						$text		= _('Mounting');
						break;

					case ($is_unmounting):
						$disable	= true;
						$class		= $spinner_class;
						$text		= _('Unmounting');
						break;

					default:
						if ($mounted) {
							$action		= "umount";
							$class		= "umount";
							$text		= _('Unmount');
						} else {
							$action		= "mount";
							$class		= "mount";
							$text		= _('Mount');
						}
						break;
				}

				/* Build the mount button. */
				$button = sprintf($buttonFormat, $action, ($disable ? "disabled" : ""), $class, $text);

				$o_remotes			.= $button;

				$display_device		= $mount['device'];
				$o_remotes 			.= ($mounted || $is_mounting || $is_unmounting || $is_running) ? "<td><i class='fa fa-remove'></i></td>" : "<td><a class='exec ud-tooltip' data-tooltip='"._("Remove ISO File Share")."' style='color:#CC0000;' onclick='remove_iso_config(\"".$device_attr."\", \"".$display_device."\");'> <i class='fa fa-remove'></i></a></td>";

				$title				= _("ISO File Settings and Script");
				$title				.= "<br>"._("Automount").": ";
				$title				.= $mount['automount'] ? "Yes" : "No";
				$title				.= "<br>"._("Share").": Yes";
				$title				.= "<br>"._("Script Enabled").": ";
				$title				.= $mount['enable_script'] != "false" ? "Yes" : "No";

				/* Empty table element. */
				$o_remotes			.= "<td></td>";

				/* Device settings table element. */
				$o_remotes			.= "<td>";
				if (! $mount['invalid']) {
					$o_remotes		.= "<a class='ud-tooltip' data-tooltip='".htmlspecialchars($title, ENT_QUOTES, 'UTF-8')."' href='/Main/DeviceSettings?type=".urlencode('iso')."&device=".urlencode($device)."&mountpoint=".urlencode($mount['mountpoint'])."&mounted=".($mounted || $is_mounting || $is_unmounting)."&source=".urlencode($mount['file'])."'><i class='fa fa-gears'></i></a>";
				} else {
					$o_remotes		.= "<i class='fa fa-gears' disabled></i>";
				}
				$o_remotes			.= "</td>";

				/* Empty table element. */
				$o_remotes			.= "<td></td>";

				/* Size, used, and free table elements. */
				$o_remotes			.= "<td>".my_scale($mount['size'], $unit)." $unit</td>";
				$o_remotes			.= render_used_and_free($mount);

				/* End of table row. */
				$o_remotes			.= "</tr>";

				/* Add to the share names. */
				$share_names[$mount['device']] = $mount_point;
			}
		}

		/* If there are no remote or ISO mounts, show message. */
		if (! count($samba_mounts) && ! count($iso_mounts)) {
			$o_remotes .= "<tr><td colspan='11' style='text-align:center;'>"._('No Remote SMB')."/"._('NFS or ISO File Shares configured').".</td></tr>";
		}

		$time		+= microtime(true);
		unassigned_log("Debug: Update ISO Files took ".sprintf('%f', $time)."s!", $UPDATE_DEBUG);

		unassigned_log("Debug: Update Historical Devices...", $UPDATE_DEBUG);

		/* Historical devices. */
		/* Start time for Historical Devices ops. */
		$time = -microtime(true);

		$o_historical = "";

		/* Get the UD configuration. */
		$config			= $ud_config;

		ksort($config, SORT_NATURAL | SORT_FLAG_CASE);
		$disks_serials	= [];
		foreach ($all_disks as $disk) {
			if ($disk) {
				$disks_serials[] = $disk['serial'];
			}
		}

		/* Organize the historical devices. */
		$historical = [];
		foreach ($config as $serial => $value) {
			if ($serial != "Config") {
				if (! preg_grep("#".$serial."#", $disks_serials)){
					if (($config[$serial]['unassigned_dev'] ?? "") && (! in_array($config[$serial]['unassigned_dev'], $disk_names))) {
						$disk_names[$serial] = $config[$serial]['unassigned_dev'];
					}
					$mountpoint		= basename($config[$serial]['mountpoint.1'] ?? "");
					$mntpoint		= $mountpoint ? " (".$mountpoint.")" : "";
					$disk_dev		= $config[$serial]['unassigned_dev'] ?? "";
					$disk_dev		= $disk_dev ? $disk_dev : _("none");

					/* Create a unique disk_display string to be sure each device is unique. */
					$disk_display	= $disk_dev."_".$serial;

					/* Save this devices info. */
					$historical[$disk_display]['serial']		= $serial;
					$historical[$disk_display]['device']		= $disk_dev;
					$historical[$disk_display]['mntpoint']		= $mntpoint;
					$historical[$disk_display]['mountpoint']	= $mountpoint;
				}
			}
		}
		ksort($historical, SORT_NATURAL | SORT_FLAG_CASE);

		/* Display the historical devices. */
		foreach ($historical as $disk_display => $value) {
			/* See if the disk is in standby and can be attached. */
			$serial			= $historical[$disk_display]['serial'];
			$is_standby		= (MiscUD::get_device_host($serial) && (! ud_serial_exists($serial)));
	
			/* Add to the historical devices. */
			/* Start of table row for this device. */
			$o_historical	.= "<tr>";

			$o_historical	.= sprintf( "<td><a class='ud-tooltip' data-tooltip='"._("Historical Device is")." %s'><i class='fa fa-minus-circle %s orb'></i></a>".$historical[$disk_display]['device']."</td>", ( $is_standby ? _("in standby") : _("offline") ), ( $is_standby ? "green-orb" : "grey-orb" ));

			$o_historical	.= "<td>";
			$o_historical	.= $historical[$disk_display]['serial'].$historical[$disk_display]['mntpoint'];
			$o_historical	.= "<td>";

			/* Empty table element. */
			$o_historical	.= "<td></td>";

			/* Remove device table element. */
			$o_historical	.= "<td>";
			if (! $is_standby) {
				$display_serial	= $historical[$disk_display]['serial'];
				$o_historical .= "<a style='color:#CC0000;' class='exec ud-tooltip' data-tooltip='"._("Remove Device Configuration")."' onclick='remove_disk_config(\"".$historical[$disk_display]['serial']."\", \"".$display_serial."\")'><i class='fa fa-remove' disabled></i></a>";
			} else {
				$o_historical .= "<i class='fa fa-remove' disabled></i>";
			}
			$o_historical	.= "</td>";

			/* Device settings table element. */
			$o_historical	.= "<td>";
			$o_historical	.= "<a class='ud-tooltip' data-tooltip='".htmlspecialchars(_("Historical Device Settings and Script"), ENT_QUOTES, 'UTF-8')."' href='/Main/DeviceSettings?type=".urlencode('disk')."&serial=".urlencode($historical[$disk_display]['serial'])."&mountpoint=".urlencode($historical[$disk_display]['mountpoint'])."&partition=1"."&switches=".true."'><i class='fa fa-gears'></i></a>";
			$o_historical	.= "</td>";


			/* Empty table elements. */
			$o_historical .= "<td></td><td></td><td></td><td></td><td></td>";

			/* End of table row for this device. */
			$o_historical	.= "</tr>";
		}

		$time		+= microtime(true);
		unassigned_log("Debug: Update Historical Devices took ".sprintf('%f', $time)."s!", $UPDATE_DEBUG);

		unassigned_log("Debug: End", $UPDATE_DEBUG);

		/* Save the current disk names for a duplicate check. */
		$mtime = is_file($paths['disk_names']) ? filemtime($paths['disk_names']) : 0;

		if ($disk_names_cache === null || $mtime !== $disk_names_mtime) {
			$disk_names_cache = MiscUD::get_json($paths['disk_names']) ?: [];
			$disk_names_mtime = $mtime;
		}

		/* Only write the JSON if it actually changes */
		if ($disk_names_cache !== $disk_names) {
			MiscUD::put_json($paths['disk_names'], $disk_names);

			/* Update the cache and mtime after write */
			$disk_names_cache = $disk_names;
			$disk_names_mtime = is_file($paths['disk_names']) ? filemtime($paths['disk_names']) : $disk_names_mtime;
		}

		/* Save the UD share names for duplicate check. */
		$mtime = is_file($paths['share_names']) ? filemtime($paths['share_names']) : 0;

		if ($share_names_cache === null || $mtime !== $share_names_mtime) {
			$share_names_cache = MiscUD::get_json($paths['share_names']) ?: [];
			$share_names_mtime = $mtime;
		}

		/* Only write the JSON if it actually changes */
		if ($share_names_cache !== $share_names) {
			MiscUD::put_json($paths['share_names'], $share_names);

			/* Update the cache and mtime after write */
			$share_names_cache = $share_names;
			$share_names_mtime = is_file($paths['share_names']) ? filemtime($paths['share_names']) : $share_names_mtime;
		}

		/* Current data sections */
		$data = [
			'disks'				=> $o_disks,
			'remotes'			=> $o_remotes,
			'historical'		=> $o_historical,
			'preclear_active'	=> $preclear_active
		];

		echo json_encode($data);
		break;

	case 'update_ping':
		/* Refresh the ping status in the background. */
		$timed_cmd	= DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/get_ud_stats ping > /dev/null 2>&1 &";
		timed_exec(0, $timed_cmd);
		break;

	case 'get_content_json':
		/* Get the UD disk info and return in a json format. */
		$all_disks	= get_all_disks_info();
		echo json_encode($all_disks);
		break;

	/*	CONFIG	*/
	case 'automount':
		/* Update auto mount configuration setting. */
		$serial = htmlspecialchars(urldecode($_POST['device']));
		$status = htmlspecialchars(urldecode($_POST['status']));

		$result	= toggle_automount($serial, $status);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'show_partitions':
		/* Update show partitions configuration setting. */
		$serial = htmlspecialchars(urldecode($_POST['serial']));
		$status = htmlspecialchars(urldecode($_POST['status']));

		$result	= set_config($serial, "show_partitions", ($status == "true") ? "yes" : "no");
		echo json_encode(array( 'result' => $result ));
		break;

	case 'enable_script':
		/* Update the enable script configuration setting. */
		$device	= htmlspecialchars(urldecode($_POST['device']));
		$part	= htmlspecialchars(urldecode($_POST['part']));
		$status = htmlspecialchars(urldecode($_POST['status'])) == "yes" ? "true" : "false";

		$result	= set_config($device, "enable_script.".$part, $status);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'set_command':
		/* Set the user command configuration setting. */
		$serial		= htmlspecialchars(urldecode($_POST['serial']));
		$part		= htmlspecialchars(urldecode($_POST['part']));
		$cmd		= htmlspecialchars(urldecode($_POST['command']));
		$user_cmd	= htmlspecialchars(urldecode($_POST['user_command']));

		$file_path = pathinfo($cmd);
		if ((($file_path['dirname'] ?? "") == "/boot/config/plugins/".UNASSIGNED_PLUGIN) && ($file_path['filename'])) {
			set_config($serial, "user_command.".$part, $user_cmd);
			$result	= set_config($serial, "command.".$part, $cmd);
			echo json_encode(array( 'result' => $result ));
		} else {
			if ($cmd) {
				unassigned_log("Warning: Cannot use '$cmd' as a device script file name.");
			}
			echo json_encode(array( 'result' => false ));
		}
		break;

	case 'set_volume':
		/* Set apfs volume configuration setting. */
		$serial	= htmlspecialchars(urldecode($_POST['serial']));
		$part	= htmlspecialchars(urldecode($_POST['part']));
		$vol	= htmlspecialchars(urldecode($_POST['volume']));

		$result	= set_config($serial, "volume.".$part, $vol);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'set_ntfs3_driver':
		/* Set ntfs3 option configuration setting. */
		$serial	= htmlspecialchars(urldecode($_POST['serial']));
		$part	= htmlspecialchars(urldecode($_POST['part']));
		$ntfs3	= htmlspecialchars(urldecode($_POST['ntfs3_driver']));

		$result	= set_config($serial, "ntfs3_driver.".$part, $ntfs3);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'set_compress_option':
		/* Set compress option configuration setting. */
		$serial		= htmlspecialchars(urldecode($_POST['serial']));
		$part		= htmlspecialchars(urldecode($_POST['part']));
		$compress	= htmlspecialchars(urldecode($_POST['compress_option']));

		$result	= set_config($serial, "compress_option.".$part, $compress);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'set_name':
		/* Set disk name configuration setting. */
		$serial		= htmlspecialchars(urldecode($_POST['serial']));
		$dev		= htmlspecialchars(urldecode($_POST['device']));
		$name		= safe_name(htmlspecialchars(urldecode($_POST['name'])));

		$disk_names	= MiscUD::get_json($paths['disk_names']);
		$dev_name	= get_disk_dev($dev);
		$result		= true;

		/* Remove our disk name from the duplicate check. */
		unset($disk_names[$dev]);
		unset($disk_names[$serial]);

		/* Ignore devX device names. */
		if ((! is_dev_device($name)) && ($name != $dev_name)) {
			/* Empty name resets to the default device name. */
			if (! $name) {
				$name = $dev_name;
			}

			/* Disk name cannot be an sdX device designation or an already used UD name. */
			if (is_sd_device($name)) {
				unassigned_log("Warning: Disk Name cannot be a device designation.");
				$result = false;
			} elseif (in_array($name, $disk_names, true)) {
				unassigned_log("Warning: Disk Name '".$name."' is already being used on another device.");
				$result = false;
			} else {
				$ser = $serial.($dev ? " (".$dev.")" : "");

				$old_name = get_config($serial, "unassigned_dev");
				if ($old_name != $name) {
					unassigned_log("Set Disk Name on '".$ser."' to '".$name."'");
					$result = set_config($serial, "unassigned_dev", $name);
				}
			}
		}

		echo json_encode(array( 'result' => $result ));
		break;

	case 'remove_config':
		/* Remove historical disk configuration. */
		$serial	= htmlspecialchars(urldecode($_POST['serial']));

		$result	= remove_config_disk($serial);
		echo json_encode($result);
		break;

	case 'toggle_share':
		/* Toggle the disk share configuration setting. */
		$info			= json_decode($_POST['info'], true);
		$status			= htmlspecialchars(urldecode($_POST['status']));
		$serial			= htmlspecialchars($info['serial']);
		$partition		= htmlspecialchars($info['part']);
		$fstype			= htmlspecialchars($info['fstype']);
		$mountpoint		= htmlspecialchars($info['mountpoint']);
		$part_read_only	= htmlspecialchars($info['part_read_only']);
		$mounted		= htmlspecialchars($info['mounted']);

		$result	= toggle_share($serial, $partition, $status);
		if (($result) && ($mounted)) {
			$fat_fruit	= (($fstype == "vfat") || ($fstype == "exfat"));
			add_smb_share($mountpoint, (! $part_read_only), $fat_fruit);
			add_nfs_share($mountpoint, $fstype);
		} else if ($mounted) {
			remove_smb_share($mountpoint, true);
			remove_nfs_share($mountpoint, $fstype);
		}
		echo json_encode(array( 'result' => $result ));
		break;

	case 'toggle_historical_share':
		/* Toggle the historical share configuration setting. */
		$serial		= htmlspecialchars(urldecode($_POST['serial']));
		$partition	= htmlspecialchars(urldecode($_POST['part']));
		$status		= htmlspecialchars(urldecode($_POST['status']));

		$result		= toggle_share($serial, $partition, $status);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'toggle_read_only':
		/* Toggle the disk read only configuration setting. */
		$serial	= htmlspecialchars(urldecode($_POST['serial']));
		$part	= htmlspecialchars(urldecode($_POST['part']));
		$status	= htmlspecialchars(urldecode($_POST['status']));

		$result	= toggle_read_only($serial, $status, $part);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'toggle_pass_through':
		/* Toggle the disk pass through configuration setting. */
		$serial	= htmlspecialchars(urldecode($_POST['serial']));
		$part	= htmlspecialchars(urldecode($_POST['part']));
		$status	= htmlspecialchars(urldecode($_POST['status']));

		$result	= toggle_pass_through($serial, $status, $part);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'toggle_disable_mount':
		/* Toggle the disable mount button setting. */
		$serial	= htmlspecialchars(urldecode($_POST['device']));
		$part	= htmlspecialchars(urldecode($_POST['part']));
		$status	= htmlspecialchars(urldecode($_POST['status']));

		$result	= toggle_disable_mount($serial, $status, $part);
		echo json_encode(array( 'result' => $result ));
		break;

	/* ALL DEVICES */
	case 'mount':
		/* Mount a disk device. */
		$device	= htmlspecialchars(urldecode($_POST['device']));

		$timed_cmd	= "/usr/bin/nice ".DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/rc.unassigned mount ".escapeshellarg($device)." 0 2>&1";
		$return		= timed_exec(0, $timed_cmd);
		echo json_encode($return == "success");
		break;

	case 'umount':
		/* Unmount a disk device. */
		$device	= htmlspecialchars(urldecode($_POST['device']));

		$timed_cmd	= "/usr/bin/nice ".DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/rc.unassigned umount ".escapeshellarg($device)." 0 2>&1";
		$return		= timed_exec(0, $timed_cmd);
		echo json_encode($return == "success");
		break;

	case 'get_device_script':
		/* Get the contents of the device script file. */
		$file			= htmlspecialchars(urldecode($_POST['file']));

		if ($file) {
			$result		= file_get_contents($file);
		} else {
			$result		= "";
		}
		echo json_encode($result);
		break;

	/* DISK */
	case 'rescan_disks':
		/* Refresh all disk partition information, update config files from flash, and clear status files. */
		$timed_cmd = DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/copy_config.sh";
		timed_exec(0, $timed_cmd);

		/* Rescan all disk partitions. */
		foreach (get_all_disks_info() as $d) {
			$device = $d['device'] ?? "";

			foreach (($d['partitions'] ?? []) as $p) {
				/* Get partition designation based on type of device. */
				if (MiscUD::is_device_nvme($device)) {
					$dev = $device."p".$p['part'];
				} else {
					$dev = $device.$p['part'];
				}

				/* Trigger udev to rescan the partition device. */
				$return_code	= null;
				$timed_cmd		= "/sbin/udevadm trigger ".escapeshellarg($dev)." 2>&1";

				timed_exec(5, $timed_cmd, true, $return_code);

				if ($return_code !== 0) {
					unassigned_log("Failed to trigger udev on device '".$dev."'.");
				}
			}
		}

		/* Clear all the disk sizes and partition file types so they can be rediscovered after a hotplug. */
		get_disk_size("", true);
		part_fs_type("", true);

		/* Clear cached NFS path checks. */
		check_remote_nfs_path("", "", true);

		/* Update the all remote servers ping status. */
		$timed_cmd = DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/get_ud_stats ping > /dev/null 2>&1 &";
		timed_exec(0, $timed_cmd, true);

		unassigned_log("Refreshed Disks and Configuration.");
		unassigned_log("Debug: Rescan Disks: initiated a Hotplug event.", $UDEV_DEBUG);

		/* Give udev triggers time to start, then initiate an Unraid update of devs.ini for unassigned devices. */
		sleep(1);

		/* Ask Unraid handle a hotplug event. */
		apply_hotplug_now();

		echo json_encode(true);
		break;

	case 'format_disk':
		/* Format a disk. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$fs			= htmlspecialchars(urldecode($_POST['fs']));
		$pass		= $_POST['pass'] ?? "";
		$pool_name	= htmlspecialchars(urldecode($_POST['pool_name'] ?? ""));
		$pool_name	= safe_name($pool_name, false);

		/* Create the state file. */
		$state_file	= MiscUD::set_mount_state(basename($device), 'formatting');

		/* Get the Unraid reserved names. Pool name cannot be a reserved name. */
		$reserved_names = explode(",", $var['reservedNames']);

		if (($pool_name) && (in_array($pool_name, $reserved_names))) {
			unassigned_log("Error: Pool name '".$pool_name."' is reserved!");
			$result	= false;
		} else {
			/* Format the disk. */
			$result	= format_disk($device, $fs, $pass, $pool_name);
		}

		/* Remove the state file. */
		MiscUD::rem_mount_state($state_file);

		/* Return status. */
		echo json_encode(array( 'status' => $result ));
		break;

	/* SAMBA */
	case 'list_samba_hosts':
		$network = $_POST['network'];
		$names = [];

		foreach ($network as $iface) {
			/* Validate 'ip' and 'netmask' fields. */
			if (! isset($iface['ip'], $iface['netmask']) || (! MiscUD::is_ip($iface['ip'])) || (! MiscUD::is_ip($iface['netmask']))) {
				unassigned_log("Invalid network data received for iface: ".json_encode($iface));
				continue;
			}

			$ip			= $iface['ip'];
			$netmask	= $iface['netmask'];

			/* Initialize and populate $hosts with SMB servers. */
			$hosts		= [];
			$exitCode	= 0;
			$timed_cmd	= DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/hosts_port_ping.sh ".escapeshellarg($ip)." ".escapeshellarg($netmask)." ".SMB_PORT." 2>/dev/null";
			$hosts		= timed_exec(15, $timed_cmd, false, $exitCode, true);

			/* Skip if the script failed or no hosts were found. */
			if (($exitCode !== 0) || (! ($hosts))) {
				unassigned_log("Warning: hosts_port_ping.sh failed or found no hosts for $ip/$netmask");
				continue;
			}

			/* Resolve hostnames for each found IP. */
			foreach ($hosts as $host) {
				if ($host === $ip) {
					$name = $var['NAME'] ?? 'UNKNOWN';
				} else {
					/* Resolve name as a local server. */
					$timed_cmd	= "/sbin/arp -a ".escapeshellarg($host)." 2>&1 | grep -v 'arp:' | /bin/awk '{print $1}'";
					$name		= timed_exec(2, $timed_cmd);
					if ($name == "?") {
						/* Attempt name lookup using nmblookup. */
						$timed_cmd	= "/usr/bin/nmblookup -A ".escapeshellarg($host)." 2>/dev/null | grep -v 'GROUP' | grep -Po '[^<]*(?=<00>)' | head -n 1";
						$name		= timed_exec(2, $timed_cmd);
						if (! $name) {
							/* Attempt name lookup using avahi. */
							$timed_cmd	= "avahi-resolve-address ".escapeshellarg($host)." | /bin/awk '{print \$2}'";
							$name		= timed_exec(0, $timed_cmd);
						} else {
							$name .= ".".$local_tld;
						}
					}
				}

				/* Add the resolved name or fallback to IP. */
				$names[] = strtoupper($name ?: $host);
			}
		}

		/* Remove duplicate names and sort naturally. */
		$names = array_unique($names);
		natsort($names);

		/* Return the resolved hostnames or an empty string. */
		echo implode(PHP_EOL, $names);
		break;

	case 'list_samba_shares':
		/* Get a list of samba shares for a specific host. */
		$ip			= htmlspecialchars(urldecode($_POST['IP'] ?? ""));
		$user		= htmlspecialchars(urldecode($_POST['USER'] ?? ""));
		$pass		= $_POST['PASS'] ?? "";
		$domain		= htmlspecialchars(urldecode($_POST['DOMAIN'] ?? ""));

		$ip			= implode("",explode("\\", $ip));
		$ip			= strtoupper(stripslashes(trim($ip)));

		/* Create the credentials file. */
		@file_put_contents($paths['authentication'], "username=".$user."\n");
		@file_put_contents($paths['authentication'], "password=".$pass."\n", FILE_APPEND);
		@file_put_contents($paths['authentication'], "domain=".$domain."\n", FILE_APPEND);

		/* Update this server status before listing shares. */
		$timed_cmd	= DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/get_ud_stats is_online ".escapeshellarg($ip)." "."SMB";
		timed_exec(0, $timed_cmd);

		/* Get a list of samba shares on this server. */
		$timed_cmd	= "/usr/bin/smbclient -t2 -g -L ".escapeshellarg($ip)." --authentication-file=".escapeshellarg($paths['authentication'])." 2>/dev/null | /usr/bin/awk -F'|' '/Disk/{print $2}' | sort";
		$list		= timed_exec(15, $timed_cmd);

		/* Shred the authentication file and remove the credential variables. */
		MiscUD::shred_file($paths['authentication']);
		unset($user);
		unset($pass);
		unset($domain);
		echo $list;
		break;

	/* NFS */
	case 'list_nfs_hosts':
		$network = $_POST['network'];
		$names = [];

		foreach ($network as $iface) {
			/* Validate 'ip' and 'netmask' fields. */
			if (! isset($iface['ip'], $iface['netmask']) || (! MiscUD::is_ip($iface['ip'])) || (! MiscUD::is_ip($iface['netmask']))) {
				unassigned_log("Invalid network data received for iface: ".json_encode($iface));
				continue;
			}

			$ip			= $iface['ip'];
			$netmask	= $iface['netmask'];

			/* Initialize and populate $hosts with NFS servers. */
			$hosts		= [];
			$exitCode	= 0;
			$timed_cmd	= DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/hosts_port_ping.sh ".escapeshellarg($ip)." ".escapeshellarg($netmask)." ".NFS_PORT." 2>/dev/null";
			$hosts		= timed_exec(15, $timed_cmd, false, $exitCode, true);

			/* Skip if the script failed or no hosts were found. */
			if (($exitCode !== 0) || (! $hosts)) {
				unassigned_log("hosts_port_ping.sh failed or found no hosts for $ip/$netmask");
				continue;
			}

			/* Resolve hostnames for each found IP. */
			foreach ($hosts as $host) {
				if ($host === $ip) {
					$name = $var['NAME'] ?? 'UNKNOWN';
				} else {
					/* Resolve name as a local server. */
					$timed_cmd	= "/sbin/arp -a ".escapeshellarg($host)." 2>&1 | grep -v 'arp:' | /bin/awk '{print $1}'";
					$name		= timed_exec(2, $timed_cmd, false, $teturn_code);
					if ($name == "?") {
						/* Attempt name lookup using avahi. */
						$timed_cmd	= "avahi-resolve-address ".escapeshellarg($host)." | /bin/awk '{print \$2}'";
						$name = timed_exec(0, $timed_cmd);
					}
				}

				/* Verify if the server shares are available using `showmount`. */
				$timed_cmd	= "/usr/sbin/showmount -e ".escapeshellarg($host)." 2>/dev/null";
				$result = timed_exec(2, $timed_cmd);
				if ($result) {
					$names[] = strtoupper($name ?: $host);
				}
			}
		}

		/* Remove duplicate names and sort naturally. */
		$names = array_unique($names);
		natsort($names);

		/* Return the resolved hostnames or an empty string. */
		echo implode(PHP_EOL, $names);
		break;

	case 'list_nfs_shares':
		/* Get a list of nfs shares for a specific host. */
		$ip			= htmlspecialchars(urldecode($_POST['IP'] ?? ""));
		$ip			= implode("",explode("\\", $ip));
		$ip			= strtoupper(stripslashes(trim($ip)));

		/* Update this server status before listing shares. */
		$timed_cmd	= DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/get_ud_stats is_online ".escapeshellarg($ip)." "."NFS";
		timed_exec(0, $timed_cmd);

		/* List the shares. */
		$timed_cmd	= "/usr/sbin/showmount --no-headers -e ".escapeshellarg($ip)." 2>/dev/null | rev | cut -d' ' -f2- | rev | sort";
		$result		= timed_exec(2, $timed_cmd);
		echo $result ?: " ";
		break;

	/* SMB SHARES */
	case 'add_samba_share':
		/* Add a samba share configuration. */
		$ip			= htmlspecialchars(urldecode($_POST['IP'] ?? ""));
		$protocol	= htmlspecialchars(urldecode($_POST['PROTOCOL']));
		$user		= htmlspecialchars(urldecode($_POST['USER'] ?? ""));
		$domain		= htmlspecialchars(urldecode($_POST['DOMAIN'] ?? ""));
		$pass		= $_POST['PASS'] ?? "";
		$path		= htmlspecialchars(urldecode($_POST['SHARE'] ?? ""));

		$rc			= true;

		/* Remove backslashes, trim whitespace, and convert to uppercase. */
		$ip_local	= stripslashes(trim($ip));
		$ip_local	= MiscUD::is_ip($ip_local) ? $ip_local : strtoupper($ip_local);
		$ip_local	= trim(str_replace("\\", "", $ip_local));

		$path		= implode("",explode("\\", $path));
		$path		= stripslashes(trim($path));
		$share		= basename($path);

		/* Remove the 'local' and 'default' tld reference as they aren't used here. */
		if (! MiscUD::is_ip($ip)) {
			$ip		= str_replace( array(".".$local_tld, ".".$default_tld), "", $ip_local);
		}

		/* See if there is another mount with a different protocol. */
		foreach (get_samba_mounts() as $mount) {
			if (($mount['ip'] == $ip_local) && (basename($mount['path']) == basename($path)) && ($mount['protocol'] != $protocol)) {
				$same_protocol	= $mount['protocol'];
				$rc	= false;
			}
		}

		if ($rc) {
			/* Don't save any information if the share is blank. */
			if ($share) {
				/* Clean up the device name so it is safe for php. */
				$safe_path		= safe_name($path, false);
				$device	= ($protocol == "NFS") ? $ip.":".$safe_path : "//".$ip."/".$safe_path;

				/* Remove dollar signs in device. */
				$device	= str_replace("$", "", $device);

				/* Set this configuration. */
				set_samba_config($device, "protocol", $protocol);
				set_samba_config($device, "ip", (MiscUD::is_ip($ip) ? $ip_local : strtoupper($ip_local)));
				set_samba_config($device, "path", $path);

				if ($protocol == "SMB") {
					set_samba_config($device, "user", $user);
					set_samba_config($device, "domain", $domain);
					set_samba_config($device, "pass", addslashes(encrypt_data($pass)));
				}

				set_samba_config($device, "share", $share);
			} else {
				unassigned_log("Warning: share cannot be blank.");
				$rc	= false;
			}
		} else {
			unassigned_log("Warning: '".$share."' is already added as a '".$same_protocol."' share.");
		}
		echo json_encode($rc);
		break;

	case 'remove_samba_config':
		/* Remove samba configuration. */
		$device		= htmlspecialchars(urldecode($_POST['device']));

		$result		= remove_config_samba($device);
		echo json_encode($result);
		break;

	case 'samba_automount':
		/* Set samba auto mount configuration setting. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$status		= htmlspecialchars(urldecode($_POST['status']));

		$result		= toggle_samba_automount($device, $status);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'toggle_samba_share':
		/* Toggle samba share configuration setting. */
		$info		= json_decode($_POST['info'], true);
		$status		= htmlspecialchars(urldecode($_POST['status']));

		$result		= toggle_samba_share($info['device'], $status);
		if (($result) && ($info['mounted'])) {
			add_smb_share($info['mountpoint'], $info['fstype'] == "root");
			add_nfs_share($info['mountpoint'], $info['fstype']);
		} else if ($info['mounted']) {
			remove_smb_share($info['mountpoint']);
			remove_nfs_share($info['mountpoint'], $info['fstype']);
		}
		echo json_encode(array( 'result' => $result ));
		break;

	case 'toggle_samba_readonly':
		/* Toggle the disable mount button setting. */
		$serial	= htmlspecialchars(urldecode($_POST['serial']));
		$status	= htmlspecialchars(urldecode($_POST['status']));

		$result	= toggle_samba_readonly($serial, $status);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'toggle_samba_disable_mount':
		/* Toggle the disable mount button setting. */
		$device	= htmlspecialchars(urldecode($_POST['device']));
		$status	= htmlspecialchars(urldecode($_POST['status']));

		$result	= toggle_samba_disable_mount($device, $status);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'samba_enable_script':
		/* Set samba share enable script configuration setting. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$status		= htmlspecialchars(urldecode($_POST['status'])) == "yes" ? "true" : "false";

		$result		= set_samba_config($device, "enable_script", $status);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'samba_enable_encryption':
		/* Set samba mount encryption configuration setting. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$status		= htmlspecialchars(urldecode($_POST['status']));

		$result		= set_samba_config($device, "encryption", $status);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'samba_cifs_uid':
		/* Set samba mount uid configuration setting. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$value		= htmlspecialchars(urldecode($_POST['value']));

		$result		= set_samba_config($device, "cifs_uid", $value);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'samba_cifs_gid':
		/* Set samba mount gid configuration setting. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$value		= htmlspecialchars(urldecode($_POST['value']));

		$result		= set_samba_config($device, "cifs_gid", $value);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'samba_cifs_cache':
		/* Set samba mount cache configuration setting. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$value		= htmlspecialchars(urldecode($_POST['value']));

		$result		= set_samba_config($device, "cifs_cache", $value);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'set_samba_command':
		/* Set samba share user command configuration setting. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$cmd		= htmlspecialchars(urldecode($_POST['command']));
		$user_cmd	= htmlspecialchars(urldecode($_POST['user_command']));

		$file_path = pathinfo($cmd);
		if ((isset($file_path['dirname'])) && ($file_path['dirname'] == "/boot/config/plugins/".UNASSIGNED_PLUGIN) && ($file_path['filename'])) {
			set_samba_config($device, "user_command", $user_cmd);
			$result		= set_samba_config($device, "command", $cmd);
			echo json_encode(array( 'result' => $result ));
		} else {
			if ($cmd) {
				unassigned_log("Warning: Cannot use '$cmd' as a device script file name.");
			}
			echo json_encode(array( 'result' => false ));
		}
		break;

	/* ISO FILE SHARES */
	case 'add_iso_share':
		/* Add iso file share. */
		$rc			= true;
		$file		= htmlspecialchars(urldecode($_POST['ISO_FILE'] ?? ""));
		$file 		= implode("", explode("\\", $file));
		$file		= stripslashes(trim($file));
		if (is_file($file)) {
			$info = pathinfo($file);

			/* Clean up the file name for the share so php won't be upset. */
			$share	= safe_name($info['filename']);

			/* Clean up the file name to use as the device. */
			$device		= safe_name($info['basename']);

			set_iso_config($device, "file", $file);
			set_iso_config($device, "share", $share);
		} else {
			unassigned_log("ISO File '".$file."' not found.");
			$rc		= false;
		}
		echo json_encode($rc);
		break;

	case 'remove_iso_config':
		/* Remove the iso share configuration. */
		$device = htmlspecialchars(urldecode($_POST['device']));

		$result	= remove_config_iso($device);
		echo json_encode($result);
		break;

	case 'iso_automount':
		/* Set the iso auto mount configuration setting. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$status		= htmlspecialchars(urldecode($_POST['status']));

		$result		= toggle_iso_automount($device, $status);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'iso_enable_script':
		/* Set the enable configuration setting. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$status		= htmlspecialchars(urldecode($_POST['status'])) == "yes" ? "true" : "false";

		$result		= set_iso_config($device, "enable_script", $status);
		echo json_encode(array( 'result' => $result ));
		break;

	case 'set_iso_command':
		/* Set the iso command file configuration setting. */
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$cmd		= htmlspecialchars(urldecode($_POST['command']));

		$file_path = pathinfo($cmd);
		if ((isset($file_path['dirname'])) && ($file_path['dirname'] == "/boot/config/plugins/".UNASSIGNED_PLUGIN) && ($file_path['filename'])) {
			$result		= set_iso_config($device, "command", $cmd);
			echo json_encode(array( 'result' => $result ));
		} else {
			if ($cmd) {
				unassigned_log("Warning: Cannot use '$cmd' as a device script file name.");
			}
			echo json_encode(array( 'result' => false ));
		}
		break;

	/* ROOT SHARES */
	case 'add_root_share':
		/* Add root file share. */
		$ip			= strtoupper($var['NAME']);
		$path		= "/mnt/".htmlspecialchars(urldecode($_POST['path']));
		$device		= "//".$ip.$path;
		$share		= basename($path);

		$rc			= true;

		/* Cannot add a root share if disk shares shares are enabled. */
		if (($var['shareDisk'] != "yes") && ($var['shareUserExclusive'] != "yes")) {
			/* See if there is already a rootshare mount. */
			foreach (get_samba_mounts() as $mount) {
				if (($mount['path'] != $path) && ($mount['protocol'] == "ROOT")) {
					$rc	= false;
					break;
				}
			}
			if ($rc) {
				set_samba_config($device, "protocol", "ROOT");
				set_samba_config($device, "ip", $ip);
				set_samba_config($device, "path", $path);
				set_samba_config($device, "share", safe_name($share, false));
			} else {
				unassigned_log("Warning: Root Share is already assigned!");
			}
		} else {
			unassigned_log("Warning: Disk Shares and Exclusive Shares must be disabled to add a Root Share!");
			$rc	= false;
		}

		echo json_encode($rc);
		break;

	case 'remove_root_config':
		/* Remove the root share configuration. */
		$device = htmlspecialchars(urldecode($_POST['device']));

		$result	= remove_config_samba($device);
		echo json_encode($result);
		break;

	/*	MISC */
	case 'remove_partition':
		/* Remove a partition from a disk. */
		$serial		= htmlspecialchars(urldecode($_POST['serial']));
		$device		= htmlspecialchars(urldecode($_POST['device']));
		$partition	= htmlspecialchars(urldecode($_POST['partition']));

		/* A disk can't be set to automount. */
		if (is_automount($serial)) {
			toggle_automount($serial, false);
		}
		$result		= remove_partition($device, $partition);
		echo json_encode($result);
		break;

	case 'clear_disk':
		/* Remove all partitions from a disk. */
		$serial		= htmlspecialchars(urldecode($_POST['serial']));
		$device		= htmlspecialchars(urldecode($_POST['device']));

		/* A disk can't be set to automount. */
		if (is_automount($serial)) {
			toggle_automount($serial, false);
		}

		$result		= remove_all_partitions($device);
		echo json_encode($result);
		break;

	case 'spin_down_disk':
		/* Spin down a disk device. */
		$device		= htmlspecialchars(urldecode($_POST['device']));

		/* Set the spinning_down state. */
		$tc			= $paths['run_status'];
		$run_status	= file_exists($tc) ? json_decode(file_get_contents($tc), true) : [];
		if (isset($run_status[$device]) && ($run_status[$device]['running'] == "yes")) {
			$run_status[$device]['spin_time']	= time();
			$run_status[$device]['spin']		= "down";
			@file_put_contents($tc, json_encode($run_status));
			$result	= MiscUD::spin_disk(true, $device);
			echo json_encode($result);
		} else {
			echo json_encode(true);
		}
		break;

	case 'spin_up_disk':
		/* Spin up a disk device. */
		$device		= htmlspecialchars(urldecode($_POST['device']));

		/* Set the spinning_up state. */
		$tc			= $paths['run_status'];
		$run_status	= file_exists($tc) ? json_decode(file_get_contents($tc), true) : [];
		if ((isset($run_status[$device])) && ($run_status[$device]['running'] == "no")) {
			$run_status[$device]['spin_time']	= time();
			$run_status[$device]['spin']		= "up";
			@file_put_contents($tc, json_encode($run_status));
			$result	= MiscUD::spin_disk(false, $device);
			echo json_encode($result);
		} else {
			echo json_encode(true);
		}
		break;

	case 'change_mountpoint':
		/* Change a disk mount point. */
		$serial			= htmlspecialchars(urldecode($_POST['serial']));
		$partition		= htmlspecialchars(urldecode($_POST['partition']));
		$device			= htmlspecialchars(urldecode($_POST['device']));
		$fstype			= htmlspecialchars(urldecode($_POST['fstype']));

		$mountpoint		= basename(safe_name(htmlspecialchars(urldecode($_POST['mountpoint'])), false));
		if ((! is_dev_device($mountpoint)) && (! is_sd_device($mountpoint))) {
			$result		= change_mountpoint($serial, $partition, $device, $fstype, $mountpoint);
		} else {
			unassigned_log("Warning: Mount Point cannot be a device designation.");
			$result		= false;
		}
		echo json_encode($result);
		break;

	case 'change_samba_mountpoint':
		/* Change a samba share mount point. */
		$device			= htmlspecialchars(urldecode($_POST['device']));
		$mountpoint		= basename(safe_name(basename(htmlspecialchars(urldecode($_POST['mountpoint']))), false));

		$result			= change_samba_mountpoint($device, $mountpoint);
		echo json_encode($result);
		break;

	case 'change_iso_mountpoint':
		/* Change an iso file mount point. */
		$device			= htmlspecialchars(urldecode($_POST['device']));
		$mountpoint		= safe_name(basename(htmlspecialchars(urldecode($_POST['mountpoint']))), false);

		$result			= change_iso_mountpoint($device, $mountpoint);
		echo json_encode($result);
		break;

	default:
		unassigned_log("Undefined POST action - ".$_POST['action'].".");
		break;
	}
?>
