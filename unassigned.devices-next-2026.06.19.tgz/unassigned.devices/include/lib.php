<?php
/*
Copyright (C) 2016-2026 Dan Landon
Licensed under the Unassigned Devices - Next Personal Use License v1.0
See LICENSE.md for full license terms.
*/

/* Define the docroot path. */
if (! defined('DOCROOT')) {
	define('DOCROOT', $_SERVER['DOCUMENT_ROOT'] ?: '/usr/local/emhttp');
}

/* Define our plugin name. */
define('UNASSIGNED_PLUGIN', 'unassigned.devices');

/* Define plugin path for JavaScript. */
define('UD_PLUGIN_PATH', json_encode(UNASSIGNED_PLUGIN));

/* Define the UD configuration path on the flash device. */
define('UD_FLASH_PATH', '/boot/config/plugins/'.UNASSIGNED_PLUGIN.'/');

/* Define the User Scripts files path on the flash device. */
define('USER_SCRIPTS_PATH', '/boot/config/plugins/user.scripts/scripts');

/* Define UD settings script path. */
define('UD_SETTINGS_SCRIPT', DOCROOT.'/plugins/'.UNASSIGNED_PLUGIN.'/scripts/rc.settings');

/* Get the Unraid Wrappers and Helpers files. */
require_once(DOCROOT."/webGui/include/Wrappers.php");
require_once(DOCROOT."/webGui/include/Helpers.php");

/* Set up display parameters. */
if (isset($_POST['display'])) {
	$display = $_POST['display'];
}

/* add translations */
require_once(DOCROOT."/webGui/include/Translations.php");

$paths = [	"smb_unassigned"	=> "/etc/samba/smb-unassigned.conf",
			"smb_usb_shares"	=> "/etc/samba/unassigned-shares",
			"usb_mountpoint"	=> "/mnt/disks",
			"remote_mountpoint"	=> "/mnt/remotes",
			"root_mountpoint"	=> "/mnt/rootshare",
			"dev_state"			=> DOCROOT."/state/devs.ini",
			"shares_state"		=> DOCROOT."/state/shares.ini",
			"disks_state"		=> DOCROOT."/state/disks.ini",
			"disk_load"			=> DOCROOT."/state/diskload.ini",
			"default_file"		=> DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/default.cfg",
			"diag_state"		=> DOCROOT."/".UNASSIGNED_PLUGIN.".ini",
			"device_log"		=> "/tmp/".UNASSIGNED_PLUGIN."/logs/",
			"config_file"		=> "/tmp/".UNASSIGNED_PLUGIN."/config/".UNASSIGNED_PLUGIN.".cfg",
			"samba_mount"		=> "/tmp/".UNASSIGNED_PLUGIN."/config/samba_mount.cfg",
			"iso_mount"			=> "/tmp/".UNASSIGNED_PLUGIN."/config/iso_mount.cfg",
			"scripts"			=> "/tmp/".UNASSIGNED_PLUGIN."/scripts/",
			"credentials"		=> "/tmp/".UNASSIGNED_PLUGIN."/credentials",
			"authentication"	=> "/tmp/".UNASSIGNED_PLUGIN."/authentication",
			"luks_pass"			=> "/tmp/".UNASSIGNED_PLUGIN."/luks_pass",
			"hotplug_event"		=> "/tmp/".UNASSIGNED_PLUGIN."/hotplug_event",
			"hotplug_running"	=> "/tmp/".UNASSIGNED_PLUGIN."/hotplug_running",
			"script_running"	=> "/tmp/".UNASSIGNED_PLUGIN."/running/",
			"user_running"		=> "/tmp/user.scripts/running/",
			"lock_file"			=> "/var/lock/%s.LCK",
			"state"				=> "/var/state/".UNASSIGNED_PLUGIN."/".UNASSIGNED_PLUGIN.".ini",
			"mounted_disks"		=> "/var/state/".UNASSIGNED_PLUGIN."/".UNASSIGNED_PLUGIN.".json",
			"run_status"		=> "/var/state/".UNASSIGNED_PLUGIN."/run_status.json",
			"ping_status"		=> "/var/state/".UNASSIGNED_PLUGIN."/ping_status.json",
			"part_file_types"	=> "/var/state/".UNASSIGNED_PLUGIN."/part_file_types.json",
			"disk_sizes"		=> "/var/state/".UNASSIGNED_PLUGIN."/disk_sizes.json",
			"df_status"			=> "/var/state/".UNASSIGNED_PLUGIN."/df_status.json",
			"disk_names"		=> "/var/state/".UNASSIGNED_PLUGIN."/disk_names.json",
			"nfs_remote_paths"	=> "/var/state/".UNASSIGNED_PLUGIN."/nfs_remote_paths.json",
			"share_names"		=> "/var/state/".UNASSIGNED_PLUGIN."/share_names.json",
			"pool_state"		=> "/var/state/".UNASSIGNED_PLUGIN."/pool_state.json",
			"device_hosts"		=> "/var/state/".UNASSIGNED_PLUGIN."/device_hosts.json",
			"unmounting"		=> "/var/state/".UNASSIGNED_PLUGIN."/unmounting_%s.state",
			"mounting"			=> "/var/state/".UNASSIGNED_PLUGIN."/mounting_%s.state",
			"formatting"		=> "/var/state/".UNASSIGNED_PLUGIN."/formatting_%s.state",
			"clearing"			=> "/var/state/".UNASSIGNED_PLUGIN."/clearing_%s.state"
		];

/* Define UD config files paths. */
define('UD_CONFIG_FILE', $paths['config_file']);
define('SAMBA_MOUNT', $paths['samba_mount']);
define('ISO_MOUNT', $paths['iso_mount']);

/* Unraid-compatible file systems. */
define('UNRAID_COMPATIBLE_FS', [
	'xfs',
	'btrfs',
	'zfs',
	'ext4',
	'ntfs',
]);

/* SMB and NFS ports. */
define('SMB_PORT', '445');
define('NFS_PORT', '2049');
define('RPC_PORT', '111');

/* Mount and unmount delays from cli commands. */
define('MOUNT_DELAY', "2");
define('UNMOUNT_DELAY', "2");

/* The time to wait for processes to stop when aborting UD and User Scripts. */
define('ABORT_WAIT_TIMEOUT', 10);

/* Get the Unraid users. */
$users_ini			= @parse_ini_file(DOCROOT."/state/users.ini", true);
$users				= $users_ini !== false ? $users_ini : [];

/* Get all Unraid disk devices (array disks, cache, and pool devices). */
$array_disks_ini	= @parse_ini_file(DOCROOT."/state/disks.ini", true);
$array_disks		= $array_disks_ini !== false ? $array_disks_ini : [];
$unraid_disks		= [];
foreach ($array_disks as $d) {
	if ($d['device']) {
		$unraid_disks[] = "/dev/".$d['device'];
	}
}

/* Get the version of Unraid we are running. */
$version		= @parse_ini_file("/etc/unraid-version");

/* Set the log level for debugging. */
/* 0 - normal logging, */

/* 1 - udev and disk discovery logging, */
$UDEV_DEBUG		= 1;

/* 2 - refresh and update logging, */
$UPDATE_DEBUG	= 2;

/* 4 - command time outs. */
$CMD_TIMEOUTS	= 4;

/* 8 - command time outs. */
$CMD_DEBUG		= 8;

/* Read in the UD configuration file.  Because the config file is in /tmp/ we cannot use parse_plugin_cfg(). */
$default_file	= $paths['default_file'];
$default_cfg	= @parse_ini_file($default_file, true);
$config_ini		= @parse_ini_file(UD_CONFIG_FILE, true);
$cfg['Config']	= file_exists($default_file) ? parse_ini_file($default_file, true) : [];
$ud_config		= $config_ini !== false ? array_replace_recursive($cfg, parse_ini_file(UD_CONFIG_FILE, true)) : $cfg;

/* Adjust the config file for some legacy parameters that cause problems. */
adjust_config_params();

/* Read in the Samba configuration file. */
$config_ini		= @parse_ini_file(SAMBA_MOUNT, true, INI_SCANNER_RAW);
$samba_config	= $config_ini !== false ? $config_ini : [];

/* Read in the ISO configuration file. */
$config_ini		= @parse_ini_file(ISO_MOUNT, true, INI_SCANNER_RAW);
$iso_config		= $config_ini !== false ? $config_ini : [];

/* Get the current debug level. */
$DEBUG_LEVEL	= (int) get_config("Config", "debug_level");

/* See if the UD settings are set for either SMB or NFS sharing. */
$shares_enabled	= ((get_config("Config", "SMB_Sharing") != "no") || (get_config("Config", "NFS_Export") == "yes"));

/* Read Unraid variables file. Used to determine disks not assigned to the array and other array parameters. */
if (! isset($var)){
	if (! is_file(DOCROOT."/state/var.ini")) {
		$timed_cmd	= "/usr/bin/wget -qO /dev/null localhost:$(ss -napt | /bin/grep emhttp | /bin/grep -Po ':\K\d+') >/dev/null";
		timed_exec(0, $timed_cmd, true);
	}
	$var = @parse_ini_file(DOCROOT."/state/var.ini");
}

/* Capitalize the local_tld.  Default local TLD is 'LOCAL'. */
$default_tld	= "LOCAL";
$local_tld		= (isset($var['LOCAL_TLD']) && ($var['LOCAL_TLD'])) ? strtoupper(trim($var['LOCAL_TLD'])) : $default_tld;

/* See if the preclear plugin is installed. */
if ( is_file( DOCROOT."/plugins/preclear.disk/assets/lib.php" ) ) {
	require_once( DOCROOT."/plugins/preclear.disk/assets/lib.php" );
	$Preclear = new Preclear;
} else if ( is_file( DOCROOT."/plugins/".UNASSIGNED_PLUGIN.".preclear/include/lib.php" ) ) {
	require_once( DOCROOT."/plugins/".UNASSIGNED_PLUGIN.".preclear/include/lib.php" );
	$Preclear = new Preclear;
} else {
	$Preclear = null;
}

/* Array of devices, mount points, and read only status taken from the /proc/mounts file. */
$mounts			= null;

/* Is destructive mode enabled? */
$format_enabled	= (file_exists("/usr/sbin/parted") && (get_config("Config", "destructive_mode") == "enabled"));

/* Determine the diskio cookie setting. */
$show_diskio	= isset($_COOKIE['diskio']);

/* Get Unraid version 7 status. */
$unraid_7_plus = version_compare($version['version'], "7.0.0", ">");
	
/* Misc functions. */
class MiscUD
{
	/* Save content to a json file. */
	public static function put_json($file, $content) {
		/* Write the file atomically. */
		$data	= json_encode($content, JSON_PRETTY_PRINT);
		$rc		= atomic_write_file($file, $data);

		return $rc;
	}

	/* Get content from a json file. */
	public static function get_json($file) {
		return file_exists($file) ? @json_decode(file_get_contents($file), true) : [];
	}

	/* Check for a valid IP address. */
	public static function is_ip($str) {
		return filter_var($str, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) !== false;
	}

	/* Check for a valid IPv6 address */
	public static function is_ipv6($str) {
		return filter_var($str, FILTER_VALIDATE_IP, FILTER_FLAG_IPV6) !== false;
	}

	/* Shutdown state file. */
	private static $shutdown_file = "/tmp/unassigned.devices/shut_down";

	/* Set shutdown semaphore. */
	public static function set_shutting_down() {
		@touch(self::$shutdown_file);
	}

	/* Clear shutdown semaphore. */
	public static function clear_shutting_down() {
		@unlink(self::$shutdown_file);
	}

	/* Are we shutting down? */
	public static function shutting_down() {
		return is_file(self::$shutdown_file);
	}

	/* Check for text in a file. */
	public static function exist_in_file($file, $text) {
		$rc	= false;

		/* Validate the file first. */
		if (file_exists($file)) {
			/* Read file content. */
			$fileContent = file_get_contents($file);

			if (($fileContent !== false) && (strpos($fileContent, $text) !== false)) {
				$rc	= true;
			}
		}

		return $rc;
	}

	/* Is the device an nvme disk? */
	public static function is_device_nvme($dev) {
		return (strpos($dev, "nvme") !== false);
	}

	/* Remove the partition number from $dev and return the base device. */
	public static function base_device($dev) {
		/* Base name only (strip /dev/) */
		$rc = $dev;

		/*
		 * Linux device naming rules to handle:
		 *	sda1        ? sda
		 *	vda3        ? vda
		 *	nvme0n1p4   ? nvme0n1
		 *	mmcblk0p2   ? mmcblk0
		 *	dm-0        ? dm-0  (no partitions)
		 *	md126       ? md126 (no partitions)
		 */

		/* NVMe: nvmeXnYpZ ? nvmeXnY */
		if (preg_match('#^(nvme\d+n\d+)p\d+$#', $rc, $m)) {
			$rc = $m[1];
		}

		/* MMC: mmcblkXpY ? mmcblkX */
		else if (preg_match('#^(mmcblk\d+)p\d+$#', $rc, $m)) {
			$rc = $m[1];
		}

		/* SATA/virtio/etc: sdX1, vdX1, xvdX1 ? base */
		else if (preg_match('#^([a-zA-Z]+[a-zA-Z0-9]*)\d+$#', $rc, $m)) {
			$rc = $m[1];
		}

		/*
		 * dm-0, md126, loop0, zram0:
		 * These are base devices themselves.
		 * No action required.
		 */

		return $rc;
	}

	/* Spin disk up or down using Unraid api. */
	public static function spin_disk($down, $dev) {
		if ($down) {
			$timed_cmd	= "/usr/local/sbin/emcmd cmdSpindown=".escapeshellarg($dev);
		} else {
			$timed_cmd	= "/usr/local/sbin/emcmd cmdSpinup=".escapeshellarg($dev);
		}

		timed_exec(5, $timed_cmd, true);
	}

	/* Get array of btrfs pool devices on a mount point. */
	public static function get_pool_devices($mountpoint, $remove = false) {
		global $paths;

		$rc = [];

		/* Get the current pool status. */
		$pool_state	= MiscUD::get_json($paths['pool_state']);

		/* If this mount point is not defined, set it as an empty array. */
		if (in_array($mountpoint, $pool_state, true)) {
			$pool_state[$mountpoint]	= is_array($pool_state[$mountpoint]) ? $pool_state[$mountpoint] : [];
		}

		if (isset($pool_state[$mountpoint])) {
			if ($remove) {
				/* Remove this from the pool devices if unmounting. */
				unset($pool_state[$mountpoint]);
				MiscUD::put_json($paths['pool_state'], $pool_state);
			} else if (is_array($pool_state[$mountpoint]) && (! count($pool_state[$mountpoint]))) {
				/* Get the pool parameters if they are not already defined. */
				unassigned_log("Debug: Get Disk Pool members on mountpoint '".$mountpoint."'.", $GLOBALS['UDEV_DEBUG']);

				/* Get the brfs pool status from the mountpoint. */
				$timed_cmd	= "/sbin/btrfs fi show ".escapeshellarg($mountpoint)." | /bin/grep 'path' | /bin/awk '{print $8}'";
				$s			= timed_exec(3, $timed_cmd, true);
				$rc			= explode("\n", $s);
				$pool_state[$mountpoint] = array_filter($rc);
				MiscUD::put_json($paths['pool_state'], $pool_state);
			} else {
				/* Get the pool status from the pool_state. */
				$rc = $pool_state[$mountpoint];
			}
		}

		return array_filter($rc);
	}

	/* Save the hostX from the DEVPATH so we can re-attach a disk device. */
	public static function save_device_host($serial, $devpath) {
		global $paths;

		$host = "";

		if (preg_match('#/(host[0-9]+)(/|$)#', $devpath, $match)) {
			$host = $match[1];
		}

		if (($host) && ($serial)) {
			$lock_file = get_file_lock("hosts");

			$current = MiscUD::get_json($paths['device_hosts']) ?: [];

			if ((! isset($current[$serial])) || ($current[$serial] !== $host)) {
				$current[$serial] = $host;

				MiscUD::put_json($paths['device_hosts'], $current);
			}

			release_file_lock($lock_file);
		}

		return;
	}

	/* Get the device hostX. */
	public static function get_device_host($serial, $delete = false) {
		global $paths;

		$rc = "";

		$lock_file = get_file_lock("hosts");

		$current = MiscUD::get_json($paths['device_hosts']) ?: [];

		if (isset($current[$serial])) {
			$host = $current[$serial];

			if (is_file("/sys/class/scsi_host/".$host."/scan")) {
				$rc = $host;
			} else {
				unset($current[$serial]);
				MiscUD::put_json($paths['device_hosts'], $current);
			}

			if ($delete && isset($current[$serial])) {
				unset($current[$serial]);
				MiscUD::put_json($paths['device_hosts'], $current);
			}
		}

		release_file_lock($lock_file);

		return $rc;
	}

	/* Set the status of a device for any state - mounting, unmounting, formatting, etc. */
	public static function set_mount_state($device, $state) {
		global $paths;

		/* Map of state => path pattern from $paths */
		$stateFiles = [
			'unmounting'	=> $paths['unmounting'] ?? '',
			'mounting'		=> $paths['mounting'] ?? '',
			'formatting'	=> $paths['formatting'] ?? '',
			'clearing'		=> $paths['clearing'] ?? '',
		];

		$pattern	= $stateFiles[$state] ?? '';
		if ($pattern) {
			/* Generate the full file path */
			$file	= sprintf($pattern, $device, true, true);

			/* Create the status file. */
			@touch($file);

			/* Give things a chance to settle.  This gives the pageRefresh time to catch up. */
			usleep(500 * 1000);
		} else {
			$file	= "";
		}

		return $file;
	}

	/* Get the status of a device for any state - mounting, unmounting, formatting, etc. */
	public static function get_mount_state($device, $state) {
		global $paths;

		$rc = false;

		/* Map of state => path pattern from $paths. */
		$state_files = [
			'unmounting'	=> $paths['unmounting'] ?? '',
			'mounting'		=> $paths['mounting'] ?? '',
			'formatting'	=> $paths['formatting'] ?? '',
			'clearing'		=> $paths['clearing'] ?? '',
		];

		$pattern = $state_files[$state] ?? '';

		if ($pattern) {
			$file = sprintf($pattern, $device, true, true);

			/* A state file is considered valid for 300 seconds.
			   If it's older than that, delete it and treat as inactive. */
			if (file_exists($file)) {
				$age = time() - filemtime($file);

				if ($age >= 300) {
					@unlink($file);
				} else {
					$rc = true;
				}
			}
		}

		return $rc;
	}

	/* Remove the state file - mounting, unmounting, formatting, etc. */
	public static function rem_mount_state($file) {
		@unlink($file);
	}

	/**
	 * Return ZFS pool name for a device, even if already imported (Linux/Unraid compatible)
	 *
	 * @param string $dev Device path (e.g., /dev/sdk1)
	 * @param string $mount_point Optional mount point
	 * @return string Pool name or empty
	 */
	public static function zfs_pool_name($dev, $mount_point = "")
	{
		global $mounts;

		$rc = "";

		/* Use mount info if no device given */
		if (! $dev) {
			if ($mount_point && isset($mounts[$mount_point])) {
				return $mounts[$mount_point]['device'];
			}
			return "";
		}

		/* Ensure ZFS tools are available */
		if (! is_file("/usr/sbin/zpool")) {
			$timed_cmd = "/sbin/modprobe zfs";
			timed_exec(2, $timed_cmd, true);
		}

		if (is_file("/usr/sbin/zpool")) {
			/* Try import scan (for unimported pools) */
			$attempts = 5;
			$count = 0;
			while ($count < $attempts) {
				$timed_cmd = "/usr/sbin/zpool import -d ".escapeshellarg($dev)." 2>/dev/null | /usr/bin/awk '/^  pool: / { print \$2 }'";
				$rc = trim(timed_exec(3, $timed_cmd, true));
				if ($rc) break;
				sleep(1);
				$count++;
			}

			/* Fallback: parse already imported pools via `zpool status` */
			if (! $rc) {
				$status = timed_exec(3, "/usr/sbin/zpool status 2>/dev/null", true);
				if ($status) {
					$lines = explode("\n", $status);
					$pool_name = "";
					$found = false;

					foreach ($lines as $line) {
						$line = trim($line);
						if (! $line) continue;

						/* Detect pool name line */
						if (preg_match('/^pool:\s*(\S+)/', $line, $m)) {
							$pool_name = $m[1];
						}

						/* Check if device exists under current pool */
						if ($pool_name && strpos($line, basename($dev)) !== false) {
							$rc = $pool_name;
							$found = true;

							/* exit this foreach only. */
							break;
						}
					}
				}
			}

			/* Final fallback: use mount info */
			if (! $rc && $mount_point && isset($mounts[$mount_point])) {
				$rc = $mounts[$mount_point]['device'];
			}
		}

		return $rc;
	}

	/* Check if the mount point is accessible. */
	public static function is_mount_accessible($mount_point) {
		$status	= null;

		$cmd	= "/bin/mountpoint -q ".escapeshellarg($mount_point);
		timed_exec(1, $cmd, true, $status);

		return ($status === 0);
	}

	/* Open a luks encrypted device. */
	public static function luks_open_device($dev, $mapper, $pass = "", $allow_discards = false) {
		global $paths;

		$result			= false;
		$output			= "";
		$discard		= "";

		/* Create the proper mapper and mapper device path. */
		$mapper			= basename($mapper);
		$mapper_device	= "/dev/mapper/".$mapper;

		if (($allow_discards) && (is_disk_ssd($dev)) && (get_config("Config", "discard") == "yes")) {
			$discard = "--allow-discards";
		}

		$cmd = "luksOpen ".$discard." ".$dev." ".$mapper;
		if (! $pass) {
			$timed_cmd	= "/usr/local/sbin/emcmd cmdCryptsetup=".escapeshellarg($cmd)." 2>&1";
			$output		= timed_exec(45, $timed_cmd, true);
		} else {
			$luks_pass_file = $paths['luks_pass']."_".$mapper;

			if (file_put_contents($luks_pass_file, $pass) === false) {
				unassigned_log("Failed to write LUKS password to file '".$luks_pass_file."'.");
			} else {
				@chmod($luks_pass_file, 0600);

				unassigned_log("Using disk password to open the 'crypto_LUKS' device.");

				$timed_cmd	= "/sbin/cryptsetup ".$cmd." -d ".escapeshellarg($luks_pass_file)." 2>&1";
				$output		= timed_exec(45, $timed_cmd, true);

				/* Shred the password file. */
				MiscUD::shred_file($luks_pass_file);
			}

			/* Overwrite the password variable, then unset it. */
			$pass = str_repeat("\0", strlen($pass));
			unset($pass);
		}

		/* Verify mapper was actually created. */
		if (file_exists($mapper_device)) {
			$result = true;
		} else {
			if ($output) {
				unassigned_log("luksOpen: ".$output);
			}
		}

		return $result;
	}

	/* Close a luks device. */
	public static function luks_close_device($mapper) {
		$result			= true;
		$mapper			= basename($mapper);
		$mapper_device	= "/dev/mapper/".$mapper;
		$output			= "";
		$tries			= MiscUD::shutting_down() ? 5 : 1;
		$sleep			= MiscUD::shutting_down() ? 2 : 0;

		if (file_exists($mapper_device)) {
			if (! MiscUD::shutting_down()) {
				$cmd		= "luksClose ".$mapper;
				$timed_cmd	= "/usr/local/sbin/emcmd cmdCryptsetup=".escapeshellarg($cmd)." 2>&1";
				$output		= timed_exec(30, $timed_cmd, true);
			}

			for ($i = 1; ($i <= $tries) && file_exists($mapper_device); $i++) {
				$timed_cmd	= "/sbin/cryptsetup luksClose ".escapeshellarg($mapper)." 2>&1";
				$output		= timed_exec(10, $timed_cmd, true);

				if (file_exists($mapper_device) && ($i < $tries)) {
					unassigned_log("luksClose: luks device '".$mapper."' is still busy, retry ".$i." of ".($tries - 1).".");
					sleep($sleep);
				}
			}

			if (file_exists($mapper_device)) {
				unassigned_log("luksClose: luks device '".$mapper."' did not close.");

				if ($output) {
					unassigned_log("luksClose result: ".$output);
				}

				$result = false;
			}
		}

		/* Clear the lsblk file type so it will rediscover the file type of luks. */
		part_fs_type($mapper_device, false, true);

		return $result;
	}

	/* Securely shred a file. */
	public static function shred_file($file) {
		$return_code	= 1;

		if (is_file($file)) {
			$timed_cmd = '/usr/bin/shred -u -n 3 -z '.escapeshellarg($file).' 2>/dev/null';
			timed_exec(0, $timed_cmd, true, $return_code);

			if ($return_code !== 0) {
				unassigned_log("Failed to securely shred the password file '".$file."'.");
			}
		}

		return ($return_code === 0);
	}

	/*	Check if a mounted XFS filesystem is v5.  Returns true if v5, false otherwise. */
	public static function is_xfs_v5($mountpoint) {
		$result	= false;

		/*	Run xfs_info and capture output. */
		$timed_cmd	= "/usr/sbin/xfs_info ".escapeshellarg($mountpoint)." 2>/dev/null";
		$out		= timed_exec(3, $timed_cmd, true);

		/*	If crc=1 appears, it's an XFS v5 filesystem. */
		if (($out) && (preg_match('/crc=1/', $out))) {
			$result = true;
		}

		return $result;
	}

	/* Validate a mount point against known UD mount bases. */
	public static function is_valid_ud_mountpoint($mountpoint) {
		global $paths;

		$rc		= false;
		$bases	= [
			'usb_mountpoint',
			'remote_mountpoint',
			'root_mountpoint'
		];

		if ($mountpoint && ($mountpoint[0] == "/")) {
			foreach ($bases as $base) {
				if (! empty($paths[$base])) {
					$path = rtrim($paths[$base], "/")."/";

					if ((strpos($mountpoint, $path) === 0) && (basename($mountpoint) !== "")) {
						$rc = true;
						break;
					}
				}
			}
		}

		return $rc;
	}

	/* Check if a mount point is in a clean state for mounting. */
	public static function is_mountpoint_clean($mountpoint) {
		$clean = true;

		if (is_dir($mountpoint)) {
			if (is_mounted("", $mountpoint)) {
				unassigned_log("Warning: Mount point '".$mountpoint."' is already mounted!");
				$clean = false;
			} else {
				$items = @scandir($mountpoint);

				if ($items === false) {
					unassigned_log("Warning: Unable to read mount point '".$mountpoint."'!");
					$clean = false;
				} else {
					$items = array_diff($items, [".", ".."]);

					if (! empty($items)) {
						unassigned_log("Warning: Mount point '".$mountpoint."' is not empty! Check for stale files or a misconfigured Docker container or VM writing to an unmounted device path.");
						$clean = false;
					}
				}
			}
		}

		return $clean;
	}
}

/* Adjust configuration parameters that have been renamed or need cleanup. */
function adjust_config_params() {
	global $ud_config, $users;

	/* Mapping of old keys to new keys for SMB/NFS settings. */
	$renames = [
		'smb_security' => 'SMB_Sharing',
		'smb_version'  => 'SMB_Version',
		'nfs_export'   => 'NFS_Export',
		'nfs_security' => 'NFS_Security',
		'nfs_version'  => 'NFS_Version',
	];

	/* Rename configuration keys if they exist. */
	foreach ($renames as $old => $new) {
		if (isset($ud_config['Config'][$old])) {
			$ud_config['Config'][$new] = $ud_config['Config'][$old];
			unset($ud_config['Config'][$old]);
		}
	}

	/* Remove SMB users that are no longer valid. */
	if (($users) && isset($ud_config['Config'])) {
		$valid_users = array_keys((array)$users);

		foreach ($ud_config['Config'] as $key => $value) {
			if (preg_match('/^smb_(.+)$/', $key, $matches)) {
				if (! in_array($matches[1], $valid_users, true)) {
					unset($ud_config['Config'][$key]);
				}
			}
		}
	}

	return;
}

/*
	Run a shell command with an optional timeout and log its duration.

	Parameters:
		$timeout (int|float) - Maximum number of seconds to allow the command to run.
		                       If zero or negative, the command runs without a timeout.
		$cmd (string) - The shell command to execute.
		$silent (bool) - When true, suppresses timing and warning log messages.
		$ret_code (int|null) - Optional reference variable to receive the command's exit code.
		$return_array (bool) - When true, returns the full output as an array of lines.

	Returns:
		string|array - Trimmed command output (string by default), or array if requested.
*/
function timed_exec($timeout, $cmd, $silent = false, &$ret_code = null, $return_array = false) {
	$start		= microtime(true);
	$output		= [];
	$ret		= 0;
	$out		= "";
	$elapsed	= 0.0;
	$exec_cmd	= "";

	/* Build full command with timeout if specified. */
	$exec_cmd = ($timeout > 0)
		? "/usr/bin/timeout ".escapeshellarg($timeout)." ".$cmd
		: $cmd;

	exec($exec_cmd, $output, $ret);

	$ret_code	= $ret;
	$out		= trim(implode("\n", $output));
	$elapsed	= microtime(true) - $start;

	/* Log results unless silent. */
	if (((! $silent) || ($GLOBALS['DEBUG_LEVEL'] == $GLOBALS['CMD_TIMEOUTS'])) && ($timeout > 0)) {
		if ($ret == 124) {
			$out = "command timed out";
			unassigned_log("Warning: shell_exec($cmd) took longer than ".sprintf('%.1f', $timeout)."s!");
		} else {
			unassigned_log("Debug: Timed Exec: shell_exec($cmd) completed in ".sprintf('%.1f', $elapsed)."s, return code: $ret", $GLOBALS['CMD_DEBUG']);
		}
	}

	return $return_array ? $output : $out;
}

/* Atomically write data to a file. */
function atomic_write_file($dest_file, $content) {
	$rc			= true;
	$tmp_file	= null;
	$tmp_dir	= dirname($dest_file);

	/* Create temp file in same directory for atomic rename. */
	$tmp_file = @tempnam($tmp_dir, 'atomic_');
	if ($tmp_file === false) {
		unassigned_log("Failed to create temporary file in $tmp_dir");
		$rc = false;
	}

	/* Write content to temp file. */
	if ($rc) {
		if (@file_put_contents($tmp_file, $content, LOCK_EX) === false) {
			unassigned_log("Failed to write temporary file: $tmp_file");
			$rc = false;
		}
	}

	/* Atomically replace destination file. */
	if ($rc) {
		if (! @rename($tmp_file, $dest_file)) {
			unassigned_log("Failed to rename temporary file to destination: $dest_file");
			$rc = false;
		}
	}

	/* Cleanup temp file on failure. */
	if ((! $rc) && ($tmp_file) && is_file($tmp_file)) {
		@unlink($tmp_file);
	}

	return $rc;
}

/*
	Get a file lock so changes can be made to config and status files.

	Parameters:
		$type (string) - Lock file type suffix.
		$timeout (float) - Lock acquisition timeout in seconds.
			- Greater than zero: wait up to the specified time for the lock.
			- Zero or less: attempt to acquire the lock once and return immediately if busy.

	Returns:
		resource|null
			File handle with an exclusive lock on success.
			Null if the lock could not be acquired or the lock file could not be opened.

	Examples:
		get_file_lock("ini");
			Wait up to 5 seconds (default) for the lock.

		get_file_lock("stats", 10);
			Wait up to 10 seconds for the lock.

		get_file_lock("df_status-MyServer", 0);
			Attempt to acquire the lock once and skip processing if already locked.
*/
function get_file_lock($type = "ini", $timeout = 5.0) {
	global $paths;

	$lock_handle	= null;
	$lock_path		= sprintf($paths['lock_file'], UNASSIGNED_PLUGIN.".".$type);

	$handle = fopen($lock_path, "c");
	if ($handle !== false) {
		$start = microtime(true);

		do {
			if (flock($handle, LOCK_EX | LOCK_NB)) {
				$lock_handle	= $handle;
				$elapsed		= microtime(true) - $start;

				if ($elapsed > 1.0) {
					unassigned_log(sprintf("Debug: Waited %.2f seconds for file lock: %s", $elapsed, $lock_path), $GLOBALS['UPDATE_DEBUG']);
				}

				break;
			}

			usleep(100000);
		} while ((microtime(true) - $start) < $timeout);

		if ($lock_handle === null) {
			unassigned_log("Debug: Timeout acquiring file lock: ".$lock_path, $GLOBALS['UPDATE_DEBUG']);

			/* Lock not acquired. Close the opened file handle. */
			fclose($handle);
		}
	} else {
		unassigned_log("Failed to open lock file: ".$lock_path);
	}

	return $lock_handle;
}

/* Release the file lock. */
function release_file_lock($lock_handle) {
	$rc = true;

	if (is_resource($lock_handle)) {
		flock($lock_handle, LOCK_UN);
		fclose($lock_handle);
	}

	return $rc;
}

/* Save ini and cfg files to tmp file system and then copy cfg file changes to flash. */
function save_ini_file($file, $config, $save_config = true, &$ini_content = null) {
	$rc			= true;
	$res		= [];

	/* Get a lock so file changes can be made. */
	$lock_file		= get_file_lock("ini");

	/* Build INI content. */
	foreach ($config as $key => $val) {
		if (is_array($val)) {
			$res[] = "\n[$key]";
			foreach ($val as $skey => $sval) {
				$res[] = $skey."=".(is_numeric($sval) ? $sval : '"'.$sval.'"');
			}
		} else {
			$res[] = $key."=".(is_numeric($val) ? $val : '"'.$val.'"');
		}
	}

	$ini_content = implode("\n", $res);

	/* Atomically write ini file. */
	$rc		= atomic_write_file($file, $ini_content);

	/* Write cfg file changes back to flash if requested. */
	if ($rc && $save_config) {
		$file_info = pathinfo($file);
		if (($file_info['extension'] ?? '') === 'cfg') {
			$flash_file = UD_FLASH_PATH.basename($file);
			if (@file_put_contents($flash_file, $ini_content, LOCK_EX) === false) {
				unassigned_log("Failed to write cfg file to flash: $flash_file");
				/* Non-fatal */
			}
		}
	}

	/* Release the file lock. */
	release_file_lock($lock_file);

	return $rc;
}

/* Unassigned Devices logging. */
function unassigned_log(mixed $message, int $debug_level = 0) {
	/* Determine if message should be logged */
	if (($debug_level === 0) || ($debug_level === ($GLOBALS['DEBUG_LEVEL'] ?? null))) {
		if (is_scalar($message)) {
			$log = (string)$message;
		} else {
			$log = trim(print_r($message, true));
		}

		/* Normalize message */
		$log = str_replace(["\n", '"'], [' ', "'"], $log);

		/* Build logger command */
		$timed_cmd = "/usr/bin/logger -t ".escapeshellarg(UNASSIGNED_PLUGIN)." ".escapeshellarg($log);

		/* Execute */
		timed_exec(0, $timed_cmd);
	}

	return;
}

/* Return non-directory entries, including symlinks */
function listFile($root) {
	$filesOnly = [];

	/* Validate directory */
	if (! is_dir($root) || !is_readable($root)) {
		return $filesOnly;
	}

	/* scandir() is fastest and gives raw names */
	$entries = scandir($root);
	if (! is_array($entries)) {
		return $filesOnly;
	}

	foreach ($entries as $entry) {
		/* Skip . and .. */
		if ($entry[0] === '.') {
			continue;
		}

		$path = $root.'/'.$entry;

		/* Optimization: check only is_dir() */
		if (! is_dir($path)) {
			$filesOnly[] = $path;
		}
	}

	return $filesOnly;
}

/* Fast check to see if any by-id entry contains the serial. */
function ud_serial_exists($serial) {
	$rc		= false;
	$list	= @scandir('/dev/disk/by-id');

	if (is_array($list)) {
		foreach ($list as $entry) {
			if ($entry[0] === '.') {
				continue;
			}

			if (strpos($entry, $serial) !== false) {
				$rc = true;
				break;
			}
		}
	}

	return $rc;
}

/* Remove characters that will cause issues with PHP or filenames. */
function safe_name($name, $convert_spaces = true, $convert_extra = false) {
	/* Trim spaces from the name. */
	$name	= trim($name);

	/* Decode HTML entities and remove control characters */
	$string = html_entity_decode($name, ENT_QUOTES, 'UTF-8');
	$string = preg_replace('/[\p{C}]+/u', '', stripcslashes($string));

	/* Base set of unsafe ASCII characters */
	$unsafe = ["'", '"', "?", "#", "&", "!", "<", ">", "[", "]", "{", "}", "|", "+", "@"];

	/* Optionally add extra characters */
	if ($convert_extra) {
		$unsafe = array_merge($unsafe, ["(", ")"]);
	}

	/* Optionally convert spaces */
	if ($convert_spaces) {
		$unsafe[] = " ";
	}

	/* Replace unsafe ASCII characters with underscore */
	$pattern = '/['.preg_quote(implode('', $unsafe), '/').']/u';
	$string = preg_replace($pattern, '_', $string);

	/* Replace problematic Unicode ranges (e.g., ideographic spaces, control-like symbols) */
	$string = preg_replace('/[\x{2000}-\x{206F}\x{3000}]/u', '_', $string);

	return trim($string);
}

/* Get the size, used, and free space on a mount point */
function get_device_stats($mountpoint, $mounted, $active = true, $file_system = "") {
	global $paths;

	/* Default return: size, used, free */
	$stats		= [0, 0, 0];
	$df_file	= $paths['df_status'];

	static $df_cache = [];
	static $df_mtime = 0;

	if ($mounted) {
		$mtime = is_file($df_file) ? filemtime($df_file) : 0;

		/* Load or reload JSON if file changed */
		if (! isset($df_cache[$df_file]) || $df_mtime !== $mtime) {
			$df_cache[$df_file] = MiscUD::get_json($df_file);
			$df_mtime = $mtime;
		}

		/* Initialize mountpoint entry if missing */
		$df_cache[$df_file][$mountpoint]['timestamp'] = $df_cache[$df_file][$mountpoint]['timestamp'] ?? 0;

		/* Update stats every 90 seconds if active */
		if ($active && (time() - $df_cache[$df_file][$mountpoint]['timestamp']) > 90) {
			$timed_cmd = DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/get_ud_stats df_status "
				. escapeshellarg($mountpoint)." "
				. escapeshellarg($file_system)." "
				. escapeshellarg($GLOBALS['DEBUG_LEVEL'])." &";
			timed_exec(0, $timed_cmd, true);
		}

		/* Use cached stats if available */
		$cached_stats	= $df_cache[$df_file][$mountpoint]['stats'] ?? "";
		if ($cached_stats) {
			$values = preg_split('/\s+/', trim($cached_stats));
			$stats[0] = intval($values[0] ?? 0);
			$stats[1] = intval($values[1] ?? 0);
			$stats[2] = intval($values[2] ?? 0);
		}
	}

	return $stats;
}

/* Get cached devs.ini state. */
function get_dev_state() {
	global $paths;

	static $devs_cache = null;
	static $devs_mtime = 0;

	$ini_file = $paths['dev_state'];

	if (is_file($ini_file)) {
		$mtime = filemtime($ini_file) ?: 0;

		if (($devs_cache === null) || ($mtime !== $devs_mtime)) {
			$devs_cache = @parse_ini_file($ini_file, true) ?: [];
			$devs_mtime = $mtime;
		}
	} else {
		$devs_cache = [];
		$devs_mtime = 0;
	}

	return $devs_cache;
}

/* Get the devX designation for this device from the devs.ini. */
function get_disk_dev($dev) {
	$device_name	= basename($dev);
	$devX			= $device_name;
	$devs			= get_dev_state();

	/* Search for matching device. */
	foreach ($devs as $entry) {
		if (isset($entry['device'], $entry['name']) && ($entry['device'] === $device_name) && ($entry['name'] !== "")) {
			$devX = $entry['name'];
			break;
		}
	}

	return $devX;
}

/* Get the disk id for this device from the devs.ini. */
function get_disk_id($dev, $udev_id) {
	$device	= MiscUD::base_device(basename($dev));
	$id		= $udev_id;
	$devs	= get_dev_state();

	/* Search for matching device. */
	foreach ($devs as $entry) {
		if (isset($entry['device'], $entry['id']) && ($entry['device'] === $device) && ($entry['id'] !== "")) {
			$id = $entry['id'];
			break;
		}
	}

	return safe_name($id);
}

/* Get cached diskload.ini state. */
function get_disk_load() {
	global $paths;

	static $disk_io_cache = null;
	static $disk_io_mtime = 0;

	$ini_file = $paths['disk_load'];

	if (is_file($ini_file)) {
		$mtime = filemtime($ini_file) ?: 0;

		if (($disk_io_cache === null) || ($mtime !== $disk_io_mtime)) {
			$disk_io_cache = @parse_ini_file($ini_file) ?: [];
			$disk_io_mtime = $mtime;
		}
	} else {
		$disk_io_cache = [];
		$disk_io_mtime = 0;
	}

	return $disk_io_cache;
}

/* Get the reads and writes from diskload.ini. */
function get_disk_reads_writes($ud_dev, $dev) {
	$rc			= [0, 0, 0, 0];
	$base_dev	= MiscUD::base_device(basename($dev));

	$devs = get_dev_state();

	if (isset($devs[$ud_dev])) {
		$rc[0] = intval($devs[$ud_dev]['numReads'] ?? 0);
		$rc[1] = intval($devs[$ud_dev]['numWrites'] ?? 0);
	}

	$disk_io = get_disk_load();

	$data = preg_split('/\s+/', trim($disk_io[$base_dev] ?? '0 0 0 0'));
	$data = array_pad($data, 4, 0);

	$rc[2] = max(0, intval($data[0]));
	$rc[3] = max(0, intval($data[1]));

	return $rc;
}

/* Check to see if the disk is spun up or down. */
function is_disk_spinning($ud_dev) {
	global $paths;

	$rc			= false;
	$tc			= $paths['run_status'];
	$device		= null;
	$timestamp	= 0;
	$do_write	= false;

	static $run_cache = null;
	static $run_mtime = 0;

	$devs = get_dev_state();

	if (isset($devs[$ud_dev])) {
		$rc			= (($devs[$ud_dev]['spundown'] ?? "1") == "0");
		$device		= $ud_dev;
		$timestamp	= time();
	}

	/* Get the current run status file mtime. */
	$mtime = is_file($tc) ? filemtime($tc) : 0;

	/* Get the current run status. */
	if (($run_cache === null) || ($mtime !== $run_mtime)) {
		$run_cache = MiscUD::get_json($tc) ?: [];
		$run_mtime = $mtime;
	}

	if (isset($device)) {
		/* Update the spin status. */
		$spin		= $run_cache[$device]['spin'] ?? "";
		$spin_time	= $run_cache[$device]['spin_time'] ?? 0;

		$new = [
			'timestamp'	=> $timestamp,
			'running'	=> $rc ? "yes" : "no",
			'spin_time'	=> $spin_time,
			'spin'		=> $spin
		];

		$old = $run_cache[$device] ?? null;

		if (($old === null) ||
			(($old['running'] ?? null) !== $new['running']) ||
			(($old['spin_time'] ?? null) !== $new['spin_time']) ||
			(($old['spin'] ?? null) !== $new['spin'])) {
			$run_cache[$device] = $new;
			$do_write = true;
		}
	}

	if ($do_write) {
		MiscUD::put_json($tc, $run_cache);
	}

	return $rc;
}

/* Check for disk in the process of spinning up or down */
function is_disk_spin($ud_dev, $running) {
	global $paths;

	$rc  = false;
	$tc  = $paths['run_status'];

	static $run_cache  = null;
	static $run_mtime  = 0;

	/* Load run_status JSON with caching */
	if (is_file($tc)) {
		$mtime = filemtime($tc) ?: 0;
		if ($run_cache === null || $mtime !== $run_mtime) {
			$run_cache = MiscUD::get_json($tc);
			$run_mtime = $mtime;
		}

		if (isset($run_cache[$ud_dev]['spin'])) {
			$spin      = $run_cache[$ud_dev]['spin'];
			$spin_time = $run_cache[$ud_dev]['spin_time'] ?? 0;
			$elapsed   = time() - $spin_time;

			switch ($spin) {
				case "up":
					if (! $running && $elapsed < 15) $rc = true;
					break;

				case "down":
					if ($running && $elapsed < 15) $rc = true;
					break;
			}

			/* Clear spin status if elapsed or no longer spinning */
			if (! $rc && $spin) {
				$run_cache[$ud_dev]['spin']      = "";
				$run_cache[$ud_dev]['spin_time'] = 0;
				MiscUD::put_json($tc, $run_cache);
			}
		}
	}

	return $rc;
}

/* Check that a requested NFS export path still exists on the remote server. */
function check_remote_nfs_path($server, $export_path, $clear = false) {
	global $paths;

	$result = false;

	/* Get the NFS remote paths JSON file */
	$df       		= $paths['nfs_remote_paths'];
	$nfs_paths		= MiscUD::get_json($df);
	$original_paths	= $nfs_paths[$server]['paths'] ?? [];
	$original_time	= $nfs_paths[$server]['timestamp'] ?? 0;
	$now			= time();

	/* Clear the array if requested */
	if ($clear) {
		$nfs_paths = [];
		MiscUD::put_json($df, $nfs_paths);
	} else {
		/* Ensure server key exists */
		if (! isset($nfs_paths[$server])) {
			$nfs_paths[$server] = [
				'paths'     => [],
				'timestamp' => 0
			];
		}

		/* If paths are fresh and export_path exists, return immediately */
		if (($now - $original_time < 300) && in_array($export_path, $nfs_paths[$server]['paths'], true)) {
			$result = true;
		} else {
			/* Get remote NFS exports */
			$timed_cmd = "/usr/sbin/showmount -e ".escapeshellarg($server)." 2>/dev/null";
			$output    = timed_exec(3, $timed_cmd, true);

			if ($output !== '') {
				$lines = explode("\n", trim($output));
				array_shift($lines); /* remove header */

				foreach ($lines as $line) {
					$line = trim($line);
					if ($line === '') continue;

					/* Split line into words to handle spaces in path */
					$parts         = preg_split('/\s+/', $line);

					/* last element is client list */
					$clients       = array_pop($parts);

					/* join rest as export path */
					$remote_export = implode(' ', $parts);

					/* Add export to array if not already present */
					if (! in_array($remote_export, $nfs_paths[$server]['paths'], true)) {
						$nfs_paths[$server]['paths'][] = $remote_export;
					}

					/* Compare against requested export_path */
					if (strcasecmp($remote_export, $export_path) === 0) {
						$result = true;
					}
				}

				/* Update timestamp */
				$nfs_paths[$server]['timestamp'] = $now;

				/* Save updated NFS paths if there has been a change */
				if ($nfs_paths[$server]['paths'] !== $original_paths || $nfs_paths[$server]['timestamp'] !== $original_time) {
					MiscUD::put_json($df, $nfs_paths);
				}
			}
		}
	}

	return $result;
}

/* Check to see if a remote server is online by chccking the online status. */
function is_samba_server_online($ip, $protocol) {
	global $paths;

	$is_alive		= false;

	/* Get the updated online status. */
	$tc				= $paths['ping_status'];
	$ping_status	= MiscUD::get_json($tc);
	$name			= $ip.".".$protocol;
	if (isset($ping_status[$name])) {
		$is_alive = ($ping_status[$name]['online'] == "yes");
	}

	return $is_alive;
}

/* See if the pgid is currently running. */
function is_pid_running($pgid) {
	$ret_code	= 1;
	$rc			= false;

	if ($pgid > 0) {
		if (function_exists('posix_kill')) {
			return @posix_kill($pgid, 0);
		} else {
			$timed_cmd	= "/bin/kill -0 ".$pgid." 2>/dev/null";
			timed_exec(0, $timed_cmd, true, $ret_code);
			$rc	= ($ret_code === 0);
		}
	}

	return $rc;
}

/* Check to see if a mount/unmount device script or user script is running. */
function is_script_running($cmd, $user = false) {
	global $paths;

	$is_running = false;

	if ($cmd) {
		if ($user) {
			/* $cmd points to script inside folder. */
			$script_name	= basename(dirname($cmd));
			$running_path	= $paths['user_running'];
		} else {
			$script_name	= basename($cmd);
			$running_path	= $paths['script_running'];
		}

		$running_file = $running_path.$script_name;

		if (is_file($running_file)) {
			$pgid		= (int)trim((string)@file_get_contents($running_file));
			$is_running	= is_pid_running($pgid);

			/* Remove stale running file. */
			if (! $is_running) {
				@unlink($running_file);
			}
		}
	}

	return $is_running;
}

/* Check to see if a device is preclearing. */
function is_preclear_running($device) {
	global $Preclear;

	$is_preclearing	= false;
	$base_device	= basename($device);

	if ($Preclear) {
		$is_preclearing = $Preclear->isRunning($base_device);

		if (! $is_preclearing) {
			$timed_cmd		= "/usr/bin/pgrep -af ".escapeshellarg("preclear");
			$output			= timed_exec(2, $timed_cmd, true);
			$is_preclearing	= (bool)preg_match('/(^|\s)'.preg_quote($device, '/').'(\s|$)/', $output);
		}
	}

	return $is_preclearing;
}

/* Get disk temperature. */
function get_temp($ud_dev, $spinning) {
	$rc = "*";

	if ($spinning) {
		$devs = get_dev_state();
		$rc = $devs[$ud_dev]['temp'] ?? "*";
	}

	return $rc;
}

/* Restart the recycle bin to adjust for the UD changes. */
function run_recycle_bin($enable, $share_name) {
	/* If the recycle bin plugin is installed, reload the inotify process. */
	$recycle_script = DOCROOT."/plugins/recycle.bin/scripts/rc.recycle.bin";
	if (((is_executable($recycle_script)) && (is_file("/var/run/recycle.bin.pid")))) {
		if ($enable) {
			unassigned_log("Enabling the Recycle Bin on share '".$share_name."'.");
		} else {
			unassigned_log("Removing the Recycle Bin from share '".$share_name."'.");
		}

		/* Restart the recycle bin inotify to pick up the new share. */
		$timed_cmd	= "$recycle_script reload 1>/dev/null &";
		timed_exec(0, $timed_cmd);
	}
}

/* Restart the file activity plugin if it is running to pick up changes in the UD mounts. */
function run_file_activity() {
	/* If the file activity plugin is installed, restart to pick up UD changes. */
	$file_activity_script = DOCROOT."/plugins/file.activity/scripts/rc.file.activity";
	if (((is_executable($file_activity_script)) && (is_file("/var/run/file.activity.pid")))) {
		/* Restart the file activity to pick up UD changes. */
		$timed_cmd	= "$file_activity_script reload 1>/dev/null";
		timed_exec(0, $timed_cmd);
	}
}

/* Check ZFS attributes for a mounted UD disk (read-only) and return indicator string.
	Indicators (stable tokens):
	- ACL_OFF
	- ACL_NFSV4
	- XATTR_OFF
	- POOL_LEGACY
	- CASE_MIXED
*/
function ud_zfs_indicator($mount_point, $pool_name) {
	$indicator	= '';
	$dataset	= '';
	$indicators	= [];

	$acltype	= '';
	$xattr		= '';
	$case		= '';
	$feature	= '';

	$ok = true;

	do {
		/* Pool name should always be provided by UD. */
		if ($pool_name === '') {
			unassigned_log("Warning: Pool name not provided when checking ZFS attributes");
			$ok = false;
			break;
		}

		/* Validate mount point. */
		if ($mount_point === '' || !is_dir($mount_point)) {
			$ok = false;
			break;
		}

		/* Find dataset by mountpoint (tab-separated output is whitespace-safe). */
		$timed_cmd	= "/usr/sbin/zfs list -H -o name,mountpoint";
		$list		= timed_exec(2, $timed_cmd, true);

		if (!is_string($list) || $list === '') {
			$ok = false;
			break;
		}

		foreach (explode("\n", trim($list)) as $line) {
			$line = rtrim($line, "\r");
			if ($line === '') {
				continue;
			}

			$parts = explode("\t", $line);
			if (count($parts) !== 2) {
				continue;
			}

			if ($parts[1] === $mount_point) {
				$dataset = $parts[0];
				break;
			}
		}

		if ($dataset === '') {
			$ok = false;
			break;
		}

		/* Read dataset properties (cheap, read-only). */
		$timed_cmd	= "/usr/sbin/zfs get -H -o value acltype ".escapeshellarg($dataset);
		$acltype	= timed_exec(2, $timed_cmd, true);

		$timed_cmd	= "/usr/sbin/zfs get -H -o value xattr ".escapeshellarg($dataset);
		$xattr		= timed_exec(2, $timed_cmd, true);

		$timed_cmd	= "/usr/sbin/zfs get -H -o value casesensitivity ".escapeshellarg($dataset);
		$case		= timed_exec(2, $timed_cmd, true);

		$acltype = is_string($acltype) ? trim($acltype) : '';
		$xattr	 = is_string($xattr)   ? trim($xattr)   : '';
		$case	 = is_string($case)    ? trim($case)    : '';

		/* ACL indicators. */
		if ($acltype === '' || $acltype === '-' || $acltype === 'off') {
			$indicators[] = 'ACL_OFF';
			unassigned_log("Warning: ZFS attribute issue on '".$mount_point."': acltype='{$acltype}'");
		} elseif ($acltype === 'nfsv4') {
			$indicators[] = 'ACL_NFSV4';
			unassigned_log("Warning: ZFS attribute issue on '".$mount_point."': acltype='nfsv4'");
		}

		/* XATTR indicator. */
		if ($xattr === '' || $xattr === '-' || $xattr === 'off') {
			$indicators[] = 'XATTR_OFF';
			unassigned_log("Warning: ZFS attribute issue on '".$mount_point."': xattr='{$xattr}'");
		}

		/* Case sensitivity indicator (only non-default). */
		if ($case === 'mixed' || $case === 'insensitive') {
			$indicators[] = 'CASE_MIXED';
			unassigned_log("Warning: ZFS attribute issue on '".$mount_point."': casesensitivity='{$case}'");
		}

		/* Legacy pool detection (fast discriminant). */
		$timed_cmd	= "/usr/sbin/zpool get -H -o value feature@async_destroy ".escapeshellarg($pool_name);
		$feature	= timed_exec(2, $timed_cmd, true);
		$feature	= is_string($feature) ? trim($feature) : '';

		if ($feature === '' || $feature === '-' || $feature === 'unsupported') {
			$indicators[] = 'POOL_LEGACY';
			unassigned_log("Warning: ZFS attribute issue on '".$mount_point."': pool='{$pool_name}' appears legacy (feature@async_destroy='{$feature}')");
		}

		/* Return minimal indicator string. */
		if ($indicators) {
			$indicator = implode('|', $indicators);
		}
	} while (false);

	return $indicator;
}

/* Get the format command based on file system to be formatted. */
function get_format_cmd($dev, $fs, $pool_name) {
	/* Strip optional -encrypted suffix */
	$fs = preg_replace('/-encrypted$/', '', $fs);

	switch ($fs) {
		case 'xfs':
			$rc = "/sbin/mkfs.xfs -f ".escapeshellarg($dev)." 2>&1";
			break;

		case 'btrfs':
			$rc = "/sbin/mkfs.btrfs -f ".escapeshellarg($dev)." 2>&1";
			break;

		case 'zfs':
			$rc = "/usr/sbin/zpool create -o ashift=12 -f ".escapeshellarg($pool_name)." ".escapeshellarg($dev)." 2>&1";
			break;

		case 'ext4':
			$rc = "mkfs.ext4 -m 0 ".escapeshellarg($dev)." 2>&1";
			break;

		case 'ntfs':
			$rc = "/sbin/mkfs.ntfs -Q ".escapeshellarg($dev)." 2>&1";
			break;

		case 'exfat':
			$rc = "/usr/local/sbin/ud-exfat/mkfs.exfat ".escapeshellarg($dev)." 2>&1";
			break;

		case 'fat32':
			$rc = "/sbin/mkfs.fat -s 8 -F 32 ".escapeshellarg($dev)." 2>&1";
			break;

		default:
			$rc = false;
			break;
	}

	return $rc;
}

/* Format a disk. */
function format_disk($dev, $fs, $pass, $pool_name) {
	global $paths;

	unassigned_log("Formatting device '".$dev."'.");
	$rc	= true;

	/* Make sure it doesn't have any partitions. */
	foreach (get_all_disks_info() as $d) {
		if ($d['device'] == $dev && count($d['partitions'])) {
			unassigned_log("Aborting format: disk '".$dev."' has '".count($d['partitions'])."' partition(s).");
			$rc = false;
		}
	}

	if ($rc) {
		/* Get the disk blocks and set either gpt or mbr partition schema based on disk size. */
		$max_mbr_blocks	= hexdec("0xFFFFFFFF");
		$timed_cmd		= "/sbin/blockdev --getsz ".escapeshellarg($dev)." 2>/dev/null | /bin/awk '{ print $1 }'";
		$disk_blocks	= intval(timed_exec(3, $timed_cmd, true));
		$disk_schema	= ( $disk_blocks >= $max_mbr_blocks ) ? "gpt" : "msdos";
		$parted_fs		= ($fs == "exfat") ? "fat32" : $fs;

		/* Clear the partition table. */
		unassigned_log("Clearing partition table of disk '".$dev."'.");
		$timed_cmd	= "/usr/bin/dd if=/dev/zero of=".escapeshellarg($dev)." bs=2M count=1 2>&1";
		$o			= timed_exec(10, $timed_cmd, true);
		if ($o) {
			unassigned_log("Clear partition result:\n".$o);
		}

		/* Reload the partition table. */
		if (! reload_partition_table($dev)) {
			return false;
		}

		/* Get partition designation based on type of device. */
		$device	= get_partition_designation($dev);

		/* Determine encryption state */
		$is_encrypted = str_contains($fs, '-encrypted');

		/* Normalize filesystem type */
		$fs_base = preg_replace('/-encrypted$/', '', $fs);

		/* Create partition if encrypted or filesystem requires it */
		if ($is_encrypted || in_array($fs_base, UNRAID_COMPATIBLE_FS, true)) {
			/* Load zfs modules if needed */
			if ($fs === "zfs" || $fs === "zfs-encrypted") {
				$cmd = "/sbin/modprobe zfs";
				timed_exec(0, $cmd, true);
			}

			/* Identify SSD for legacy MBR alignment */
			$is_ssd = is_disk_ssd($dev);
			$result = false;

			unassigned_log("Creating Unraid compatible gpt partition on disk '".$dev."'.");

			/* Wipe existing table */
			$cmd = "/sbin/sgdisk -Z ".escapeshellarg($dev);
			timed_exec(30, $cmd, true);

			/* New GPT */
			$cmd = "/sbin/sgdisk -o ".escapeshellarg($dev);
			timed_exec(30, $cmd, true);

			/* Always 1MiB alignment for GPT */
			$cmd = "/sbin/sgdisk -n 1:2048:0 ".escapeshellarg($dev);
			timed_exec(30, $cmd, true);

			/* Partition type: 8300 normal, 8309 LUKS */
			$type = $is_encrypted ? "8309" : "8300";
			$cmd = "/sbin/sgdisk -t 1:{$type} ".escapeshellarg($dev);
			$o   = timed_exec(30, $cmd, true);

			if ($o) {
				unassigned_log("GPT partitioning result:\n".$o);
			}

			/* Log GPT particulars */
			$disk_size = trim(shell_exec("blockdev --getsize64 ".escapeshellarg($dev)));  /* bytes */
			$part_info = shell_exec("sgdisk -p ".escapeshellarg($dev));

			/* Extract partition start/end sectors */
			if (preg_match('/^\s*1\s+(\d+)\s+(\d+)/m', $part_info, $matches)) {
				$start_sector = $matches[1];
				$end_sector   = $matches[2];
				$alignment    = $start_sector % 2048 === 0 ? "1MiB" : "Other";
			} else {
				$start_sector = $end_sector = $alignment = "unknown";
			}

			/* Get GPT partition GUID code */
			$part_type_raw = trim(shell_exec("sgdisk -i 1 ".escapeshellarg($dev)." | awk -F': ' '/Partition GUID code/ {print \$2}'"));

			/* Extract the GUID only (ignore human-readable part in parentheses) */
			if (preg_match('/^([0-9A-Fa-f-]{36})/', $part_type_raw, $matches)) {

			/* lowercase for mapping */
				$guid = strtolower($matches[1]);
			} else {
				$guid = '';
			}

			/* Map known GUIDs to human-readable types */
			$guid_map = [
				'0fc63daf-8483-4772-8e79-3d69d8477de4' => 'Linux filesystem (8300)',
				'ca7d7ccb-63ed-4c53-861c-1742536059cc' => 'Linux LUKS (8309)',
			];

			$part_type = $guid_map[$guid] ?? 'Linux filesystem (unknown)';

			/* Helper to convert bytes to human-readable format */
			$human_readable_size = function($bytes, $decimals = 2) {
				$units	= ['B', 'KiB', 'MiB', 'GiB', 'TiB', 'PiB'];
				$factor	= floor((strlen((string)$bytes) - 1) / 3);
				$rc		= sprintf("%.{$decimals}f %s", $bytes / pow(1024, $factor), $units[$factor]);

				return $rc;
			};

			/* Convert disk size */
			$disk_size_hr = $human_readable_size($disk_size);

			/* Log everything */
			unassigned_log("GPT Details for '".$dev."': Disk size: ".$disk_size_hr." Partition 1: Start sector: ".$start_sector.", End sector: ".$end_sector.", Type: ".$part_type.", Alignment: ".$alignment);
		} else {
			/* If the file system is fat32, the disk_schema is msdos. */
			$disk_schema = ($fs == "fat32") ? "msdos" : "gpt";

			/* All other file system partitions are gpt, except fat32. */
			unassigned_log("Creating a '".$disk_schema."' partition table on disk '".$dev."'.");
			$timed_cmd	= "/usr/sbin/parted ".escapeshellarg($dev)." --script -- mklabel ".escapeshellarg($disk_schema)." 2>&1";
			$o			= timed_exec(30, $timed_cmd, true);
			if ($o) {
				unassigned_log("Create '".$disk_schema."' partition table result:\n".$o);
			}

			/* Create an optimal disk partition. */
			$timed_cmd	= "/usr/sbin/parted -a optimal ".escapeshellarg($dev)." --script -- mkpart primary ".escapeshellarg($parted_fs)." 0% 100% 2>&1";
			$o			= timed_exec(30, $timed_cmd, true);
			if ($o) {
				unassigned_log("Create primary partition result:\n".$o);
			}
		}

		/* Reload the partition table. */
		if (! reload_partition_table($dev)) {
			$rc	= false;
		}

		unassigned_log("Format device '".$dev."' with '".$fs."' filesystem.");

		/* Format the disk. */
		if (($rc) && (strpos($fs, "-encrypted") !== false)) {
			/* Command time out when formatting a disk. */
			$luks_format_timeout = 120;

			/* Which luks format is desired. */
			$luks_volume	= get_config("Config", "luks_volume");
			$luks_volume	= $luks_volume ? $luks_volume : "luks2";
			$cmd			= "luksFormat --type ".$luks_volume." ".$device;

			/* Use a disk password, or Unraid's. */
			if (! $pass) {
				$timed_cmd		= "/usr/local/sbin/emcmd cmdCryptsetup=".escapeshellarg($cmd)." 2>&1";
				$o				= timed_exec($luks_format_timeout, $timed_cmd, true);
			} else {
				$luks			= basename($dev);
				$luks_pass_file	= $paths['luks_pass']."_".$luks;
				if (file_put_contents($luks_pass_file, $pass) === false) {
					unassigned_log("Failed to write LUKS password to file '".$luks_pass_file."'.");
					return false;
				}
				/* Set permissions on password file. */
				@chmod($luks_pass_file, 0600);
				$timed_cmd		= "/sbin/cryptsetup $cmd -d ".escapeshellarg($luks_pass_file)." 2>&1";
				$o				= timed_exec($luks_format_timeout, $timed_cmd, true);

				/* Shred the password file. */
				MiscUD::shred_file($luks_pass_file);
			}

			if ($o) {
				unassigned_log("luksFormat error: ".$o);
				$rc = false;
			} else {
				$mapper	= "format_".basename($dev);

				/* Use a disk password, or Unraid's. */
				if (! MiscUD::luks_open_device($device, $mapper, $pass)) {
					$rc = false;
				} else {
					/* Format the disk. */
					$rc	= format_disk_with_cmd("/dev/mapper/".$mapper, $fs, $pool_name);

					/* If the format was successful. */
					if (($rc) && ($fs == "zfs-encrypted") && ($pool_name)) {
						/* Set acltype. */
						$timed_cmd	= "/usr/sbin/zfs set acltype=posixacl ".escapeshellarg($pool_name)." 2>/dev/null";
						timed_exec(2, $timed_cmd, true);

						/* Set xattr. */
						$timed_cmd	= "/usr/sbin/zfs set xattr=sa ".escapeshellarg($pool_name)." 2>/dev/null";
						timed_exec(2, $timed_cmd, true);

						/* Export the pool. */
						$timed_cmd	= "/usr/sbin/zpool export ".escapeshellarg($pool_name)." 2>/dev/null";
						timed_exec(3, $timed_cmd, true);
						sleep(1);
					}

					/* Close the luks device. */
					MiscUD::luks_close_device($mapper);
				}
			}
		} else {
			/* Format the disk. */
			$rc	= format_disk_with_cmd($device, $fs, $pool_name);

			/* If the format was successful. */
			if (($rc) && ($fs == "zfs") && ($pool_name)) {
				/* Set acltype. */
				$timed_cmd	= "/usr/sbin/zfs set acltype=posixacl ".escapeshellarg($pool_name)." 2>/dev/null";
				timed_exec(2, $timed_cmd, true);

				/* Set xattr. */
				$timed_cmd	= "/usr/sbin/zfs set xattr=sa ".escapeshellarg($pool_name)." 2>/dev/null";
				timed_exec(2, $timed_cmd, true);

				/* Export the pool. */
				$timed_cmd	= "/usr/sbin/zpool export ".escapeshellarg($pool_name)." 2>/dev/null";
				timed_exec(3, $timed_cmd, true);
				sleep(1);
			}
		}

		/* Reload the partition table. */
		if (! reload_partition_table($dev)) {
			$rc	= false;
		}

		/* Finish up the format. */
		if ($rc) {
			/* Clear the $pass variable. */
			unset($pass);

			/* Clear any existing zfs pool information onthe disk. */
			if (($fs != "zfs") && ($fs != "zfs-encrypted")) {
				sleep(1);

				/* See if there is a zpool signature on the disk. */
				$old_pool_name	= MiscUD::zfs_pool_name($dev);
				if ($old_pool_name) {
					/* Remove zpool label info. */
					$timed_cmd	= "/usr/sbin/zpool labelclear -f ".escapeshellarg($dev);
					timed_exec(3, $timed_cmd, true);

					sleep(1);

					unassigned_log("Format failed, zpool signature found on device '".$dev."'!  Clear the disk and try again.");
					$rc		= false;
				}

				$old_pool_name	= MiscUD::zfs_pool_name($device);
				if ($old_pool_name) {
					/* Remove zpool label info. */
					$timed_cmd	= "/usr/sbin/zpool labelclear -f ".escapeshellarg($device);
					timed_exec(3, $timed_cmd, true);

					sleep(1);

					unassigned_log("Format failed, zpool signature found on device partition '".$device."'!  Clear the disk and try again.");
					$rc		= false;
				}

				/* Refresh partition if there was a zfs pool issue. */
				if (! $rc) {
					/* Refresh partition information. */
					reload_partition_table($dev);
				}
			}
		}
	}

	/* Immediately update Unraid device state. */
	apply_hotplug_now();


	return $rc;
}

/* Get the partition designation for nvme or regular devices. */
function get_partition_designation($dev) {
	return MiscUD::is_device_nvme($dev) ? $dev."p1" : $dev."1";
}

/* Format the disk command. */
function format_disk_with_cmd($device, $fs, $pool_name) {
	$rc	= true;

	$return_code	= null;
	$cmd			= get_format_cmd($device, $fs, $pool_name);

	unassigned_log("Format command: ".$cmd);
	if ($cmd) {
		$out	= timed_exec(300, $cmd, true, $return_code, true);
		if ($return_code) {
			unassigned_log("Format failed:\n".implode(PHP_EOL, $out));
			$rc	= false;
		} else {
			sleep(1);
		}
	} else {
		$rc	= false;
	}

	return $rc;
}

/* Reload the partition table and ensure udev processes events properly. */
function reload_partition_table($dev) {
	/* Always use a single exit point. */
	$rc				= false;
	$return_code	= null;
	$attempt		= 0;
	$max_attempts	= 3;
	$sysname		= basename($dev);
	$is_nvme		= MiscUD::is_device_nvme($dev);

	/* Let the system settle after format. */
	sleep(3);

	/* Retry the full reload sequence a few times. */
	while ((! $rc) && ($attempt < $max_attempts)) {
		$attempt++;

		/* Let kernel/udev settle before each attempt. */
		if (is_executable("/sbin/udevadm")) {
			$cmd = "/sbin/udevadm settle --timeout=5 2>&1";
			timed_exec(7, $cmd, true, $return_code);
		}

		/* Attempt partprobe first. */
		if ((! $rc) && is_executable("/usr/sbin/partprobe")) {
			$cmd = "/usr/sbin/partprobe ".escapeshellarg($dev)." 2>&1";
			timed_exec(10, $cmd, true, $return_code);
			if ($return_code === 0) {
				unassigned_log("Successfully reloaded partition table on device '".$dev."' with partprobe.");
				$rc = true;
			}
		}

		/* Fallback to hdparm for non-NVMe devices. */
		if ((! $rc) && (! $is_nvme) && is_executable("/usr/sbin/hdparm")) {
			$cmd = "/usr/sbin/hdparm -z ".escapeshellarg($dev)." 2>&1";
			timed_exec(10, $cmd, true, $return_code);
			if ($return_code === 0) {
				unassigned_log("Successfully reloaded partition table on device '".$dev."' with hdparm.");
				$rc = true;
			}
		}

		/* Fallback to blockdev. */
		if ((! $rc) && is_executable("/sbin/blockdev")) {
			$cmd = "/sbin/blockdev --rereadpt ".escapeshellarg($dev)." 2>&1";
			timed_exec(10, $cmd, true, $return_code);
			if ($return_code === 0) {
				unassigned_log("Successfully reloaded partition table on device '".$dev."' with blockdev.");
				$rc = true;
			}
		}

		/* If any method succeeded, trigger udev updates and wait for completion. */
		if ($rc) {
			if (is_executable("/sbin/udevadm")) {
				/* Force udev to emit change events for the device. */
				$cmd = "/sbin/udevadm trigger --action=change --subsystem-match=block --sysname-match=".escapeshellarg($sysname)." 2>&1";
				timed_exec(7, $cmd, true, $return_code);

				/* Wait for udev to finish handling the new partition table. */
				$cmd = "/sbin/udevadm settle --timeout=5 2>&1";
				timed_exec(7, $cmd, true, $return_code);
			}

			sleep(1);
		} else {
			/* Give the kernel a little more time before retrying. */
			sleep(1);
		}
	}

	if (! $rc) {
		unassigned_log("Failed to reload partition table on device '".$dev."' after multiple attempts.");
	}

	return $rc;
}

/* Remove a disk partition. */
function remove_partition($dev, $part) {
	global $paths;

	$rc		= true;

	/* Ensure the partition is not mounted. */
	foreach (get_all_disks_info() as $d) {
		if ($d['device'] == $dev) {
			foreach ($d['partitions'] as $p) {
				if (($p['part'] == $part) && ($p['mounted'])) {
					unassigned_log("Aborting removal: partition '".$part."' is mounted by Unassigned devices.");

					$rc = false;

					/* Stop checking immediately, */
					break 2;
				}

				/* See if the partition is mounted somewhere. */
				$partition_device = MiscUD::is_device_nvme($dev) ? $dev."p".$part : $dev.$part;

				if (is_mounted($partition_device)) {
					unassigned_log("Aborting removal: partition '".$partition_device."' is already mounted, but not by Unassigned Devices.");

					$rc = false;

					/* Stop checking immediately, */
					break 2;
				}
			}
		}
	}

	if ($rc) {
		/* Create the state file. */
		$state_file	= MiscUD::set_mount_state(basename($dev), 'clearing');

		unassigned_log("Removing partition '".$part."' from disk '".$dev."'.");

		/* Remove the partition. */
		$cmd	= "/usr/sbin/parted ".escapeshellarg($dev)." --script -- rm ".escapeshellarg($part)." 2>&1";
		$out	= timed_exec(30, $cmd, true);

		/* Any output from parted likely indicates failure. */
		if ($out) {
			unassigned_log("Remove partition failed: '".$out."'.");
			$rc = false;
		} else {
			/* Reload partition table. */
			$cmd = "/usr/sbin/hdparm -z ".escapeshellarg($dev)." >/dev/null 2>&1";
			timed_exec(10, $cmd, true);

			/* Refresh UD's cached partition info. */
			reload_partition_table($dev);
		}

		/* Remove the state file. */
		MiscUD::rem_mount_state($state_file);
	}

	/* Immediately update Unraid device state. */
	apply_hotplug_now();

	return $rc;
}

/* Remove all disk partitions. */
function remove_all_partitions($dev) {
	global $paths;

	$rc = true;

	/* Be sure there are no mounted partitions. */
	$disks	= get_all_disks_info();
	foreach ($disks as $d) {
		if ($d['device'] == $dev) {
			$serial	= $d['serial'];
			foreach ($d['partitions'] as $p) {
				if ($p['mounted']) {
					unassigned_log("Aborting clear: partition '".$p['part']."' is mounted.");

					$rc = false;

					/* Stop checking immediately */
					break 2;
				}

				/* See if the partition is mounted somewhere. */
				$partition_device = MiscUD::is_device_nvme($dev) ? $dev."p".$p['part'] : $dev.$p['part'];

				if (is_mounted($partition_device)) {
					unassigned_log("Warning: Aborting removal: partition '".$partition_device."' is already mounted, but not by Unassigned Devices.");

					$rc = false;

					/* Stop checking immediately, */
					break 2;
				}
			}
		}
	}

	if ($rc) {
		$device	= MiscUD::base_device($dev);

		/* Create the state file. */
		$state_file	= MiscUD::set_mount_state(basename($device), 'clearing');

		unassigned_log("Removing all partitions from disk '".$device."'.");

		$pool_name	= MiscUD::zfs_pool_name($dev);
		if ($pool_name) {
			/* Remove zpool label info. */
			$timed_cmd	= "/usr/sbin/zpool labelclear -f ".escapeshellarg($dev);
			timed_exec(3, $timed_cmd, true);
			sleep(1);

			/* Export the zpool. */
			$timed_cmd	= "/usr/sbin/zpool export ".escapeshellarg($pool_name)." 2>/dev/null";
			timed_exec(3, $timed_cmd, true);
			sleep(1);
		}

		/* Remove all partitions - this clears the disk. */
		foreach ($disks as $d) {
			if ($d['device'] == $dev) {
				foreach ($d['partitions'] as $p) {
					/* Get partition designation based on type of device. */
					if (MiscUD::is_device_nvme($device)) {
						$zfs_device	= $dev."p".$p['part'];
					} else {
						$zfs_device	= $dev.$p['part'];
					}

					$pool_name	= MiscUD::zfs_pool_name($zfs_device);
					if ($pool_name) {
						/* Remove zpool label info. */
						$timed_cmd	= "/usr/sbin/zpool labelclear -f ".escapeshellarg($zfs_device);
						timed_exec(3, $timed_cmd, true);
						sleep(1);

						/* Export the zpool. */
						$timed_cmd	= "/usr/sbin/zpool export ".escapeshellarg($pool_name)." 2>/dev/null";
						timed_exec(3, $timed_cmd, true);
						sleep(1);
					}

					/* We have to clear every partition. */
					$timed_cmd	= "/sbin/wipefs --all --force ".escapeshellarg($zfs_device)." 2>&1";
					timed_exec(30, $timed_cmd, true);
					sleep(1);
				}
			}
		}

		$timed_cmd	= "/sbin/wipefs --all --force ".escapeshellarg($device)." 2>&1";
		timed_exec(30, $timed_cmd, true);

		/* Let things settle a bit. */
		sleep(2);

		unassigned_log("Debug: Removed all Disk partitions.", $GLOBALS['UDEV_DEBUG']);

		/* Let things settle. */
		timed_exec(10, "/bin/sync", true);
		timed_exec(10, "/sbin/udevadm settle 2>/dev/null", true);

		/* Refresh partition information. */
		$rc	= reload_partition_table($dev);

		/* Remove the state file. */
		MiscUD::rem_mount_state($state_file);
	}

	/* Immediately update Unraid device state. */
	apply_hotplug_now();

	return $rc;
}

/* Procedure to determine the time a command takes to run.  Mostly for debug purposes. */
function benchmark() {
	$params		= func_get_args();
	$function	= $params[0];
	array_shift($params);
	$time		= -microtime(true); 
	$out		= call_user_func_array($function, $params);
	$time		+= microtime(true); 
	$type		= ($time > 10) ? 0 : 1;
	unassigned_log("benchmark: $function(".implode(",", $params).") took ".sprintf('%f', $time)."s.", $type);

	return $out;
}

/* Get the disk size for a disk. */
function get_disk_size($dev, $clear = false) {
	global $paths;

	/* Normalize device name (lsblk outputs names without /dev/). */
	$dev	= basename($dev);

	/* Get cached JSON file. */
	$df				= $paths['disk_sizes'];
	$disk_sizes		= MiscUD::get_json($df);

	/* Clear cache if requested. */
	if ($clear) {
		$disk_sizes = [];

		/* Update JSON file of disk sizes. */
		MiscUD::put_json($df, $disk_sizes);
	}

	/* If not cached, rebuild the disk size map. */
	if ((! $clear) && (! isset($disk_sizes[$dev]))) {
		/* Read all disk sizes in one lsblk call. */
		$timed_cmd		= "/bin/lsblk -b -n -o NAME,SIZE,TYPE 2>/dev/null | /bin/awk '$3 == \"disk\" { print $1 \",\" $2 }'";
		$lsblkOutput	= timed_exec(1, $timed_cmd, true);

		/* Process lsblk output only if non-empty. */
		$lines = $lsblkOutput ? explode("\n", trim($lsblkOutput)) : [];

		if ($lines) {
			/* Build map of disk->size. */
            $new_sizes = [];

			foreach ($lines as $line) {
				$parts = explode(",", $line);
				if (count($parts) === 2) {
					$new_sizes[$parts[0]] = $parts[1];
				}
			}

			/* Only update JSON if valid data was obtained. */
			if ($new_sizes) {
				$disk_sizes = $new_sizes;
				MiscUD::put_json($df, $disk_sizes);
			}
		}
	}

	$rc = $disk_sizes[$dev] ?? "";

	return $rc;
}

/* Find the file system type of a partition or zvol device. */
function part_fs_type($dev, $clear = false, $remove = false) {
	global $paths;

	/* Load cached JSON file. */
	$sf					= $paths['part_file_types'];
	$part_file_types	= MiscUD::get_json($sf);

	/* Clear cache if requested. */
	if ($clear) {
		$part_file_types = [];

		/* Save updated cache. */
		MiscUD::put_json($sf, $part_file_types);
	} else if ($remove) {
		unset($part_file_types[$dev]);
	}

	/* Early return if cached. */
	if ((! $clear) && (! isset($part_file_types[$dev]))) {
		/* Special handling for ZFS zvols. */
		if (strpos($dev, '/dev/zvol/') === 0) {
			$timed_cmd	= "/sbin/blkid -s TYPE -o value ".escapeshellarg($dev)." 2>/dev/null";
			$fs_type	= timed_exec(1, $timed_cmd, true);
			$part_file_types[$dev] = $fs_type ?: "";
			MiscUD::put_json($sf, $part_file_types);
		} else {
			/* Gather NAME + FSTYPE for all partitions except type 7, 11. */
			$timed_cmd		= "/bin/lsblk -o NAME,FSTYPE -n -l -p -e 7,11 2>/dev/null";
			$lsblkOutput	= timed_exec(1, $timed_cmd, true);

			$lines = $lsblkOutput ? explode("\n", trim($lsblkOutput)) : [];

			if ($lines) {
				foreach ($lines as $line) {
					$parts = preg_split('/\s+/', $line, -1, PREG_SPLIT_NO_EMPTY);
					if (count($parts) === 2) {
						$device		= trim($parts[0]);
						$fileType	= trim($parts[1]);

						/* Skip encrypted containers; handle LUKS separately. */
						if ($fileType === "crypto_LUKS") {
							continue;
						}

						$part_file_types[$device] = $fileType;
					}
				}

				/* Ensure entry exists for this device. */
				$part_file_types[$dev] = $part_file_types[$dev] ?? "";

				/* Save updated cache. */
				MiscUD::put_json($sf, $part_file_types);
			}
		}
	}

	/* Get the detected type (may be blank). */
	$file_type = $part_file_types[$dev] ?? "";

	/* Detect LUKS by mapper/dm naming. */
	$is_luks = (strpos($dev, "/dev/mapper/") !== false || preg_match('#^/dev/dm-#', $dev));

	/* Final determination. */
	$rc = ($file_type === "zfs_member") ? "zfs" : ($file_type ? $file_type : ($is_luks ? "luks" : ""));

	return $rc;
}

/**
 * Request a deferred Unraid hotplug apply.
 *
 * @return bool True when the request file was written.
 */
function request_hotplug_apply() {
	global $paths;

	$rc = false;

	$rc = (@touch($paths['hotplug_event']) !== false);

	return $rc;
}

/**
 * Clear a stale hotplug running semaphore.
 *
 * @param int $max_age Maximum age in seconds.
 *
 * @return bool True when the stale semaphore was cleared.
 */
function clear_stale_hotplug_running($max_age = 60) {
	global $paths;

	$rc = false;

	if (file_exists($paths['hotplug_running'])) {
		if ((time() - filemtime($paths['hotplug_running'])) > $max_age) {
			unassigned_log("Debug: Clear Hotplug Running semaphore file.", $GLOBALS['UDEV_DEBUG']);

			$rc = @unlink($paths['hotplug_running']);
		}
	}

	return $rc;
}

/**
 * Wait for the active hotplug apply to finish.
 *
 * @param int $timeout Timeout in seconds.
 *
 * @return bool True when no hotplug apply is running.
 */
function wait_for_hotplug_apply($timeout = 30) {
	global $paths;

	$rc		= true;
	$start	= time();

	while (true) {
		clearstatcache(true, $paths['hotplug_running']);

		if (! file_exists($paths['hotplug_running'])) {
			break;
		}

		if ((time() - $start) >= $timeout) {
			$rc = false;
			break;
		}

		usleep(250 * 1000);
	}

	return $rc;
}

/**
 * Run a queued Unraid hotplug apply.
 *
 * @param bool $wait Wait for the apply to finish.
 *
 * @return bool True when the apply was launched or completed.
 */
function run_hotplug_apply_if_needed($wait = false) {
	global $paths;

	$rc = false;

	clear_stale_hotplug_running();

	if ((file_exists($paths['hotplug_event'])) && (! file_exists($paths['hotplug_running']))) {
		@touch($paths['hotplug_running']);
		@unlink($paths['hotplug_event']);

		unassigned_log("Debug: Processing needed Hotplug event...", $GLOBALS['UDEV_DEBUG']);

		/* Clear all the disk sizes and partition file types so they can be rediscovered after a hotplug. */
		get_disk_size("", true);
		part_fs_type("", true);

		/* Clear cached NFS path checks. */
		check_remote_nfs_path("", "", true);

		if ($wait) {
			$cmd  = "/usr/local/sbin/emcmd cmdHotplug='apply' >/dev/null 2>&1; ";
			$cmd .= "/bin/rm -f ".escapeshellarg($paths['hotplug_running']);
			timed_exec(30, $cmd, true);
			$rc = (! file_exists($paths['hotplug_running']));
		} else {
			$cmd  = "/usr/local/sbin/emcmd cmdHotplug='apply' >/dev/null 2>&1; ";
			$cmd .= "/bin/rm -f ".escapeshellarg($paths['hotplug_running']);
			$launch_cmd = "/usr/bin/nohup /bin/bash -c ".escapeshellarg($cmd)." >/dev/null 2>&1 &";
			timed_exec(0, $launch_cmd);

			$rc = true;
		}
	} else if ($wait) {
		$rc = wait_for_hotplug_apply();
	}

	return $rc;
}

/**
 * Request and synchronously apply a Unraid hotplug update.
 *
 * Use this before operations that depend on current devX/devs.ini state.
 *
 * @return bool True when the hotplug apply completed.
 */
function apply_hotplug_now() {
	$rc = false;

	/* Wait for any currently running hotplug to complete. */
	wait_for_hotplug_apply();

	/* Request a new hotplug. */
	request_hotplug_apply();

	/* Run a hotplug apply. */
	$rc = run_hotplug_apply_if_needed(true);

	return $rc;
}

#########################################################
############		CONFIG FUNCTIONS		#############
#########################################################
/* Get device configuration parameter. */
function get_config($serial, $variable) {
	global $ud_config;

	return $ud_config[$serial][$variable] ?? "";
}

/* Set device configuration parameter. */
function set_config($serial, $variable, $value) {
	global $ud_config;

	/* Verify we have a serial number. */
	if ($serial) {
		/* Make file changes. */
		$ud_config[$serial][$variable] = $value;
		save_ini_file(UD_CONFIG_FILE, $ud_config);

		$rc	= $ud_config[$serial][$variable] ?? "";
	} else {
		$rc	= false;
	}

	return $rc;
}

/* Is device set to auto mount? */
function is_automount($serial, $usb = false) {
	$auto			= get_config($serial, "automount");
	$auto_usb		= get_config("Config", "automount_usb");
	$pass_through	= get_config($serial, "pass_through");

	return ( (($pass_through != "yes") && (($auto == "yes") || ($usb && $auto_usb == "yes"))) );
}

/* Is device set to mount read only? */
function is_read_only($serial, $default = false, $part = "") {
	$read_only		= "read_only".($part ? ".$part" : "");
	$read_only		= get_config($serial, $read_only);
	$pass_through	= get_config($serial, "pass_through");

	return ( $pass_through != "yes" && $read_only == "yes" ) ? true : (($read_only == "no") ? false : $default);
}

/* Is device set to pass through. */
function is_pass_through($serial, $part = "") {
	$pass_through	= "pass_through".($part ? ".$part" : "");

	return (get_config($serial, $pass_through) == "yes");
}

/* Is disable mount button set. */
function is_disable_mount($serial, $part = "") {
	$disable_mount	= "disable_mount".($part ? ".$part" : "");

	return (get_config($serial, $disable_mount) == "yes");
}

/* Toggle auto mount on/off. */
function toggle_automount($serial, $status) {
	global $ud_config;

	/* Verify we have a serial number. */
	if ($serial) {
		/* Make file changes. */
		$ud_config[$serial]["automount"] = ($status == "true") ? "yes" : "no";
		save_ini_file(UD_CONFIG_FILE, $ud_config);

		$rc	= ($ud_config[$serial]["automount"] == "yes");
	} else {
		$rc = false;
	}

	return $rc;
}

/* Toggle read only on/off. */
function toggle_read_only($serial, $status, $part = "") {
	global $ud_config;

	/* Verify we have a serial number. */
	if ($serial) {
		/* Make file changes. */
		$read_only		= "read_only".($part ? ".$part" : "");
		$ud_config[$serial][$read_only] = ($status == "true") ? "yes" : "no";
		save_ini_file(UD_CONFIG_FILE, $ud_config);

		$rc = ($ud_config[$serial][$read_only] == "yes");
	} else {
		$rc = false;
	}

	return $rc;
}

/* Toggle pass through on/off. */
function toggle_pass_through($serial, $status, $part = "") {
	global $ud_config;

	/* Verify we have a serial number. */
	if ($serial) {
		/* Make file changes. */
		$pass_through	= "pass_through".($part ? ".$part" : "");
		$ud_config[$serial][$pass_through] = ($status == "true") ? "yes" : "no";
		save_ini_file(UD_CONFIG_FILE, $ud_config);

		$rc = ($ud_config[$serial][$pass_through] == "yes");
	} else {
		$rc = false;
	}

	return $rc;
}

/* Toggle hide mount button on/off. */
function toggle_disable_mount($serial, $status, $part = "") {
	global $ud_config;

	/* Verify we have a serial number. */
	if ($serial) {
		/* Make file changes. */
		$disable_mount	= "disable_mount".($part ? ".$part" : "");
		$ud_config[$serial][$disable_mount] = ($status == "true") ? "yes" : "no";
		save_ini_file(UD_CONFIG_FILE, $ud_config);

		$rc = ($ud_config[$serial][$disable_mount] == "yes");
	} else {
		$rc = false;
	}

	return $rc;
}

/* Copy script to tmpfs, normalize line endings, and make executable. */
function prepare_script($source_file, $command_script) {
	$ok = false;
	$data = '';
	$tmp_file = $command_script.'.tmp';

	if (is_file($source_file) && is_readable($source_file)) {
		$data = file_get_contents($source_file);

		if ($data !== false) {
			/*
			 * Normalize line endings:
			 * - CRLF -> LF
			 * - stray CR -> LF
			 */
			$data = str_replace(["\r\n", "\r"], "\n", $data);

			/* Ensure file ends with a newline. */
			if ($data === '' || substr($data, -1) !== "\n") {
				$data .= "\n";
			}

			if (file_put_contents($tmp_file, $data, LOCK_EX) !== false) {
				if (@rename($tmp_file, $command_script)) {
					if (@chmod($command_script, 0755)) {
						$ok = true;
					}
				}
			}
		}
	}

	if (! $ok) {
		@unlink($tmp_file);
	}

	return $ok;
}

/* Execute the device script. */
function execute_script($info, $action, $testing = false) {
	global $paths;

	$rc = false;

	/* Set environment variables. */
	putenv("ACTION=".$action ?? "");
	foreach ($info as $key => $value) {
		/* Only set the environment variables used by the device script. */
		switch ($key) {
			case 'device':
			case 'serial':
			case 'label':
			case 'fstype':
			case 'mountpoint':
			case 'owner':
			case 'prog_name':
			case 'logfile':
			case 'luks':
				putenv(strtoupper($key)."=".$value);
			break;
		}
	}

	/* Set the device devX designation. */
	$device	= ($info['fstype'] != "crypto_LUKS") ? $info['device'] : $info['luks'];
	$ud_dev	= get_disk_dev(MiscUD::base_device(basename($device)));
	putenv("UD_DEVICE=".$ud_dev);

	/* Execute the common script if it is defined. */
	if (($action == "ADD") && ($common_cmd = $info['common_cmd'])) {
		if (is_file($common_cmd)) {
			$common_script = $paths['scripts'].basename($common_cmd);

			unassigned_log("Running common script: '".basename($common_script)."'");

			/* Prepare script by copying to tmpfs, insuring line feeds, and making executable. */
			prepare_script($common_cmd, $common_script);

			/* Run the common script in the background. */
			$cmd	= escapeshellarg($common_script)." > /dev/null 2>&1 &";
			$out	= null;
			$return	= null;

			exec($cmd, $out, $return);
			if ($return) {
				unassigned_log("Common script failed: '".$return."'");
			}
		} else {
			unassigned_log("Common Script file '".$common_cmd."' is not a valid file!");
		}
	}

	/* If there is a command, execute the device script. */
	$cmd			= $info['command'];
	$enable_script	= ($info['enable_script'] != "false");

	if (file_exists($cmd)) {
		$command_script = $paths['scripts'].basename($cmd);

		if ($enable_script) {
			if (is_file($cmd)) {
				$script_running = is_script_running($cmd);

				if ((! $script_running) || (($script_running) && ($action != "ADD"))) {
					unassigned_log("Running device script: '".basename($cmd)."' with action '".$action."'.");

					/* Prepare script by copying to tmpfs, insuring line feeds, and making executable. */
					prepare_script($cmd, $command_script);

					$clear_log		= ($action == "ADD") ? ">" : ">>";
					$running_dir	= $paths['script_running'];
					$running_file	= $running_dir.basename($cmd);

					if (! is_dir($running_dir)) {
						@mkdir($running_dir, 0777, true);
					}

					@unlink($running_file);

					if ($testing) {
						$launch_cmd  = "/usr/bin/setsid /bin/bash -c ";
						$launch_cmd .= escapeshellarg(
							"echo \$\$ > ".escapeshellarg($running_file)."; ".
							escapeshellarg($command_script)." 2>&1; ".
							"rc=\$?; ".
							"rm -f ".escapeshellarg($running_file)."; ".
							"exit \$rc"
						);

						$rc = $launch_cmd;
					} else {
						if (($action == "REMOVE") || ($action == "ERROR_MOUNT") || ($action == "ERROR_UNMOUNT")) {
							sleep(1);
						}

						$launch_cmd  = "/usr/bin/setsid /bin/bash -c ";
						$launch_cmd .= escapeshellarg(
							"echo \$\$ > ".escapeshellarg($running_file)."; ".
							escapeshellarg($command_script)." ".$clear_log." ".escapeshellarg($info['logfile'])." 2>&1; ".
							"rc=\$?; ".
							"rm -f ".escapeshellarg($running_file)."; ".
							"exit \$rc"
						);
						$launch_cmd .= " > /dev/null 2>&1 &";

						$out	= null;
						$return	= null;

						exec($launch_cmd, $out, $return);
						if ($return) {
							unassigned_log("Device script failed to launch: '".$return."'");
						} else {
							$rc = true;
						}
					}
				} else {
					unassigned_log("Device script '".basename($cmd)."' is already running!");
				}
			} else {
				unassigned_log("Script file '".$command_script."' is not a valid file!");
			}
		} else if ($action == "ADD") {
			unassigned_log("Device script '".basename($cmd)."' is not enabled!");
		}
	}

	return $rc;
}

/* Remove a historical disk configuration. */
function remove_config_disk($serial) {
	global $ud_config;

	$result = true;

	/* Remove this disk configuration if it exists. */
	if (isset($ud_config[$serial])) {
		unassigned_log("Removing configuration '".$serial."'.");

		foreach ($ud_config[$serial] as $key => $value) {
			if (($key == "command") || (strpos($key, "command.") === 0)) {
				if (isset($value) && is_file($value)) {
					@unlink($value);

					unassigned_log("Removing device script '".$value."'.");
				}
			}
		}

		/* Remove this configuration. */
		unset($ud_config[$serial]);

		/* Resave all disk configurations. */
		save_ini_file(UD_CONFIG_FILE, $ud_config);
	}

	$result = (! isset($ud_config[$serial]));

	return $result;
}

/* Is disk device an SSD? */
function is_disk_ssd($dev) {
	$rc		= false;
	$device	= MiscUD::base_device(basename($dev));

	if ($device) {
		if (MiscUD::is_device_nvme($device)) {
			$rc = true;
		} else {
			$file	= "/sys/block/".basename($device)."/queue/rotational";
			$rc		= (trim(@file_get_contents($file)) === "0");
		}
	}

	return $rc;
}

/* Is the device designation a 'devX' device? */
function is_dev_device($dev) {
	$result = false;

	if (preg_match('/^dev\d{1,2}$/i', $dev)) {
		$result = true;
	}

	return $result;
}

/* Is the device designation a 'sdX' device? */
function is_sd_device($dev) {
	$result = false;

	if (preg_match('/^sd[a-z]{1,2}$/i', $dev)) {
		$result = true;
	}

	return $result;
}

#########################################################
############		MOUNT FUNCTIONS			#############
#########################################################
/* Is a device mounted? */
function is_mounted($dev, $dir = "", $update = true) {
	global $mounts;

	/* 
	 * Device-only or mountpoint-only requests are allowed.
	 *
	 * If $dev is empty, the device check is considered satisfied.
	 * If $dir is empty, the mountpoint check is considered satisfied.
	 *
	 * Examples:
	 *	is_mounted($dev)			-> device must be mounted.
	 *	is_mounted("", $dir)		-> mountpoint must be mounted.
	 *	is_mounted($dev, $dir)		-> both device and mountpoint must match.
	 */
	$rc_dev	= ($dir) ? (! $dev) : false;
	$rc_dir	= ($dev) ? (! $dir) : false;

	/* Refresh cached mount table if needed. */
	if ((! isset($mounts)) || $update) {
		$timed_cmd	= "/bin/awk '{print $1 \",\" $2 \",\" $4}' /proc/mounts 2>/dev/null";
		$text		= timed_exec(1, $timed_cmd, true);

		/* Decode common /proc/mounts escapes. */
		$text = str_replace(
			["\\040", "\\011", "\\012", "\\134"],
			[" ", "\t", "\n", "\\"],
			$text
		);

		$new_mounts	= [];
		$lines		= explode("\n", $text);

		foreach ($lines as $line) {
			if ($line === '') {
				continue;
			}

			$parts = explode(',', $line, 3);
			if (count($parts) !== 3) {
				continue;
			}

			$device			= trim($parts[0]);
			$mount_point	= trim($parts[1]);
			$options		= explode(",", trim($parts[2]));
			$read_only		= in_array("ro", $options, true);

			$new_mounts[$mount_point] = [
				'device'	=> $device,
				'read_only'	=> $read_only
			];
		}

		$mounts = $new_mounts;
	}

	/* Check by device. */
	if ($dev) {
		foreach ($mounts as $mp => $info) {
			if (isset($info['device']) && $info['device'] === $dev) {
				$rc_dev = true;
				break;
			}
		}
	}

	/* Check by mount point. */
	if ($dir) {
		$rc_dir = isset($mounts[$dir]);
	}

	/*
	 * Returns:
	 *	true  - requested device and/or mountpoint are mounted.
	 *	false - one or more requested checks failed.
	 *
	 * Either $dev or $dir may be blank.
	 */

	return ($rc_dev && $rc_dir);
}

/**
 * Wait for a device/mountpoint to be mounted.
 *
 * @param string $dev Device path (e.g., /dev/sdb1)
 * @param string $dir Mount point path (optional)
 * @return bool True if mounted within retries, false on timeout
 */
function wait_for_mounted($dev, $dir = "") {
	$rc = false;

	/* Fixed number of retries */
   	$attempts = 5;
 
 	/* Fixed sleep between retries in milliseconds */
 	$sleep_ms = 100;

	for ($i = 0; $i < $attempts; $i++) {
		/* Force refresh of /proc/mounts each loop */
		if (is_mounted($dev, $dir)) {
			$rc = true;
			break;
		}

		usleep($sleep_ms * 1000);
	}

	return $rc;
}

/**
 * Wait for a device/mountpoint to be unmounted.
 *
 * @param string $dev Device path (e.g., /dev/sdb1)
 * @param string $dir Mount point path (optional)
 * @return bool True if unmounted within retries, false on timeout
 */
function wait_for_unmounted($dev, $dir = "") {
	global $mounts;

	$rc = false;

	/* Fixed number of retries */
   	$attempts = 5;

	/* Fixed sleep between retries in milliseconds */
 	$sleep_ms = 100;

	for ($i = 0; $i < $attempts; $i++) {
		/* Force refresh of /proc/mounts each loop */
		if (! is_mounted($dev, $dir)) {
			$rc = true;
			break;
		}

		usleep($sleep_ms * 1000);
	}

	return $rc;
}

/* Is a device mounted read only? */
function is_mounted_read_only($dir) {
	global $mounts;

	$rc		= $mounts[$dir]['read_only'] ?? false;

	return ($rc);
}

/* Get the mount parameters based on the file system. */
function get_mount_params($fs, $dev, $ro = false, $compression = "") {
	$rc					= "";
	$discard			= "";

	/* Set the discard option. */
	if (($fs != "cifs") && ($fs != "nfs") && ($fs != "root")) {
		$discard 		= ((get_config("Config", "discard") == "yes") && (is_disk_ssd($dev))) ? ",discard" : "";
	}

	/* Set the compress option. */
	$compress_option	= (($fs == "btrfs") && ($compression)) ? ",compress=".$compression : "";

	/* Set rw option. */
	$rw					= $ro ? "ro" : "rw";

	switch ($fs) {
		case 'hfsplus':
			$rc = "force,{$rw},users,umask=000";
			break;

		case 'btrfs':
			$rc = "{$rw},relatime,space_cache=v2{$discard}{$compress_option}";
			break;

		case 'xfs':
			$rc = "{$rw},relatime{$discard}";
			break;

		case 'zfs':
			$rc = "{$rw}";
			break;

		case 'ext4':
			$rc = "{$rw},relatime,nodev,nosuid{$discard}";
			break;

		case 'exfat':
			$rc = "{$rw},relatime,nodev,nosuid,umask=000";
			break;

		case 'vfat':
			$rc = "{$rw},relatime,nodev,nosuid,iocharset=utf8,umask=000";
			break;

		case 'ntfs':
			$rc = "{$rw},relatime,nodev,nosuid,nls=utf8,umask=000";
			break;

		case 'ntfs3':
			$rc = "{$rw},relatime,nodev,nosuid,umask=000";
			break;

		case 'cifs':
			$rc = "{$rw}%s,relatime,noserverino,nounix,iocharset=utf8,file_mode=0777,dir_mode=0777,cache=%s,uid=%s,gid=%s,actimeo=%s,%s";
			break;

		case 'nfs':
			$rc = "{$rw},relatime,timeo=50,retrans=5";
			break;

		case 'root':
			$rc = "{$rw},bind";
			break;

		default:
			$rc = "{$rw},relatime";
			break;
	}

	return $rc;
}

/* Mount a device. */
function do_mount($info) {
	global $paths;

	$rc = false;

	if (MiscUD::is_valid_ud_mountpoint($info['mountpoint'])) {
		/* Mount a CIFS or NFS remote mount. */
		if ($info['fstype'] == "cifs" || $info['fstype'] == "nfs") {
			$rc = do_mount_samba($info);

		/* Mount root share. */
		} else if ($info['fstype'] == "root") {
			$rc = do_mount_root($info);

		/* Mount an ISO file. */
		} else if ($info['fstype'] == "loop") {
			$rc = do_mount_iso($info);

		/* Mount a luks encrypted disk device. */
		} else if ($info['fstype'] == "crypto_LUKS") {
			$fstype		= part_fs_type($info['device']);
			$mounted	= $info['mounted'];
			if (! $mounted) {
				$luks		= basename($info['device']);
				$pass		= decrypt_data(get_config($info['serial'], "pass"));

				/* Open the luks device. */
				if (! MiscUD::luks_open_device($info['luks'], $luks, $pass, true)) {
					$rc		= false;
				} else {
					/* Mount an encrypted disk. */
					$rc		= do_mount_local($info);
				}
			} else {
				unassigned_log("Partition '".basename($info['device'])."' is already mounted.");
			}

		/* Mount an unencrypted disk. */
		} else {
			$rc = do_mount_local($info);
		}
	} else {
		unassigned_log("Mount aborted: invalid mount point '".$info['mountpoint'].".");
	}

	return $rc;
}

/* Mount a disk device. */
function do_mount_local($info) {
	global $paths, $var;

	$cmd				= "";
	$o					= "";

	$rc					= true;
	$dev				= $info['device'];
	$dir				= $info['mountpoint'];
	$fs					= $info['fstype'];
	$file_system		= $fs;
	$ro					= $info['read_only'];
	$compression		= $info['compression'];
	$pool_name			= ($info['pool_name']) ?: MiscUD::zfs_pool_name($dev);
	$mounted			= $info['mounted'];

	/* Determine desired compression state for zfs and btrfs disks. */
	$zfs_compression	= ($compression == "yes") ? "lz4" : "off";
	$btrfs_compression	= ($compression == "yes") ? "zlib" : "";

	/* Check if the ntfs3 module is loaded. */
	$timed_cmd			= "/bin/lsmod | grep ntfs3";
	$ntfs3_loaded		= timed_exec(2, $timed_cmd, true) ? true : false;

	$ntfs3				= (($ntfs3_loaded) && (get_config($info['serial'], "ntfs3_driver.".$info['part']) == "yes")) ? "3" : "";

	/* Mount the disk if it is not already mounted. */
	if ($file_system) {
		$recovery = "";
		if ($file_system != "crypto_LUKS") {
			if ($file_system == "apfs") {
				/* See if there is a disk password. */
				$password	= decrypt_data(get_config($info['serial'], "pass"));
				if ($password) {
					$recovery = ",pass='".$password."'";
				}
				$vol		= ",vol=".(get_config($info['serial'], "volume.".$info['part']) ?: "0");
				$cmd		= "/usr/bin/apfs-fuse -o uid=99,gid=100,allow_other{$vol}{$recovery} ".escapeshellarg($dev)." ".escapeshellarg($dir);
			} else if ($file_system == "zfs") {
				/* Mount a zfs pool device. */
				if ($pool_name) {
					/* Get the Unraid reserved names. Pool name cannot be a reserved name. */
					$reserved_names = explode(",", $var['reservedNames']);

					if (($pool_name) && (! in_array($pool_name, $reserved_names))) {
						$timed_cmd	= "/usr/sbin/zpool list -H ".escapeshellarg($pool_name)." 2>/dev/null";
						$check		= timed_exec(2, $timed_cmd, true);
						if ($check) {
							$timed_cmd = "/usr/sbin/zpool export ".escapeshellarg($pool_name)." 2>/dev/null";
							timed_exec(2, $timed_cmd, true);
						}

						$timed_cmd	= "/usr/sbin/zpool import -d ".escapeshellarg($dev)." -N ".escapeshellarg($pool_name)." 2>&1";					
						$o			= timed_exec(2, $timed_cmd, true);
						if (! $o) {
							/* Check current atime value */
							$timed_cmd	= "/usr/sbin/zfs get -H -o value atime ".escapeshellarg($pool_name);
							$current	= timed_exec(2, $timed_cmd, true);

							/* Set atime=off only if needed */
							if ($current !== 'off') {
								$timed_cmd	= "/usr/sbin/zfs set atime=off ".escapeshellarg($pool_name)." 2>/dev/null";
								timed_exec(2, $timed_cmd, true);
							}

							/* Get current compression value */
							$timed_cmd	= "/usr/sbin/zfs get -H -o value compression ".escapeshellarg($pool_name)." 2>/dev/null";
							$current	= timed_exec(2, $timed_cmd, true);

							/* Apply compression only if different */
							if ($current != $zfs_compression) {
								$timed_cmd 	= "/usr/sbin/zfs set compression=".$zfs_compression." ".escapeshellarg($pool_name)." 2>/dev/null";
								timed_exec(2, $timed_cmd, true);
							}

							/* Set zfs mount point. */
							$timed_cmd	= "/usr/sbin/zfs set mountpoint=".escapeshellarg($dir)." ".escapeshellarg($pool_name)." 2>/dev/null";
							timed_exec(2, $timed_cmd, true);

							/* Build mount command. */
							$params 	= get_mount_params($file_system, $dev, $ro);
							$cmd		= "/usr/sbin/zfs mount -o $params ".escapeshellarg($pool_name);
						} else {
							/* Log the warning with the message */
							$o	= str_replace("\t", '', $o);
							unassigned_log("Warning: ".$o);

							$rc	= false;
						}
					} else {
						unassigned_log("Error: Cannot mount disk - pool name '".$pool_name."' is a reserved name!");

						$rc	= false;
					}
				} else {
					unassigned_log("Warning: Cannot determine Pool Name of '".$dev."'");

					$rc	= false;
				}
			} else if ($file_system == "zvol") {
				/* Get the file system of this partition. */
				$z_fstype	= part_fs_type($dev);

				/* If the file system is ntfs, apply the ntfs3 setting to mount the disk. */
				if ($z_fstype === "ntfs") {
					$z_fstype	= $z_fstype.$ntfs3;
				}

				$params			= get_mount_params($z_fstype, $dev, $ro);
				$cmd			= "/sbin/mount -t ".escapeshellarg($z_fstype)." -o $params ".escapeshellarg($dev)." ".escapeshellarg($dir);
			} else {
				/* If the file system is ntfs, apply the ntfs3 setting to mount the disk. */
				if ($file_system === "ntfs") {
					$file_system	= $fs.$ntfs3;
				}

				/* Build mount command. */
				$params			= get_mount_params($file_system, $dev, $ro, $btrfs_compression);
				$cmd			= "/sbin/mount -t ".escapeshellarg($file_system)." -o $params ".escapeshellarg($dev)." ".escapeshellarg($dir);
			}
		} else {
			/* Set as not mounted properly. */
			$rc	= false;

			/* Physical device being mounted. */
			$device = $info['luks'];

			/* Find the file system type on the luks device to use the proper mount options. */
			$mapper			= $info['device'];

			/* Now that the luks device is opened, we can get the file system. */
			$fs				= part_fs_type($mapper, false, true);

			/* If the file system is ntfs, apply the ntfs3 setting to mount the disk. */
			if ($fs == "ntfs") {
				$file_system	= $fs.$ntfs3;
			} else {
				$file_system	= $fs;
			}

			if ($file_system != "zfs") {
				/* If the file system is ntfs, apply the ntfs3 setting to mount the disk. */
				if ($file_system === "ntfs") {
					$file_system	= $fs.$ntfs3;
				}

				$params	= get_mount_params($file_system, $device, $ro, $btrfs_compression);
				if ($file_system) {
					$cmd = "/sbin/mount -t ".escapeshellarg($file_system)." -o $params ".escapeshellarg($dev)." ".escapeshellarg($dir);
				} else {
					$cmd = "/sbin/mount -o $params ".escapeshellarg($dev)." ".escapeshellarg($dir);
				}

				$rc	= true;
			} else {
				/* Mount a zfs pool device. */
				/* After the luks device is opened, we can get the pool name. */
				$pool_name	= MiscUD::zfs_pool_name($dev);
				if ($pool_name) {
					/* Get the Unraid reserved names. Pool name cannot be a reserved name. */
					$reserved_names = explode(",", $var['reservedNames']);

					if (($pool_name) && (! in_array($pool_name, $reserved_names))) {
						$timed_cmd	= "/usr/sbin/zpool list -H ".escapeshellarg($pool_name)." 2>/dev/null";
						$check		= timed_exec(2, $timed_cmd, true);
						if ($check) {
							$timed_cmd = "/usr/sbin/zpool export ".escapeshellarg($pool_name)." 2>/dev/null";
							timed_exec(2, $timed_cmd, true);
						}

						$timed_cmd	= "/usr/sbin/zpool import -d ".escapeshellarg($dev)." -N ".escapeshellarg($pool_name)." 2>&1";					
						$o = timed_exec(3, $timed_cmd, true);
						if (! $o) {
							/* Check current atime value */
							$timed_cmd	= "/usr/sbin/zfs get -H -o value atime ".escapeshellarg($pool_name);
							$current	= timed_exec(2, $timed_cmd, true);

							/* Set atime=off only if needed */
							if ($current !== 'off') {
								$cmd = "/usr/sbin/zfs set atime=off ".escapeshellarg($pool_name)." 2>/dev/null";
								timed_exec(2, $cmd, true);
							}

							/* Get current compression value */
							$timed_cmd	= "/usr/sbin/zfs get -H -o value compression ".escapeshellarg($pool_name)." 2>/dev/null";
							$current	= timed_exec(2, $timed_cmd, true);

							/* Apply compression only if different */
							if ($current != $zfs_compression) {
								$timed_cmd 	= "/usr/sbin/zfs set compression=".$zfs_compression." ".escapeshellarg($pool_name)." 2>/dev/null";
								timed_exec(2, $timed_cmd, true);
							}

							/* Set zfs mount point. */
							$timed_cmd	= "/usr/sbin/zfs set mountpoint=".escapeshellarg($dir)." ".escapeshellarg($pool_name)." 2>/dev/null";
							timed_exec(3, $timed_cmd, true);

							$rc		= true;
						} else {
							/* Log the warning with the message */
							$o	= str_replace("\t", '', $o);
							unassigned_log("Warning: ".$o);
						}
					} else {
						unassigned_log("Error: Cannot mount disk - pool name '".$pool_name."' is a reserved name!");
					}
				} else {
					unassigned_log("Warning: Cannot determine Pool Name of '".$dev."'");
				}

				/* Build mount command. */
				$params		= get_mount_params($file_system, $device, $ro, $btrfs_compression);
				$cmd		= "/usr/sbin/zfs mount -o $params ".escapeshellarg($pool_name);
			}
		}

		$log_cmd = $cmd ?? "";
		if (($file_system == "apfs") && ($recovery ?? "")) {
			$log_cmd = str_replace($recovery, ",pass='*****'", $log_cmd);
		}

		unassigned_log("Mount cmd: ".$log_cmd);

		/* If there aren't any failures so far, mount the device. */
		if ($rc) {
			/* Set as not mounted properly. */
			$rc	= false;

			/* apfs file system requires UD+ to be installed. */
			if (($file_system == "apfs") && (! is_file("/usr/bin/apfs-fuse"))) {
				$o = "Install Unassigned Devices Plus to mount an apfs file system";
			} else if (($file_system == "zfs") && (! is_file("/usr/sbin/zfs"))) {
				$o = "Unraid 6.12 or later is needed to mount a zfs file system";
			} else {
				/* Create mount point and set permissions. */
				if (! is_dir($dir)) {
					@mkdir($dir, 0777, true);
				}

				/* If the pool name cannot be found, we cannot mount the pool. */
				if (($file_system == "zfs") && (! $pool_name)) {
					$o = "Warning: Cannot determine Pool Name of '".$dev."'";
				} else {
					/* Do the mount command. */
					$timed_cmd	= $cmd." 2>&1";
					$o = timed_exec(30, $timed_cmd, true);
				}
			}

			/* Do some cleanup if we mounted an apfs disk, */
			if ($file_system == "apfs") {
				/* Remove all password variables. */
				unset($password);
				unset($recovery);
				unset($cmd);
			}

			if (($file_system == "zfs") && (! $pool_name)) {
				$o = "Warning: Cannot determine Pool Name of '".$dev."'";
			} else {
				/* Let the mount settle. */
				usleep(250 * 1000);

				/* Check to see if the device really mounted. */
				if (($file_system == "zfs") && ($pool_name)) {
					/* For zfs devices, the pool name is the device. */
					$mount_dev		= $pool_name;
				} else if ($file_system == "btrfs") {
					/* If the btrfs secondary pool device is being mounted, don't check the device is mounted. */
					$mount_dev		= "";
				} else {
					$mount_dev		= $dev;
				}

				/* The device and mount point need to be mounted. */
				$mounted	= wait_for_mounted($mount_dev, $dir);

				if ($mounted) {
					if (! is_mounted_read_only($dir)) {
						@chmod($dir, 0777);
						@chown($dir, 99);
						@chgrp($dir, 100);
					} else if (($file_system == "apfs") || ($file_system == "hfsplus")) {
						unassigned_log("Warning: apfs and HFS+ file systems can only be mounted read only due to driver limitations.");
					} else if ($file_system == "zvol") {
						unassigned_log("Warning: zfs zvols will be mounted read only when the ZFS Pool is mounted read only.");
					}

					unassigned_log("Successfully mounted '".$dev."' on '".$dir."'.");

					$rc = true;

					/* Set zfs readonly flag based on device read only setting. */
					if ($file_system == "zfs") {
						$timed_cmd	= "/usr/sbin/zfs set readonly=".($ro ? 'on' : 'off')." ".escapeshellarg($pool_name)." 2>/dev/null";
						timed_exec(3, $timed_cmd, true);

						/* Check zfs indicators indicating any incompatibilities. */
						$zfs_indicators		= ud_zfs_indicator($dir, $pool_name);
						$zfs_current_ind	= get_config($info['serial'], "zfs_indicator.{$info['part']}");
						if ($zfs_indicators != $zfs_current_ind) {
							set_config($info['serial'], "zfs_indicator.{$info['part']}", $zfs_indicators);
						}
					}
				}
			}
		}

		/* If the device did not mount, close the luks disk if the FS is luks, and show an error. */
		if (! $rc) {
			if ($info['fstype'] == "crypto_LUKS" ) {
				MiscUD::luks_close_device($info['devcice']);
			}

			/* Is there a mount error? */
			if ($o) {
				unassigned_log("Warning: Mount of '".basename($dev)."' failed: '".$o."'");
			}

			/* Remove the mount point. */
			@rmdir($dir);

			if ($pool_name) {
				/* Export the pool so it will mount later. */
				$timed_cmd	= "/usr/sbin/zpool export ".escapeshellarg($pool_name)." 2>/dev/null";
				timed_exec(3, $timed_cmd, true);
			}
		} else {
			if ($info['fstype'] == "btrfs") {
				/* Update the btrfs state file for single scan for pool devices. */
				$pool_state			= MiscUD::get_json($paths['pool_state']);
				$pool_state[$dir]	= [];
				MiscUD::put_json($paths['pool_state'], $pool_state);
			}

			/* Ntfs is mounted but is most likely mounted r/o. Display the mount command warning. */
			if ($o && ($file_system == "ntfs")) {
				unassigned_log("Mount warning: ".$o);
			}

			/* Check a xfs file system to see if it is V5. */
			if (($file_system == "xfs") && (! MiscUD::is_xfs_v5($dir))) {
				unassigned_log("Warning: Device '".$dev."' mounted at '".$dir."' is XFS V4 - V4 is deprecated and will not be supported in future Unraid releases.  You need to migrate to XFS V5.");
			}

			/* If file system is zfs, mount any datasets. */
			if ($file_system == "zfs") {
				$timed_cmd	= "/usr/sbin/zfs list -H -o name,mountpoint | /usr/bin/grep ".escapeshellarg($pool_name)." | /bin/awk -F'\t' '$2 != \"-\" && $2 != \"legacy\" {print $1 \",\" $2}'";
				$data	= timed_exec(3, $timed_cmd, true);

				$rows	= explode("\n", $data);

				/* Check for any potential datasets to mount. */
				if (count($rows) > 2) {
					/* Set as not mounted properly. */
					$dataset_mounted	= false;

					unassigned_log("Mounting zfs datasets...");

					/* Check each dataset to see if can be mounted. */
					foreach ($rows as $dataset) {
						$columns		= explode(',', $dataset);

						/* The dataset (folder) must exist before it can be mounted. */
						if ((count($columns) == 2) && ($columns[0] != $pool_name)) {
							/* Mount the dataset if it did not automount. */
							if (! is_mounted($columns[0], $columns[1])) {
								/* Mount the dataset. */
								$params	= get_mount_params($file_system, $pool_name, $ro);
								$cmd = "/usr/sbin/zfs mount -o ".$params." ".escapeshellarg($columns[0]);

								unassigned_log("Mount dataset cmd: ".$cmd);

								/* Do the mount command. */
								$o		= timed_exec(30, $cmd." 2>&1");
								if (! $o) {
									/* Let the mount settle. */
									usleep(250 * 1000);

									/* Check to see if the dataset really mounted. */
									for ($i=0; $i < 5; $i++) {
										/* The device and mount point need to be mounted. */
										if (is_mounted($columns[0], $columns[1])) {
											unassigned_log("Successfully mounted zfs dataset '".$columns[0]."' on '".$columns[1]."'.");

											$dataset_mounted = true;

											break;
										} else {
											usleep(100 * 1000);
										}
									}
								}

								/* Was there an error? */
								if ($dataset_mounted) {
									$rc	= true;
								} else {
									unassigned_log("Warning: Mount of zfs dataset '".$columns[0]."' failed: '".$o."'");
								}
							} else {
								unassigned_log("Dataset '".$columns[0]."' already mounted");
							}
						}
					}
				}
			}

			/* If the file activity plugin is installed and ud is enabled, restart the file activity. */
			if (file_exists("/boot/config/plugins/file.activity/file.activity.cfg")) {
				$file_activity_cfg	= @parse_plugin_cfg("file.activity");
			}
			$file_activity_enabled	= $file_activity_cfg['INCLUDE_UD'] ?? "no";

			/* Restart file activity. */
			if ($file_activity_enabled == "yes") {
				run_file_activity();
			}
		}
	} else {
		unassigned_log("Warning: No file system detected on '".basename($dev)."'!");

		$rc	= false;
	}

	return $rc;
}

/* Mount root share. */
function do_mount_root($info) {
	global $paths, $var;

	$rc		= false;

	/* A rootshare device is treated similar to a CIFS mount.  The rootshare won't work if disks are shared. */
	if (($var['shareDisk'] != "yes") && ($var['shareUserExclusive'] != "yes")) {
		/* If the root server is not online, run the ping update and see if ping status needs to be refreshed. */
		if (! $info['alive']) {
			/* Update the root share server ping status. */
			$timed_cmd	= DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/get_ud_stats is_online ".escapeshellarg($info['ip'])." ".escapeshellarg($info['protocol']);
			timed_exec(0, $timed_cmd, true);

			/* See if the root share server is online now. */
			$info['alive'] = is_samba_server_online($info['ip'], $info['protocol']);
		}
	
		/* If server shows as being on-line, we can mount the rootshare. */
		if ($info['alive']) {
			$dir		= $info['mountpoint'];
			$fs			= $info['fstype'];

			/* Root share is read only due to limitations of fuse file system. */
			$ro			= true;

			$dev		= str_replace("//".$info['ip'], "", $info['path']);
			if (! $info['mounted']) {
				/* Create the mount point and set permissions. */
				@mkdir($dir, 0777, true);
				@chown($dir, 99);
				@chgrp($dir, 100);

				$params	= get_mount_params($fs, $dev, $ro);
				$cmd	= "/sbin/mount -o ".$params." ".escapeshellarg($dev)." ".escapeshellarg($dir);

				unassigned_log("Mount ROOT command: ".$cmd);

				/* Mount the root share. */
				$o		= timed_exec(30, $cmd." 2>&1");
				if ($o) {
					unassigned_log("Root mount failed: '".$o."'.");
				}

				/* Did the root share successfully mount? */
				if (is_mounted("", $dir)) {
					unassigned_log("Root Share is always mounted read only.");

					unassigned_log("Successfully mounted '".$dev."' on '".$dir."'.");

					$rc = true;
				} else {
					@rmdir($dir);
				}
			} else {
				unassigned_log("Root Share '".$dev."' is already mounted.");
			}
		} else {
			unassigned_log("Root Server '".$info['ip']."' is offline and remote share '".$info['path']."' cannot be mounted."); 
		}
	} else {
		unassigned_log("Root Server share '".$info['device']."' cannot be mounted with Disk or Exclusive Shares enabled."); 
	}

	return $rc;
}

/**
 * Wait for a mount point to become idle.
 *
 * @param string $dir Mount point path
 * @param int $timeout Timeout in seconds
 * @return bool True if idle, false on timeout
 */
function wait_for_mountpoint_idle($dir, $timeout = 300) {
	$rc		= true;
	$start	= time();

	while (is_dir($dir)) {
		$output	= [];
		$status	= 1;
		$cmd	= "/usr/bin/fuser -m ".escapeshellarg($dir)." >/dev/null 2>&1";

		exec($cmd, $output, $status);

		if ($status !== 0) {
			break;
		}

		if ((time() - $start) >= $timeout) {
			$rc = false;
			break;
		}

		sleep(1);
	}

	return $rc;
}

/* Unmount a device. */
function do_unmount($info, $unmount_mode = false) {
	global $paths;

	/* Default return value - failure. */
	$rc			= false;

	/* Initialize some variables. */
	$smb				= false;
	$nfs				= false;
	$zfs				= false;
	$root				= false;
	$unmount_type		= "";
	$unmount_mode		= ($unmount_mode ? "-l " : "");

	switch ($info['fstype']) {
		case ("crypto_LUKS"):
			if ($info['file_system'] == "zfs") {
				$zfs		= true;
				$pool_name	= $info['pool_name'];
			} else {
				$pool_name	= "";
			}
			$dev			= "";
			$timeout		= 90;
			break;

		case ("cifs"):
			$smb			= true;
			$dev			= $info['mount_dev'];
			$timeout		= ($unmount_mode ? 10 : 30);
			$unmount_type	= "-t cifs ";
			break;

		case ("nfs"):
			$nfs			= true;
			$dev			= $info['mount_dev'];
			$timeout		= ($unmount_mode ? 10 : 30);
			$unmount_type	= "-t nfs ";
			break;

		case ("root"):
		case ("loop"):
			$root			= true;
			$dev			= "";
			$timeout		= 10;
			break;

		default:
			$dev			= $info['device'];
			if ($info['file_system'] == "zfs") {
				$zfs		= true;
				$pool_name	= $info['pool_name'];
			} else {
				$pool_name	= "";
			}

			if ($info['file_system'] == "vfat") {
				$timeout	= 180;
			} else {
				$timeout	= 90;
			}
			break;
	}

	$dir		= $info['mountpoint'];

	$mounted	= (($zfs) && ($pool_name)) ? (is_mounted($pool_name, $dir)) : (is_mounted($dev, $dir));
	if ($mounted) {
		/* Are we shutting down Unraid? */
		if (((! $unmount_mode) || (($unmount_mode) && (! $smb) && (! $nfs))) && (! is_mounted_read_only($dir))) {
			unassigned_log("Synching file system on '".$dir."'...");
			if ($zfs) {
				if (! $unmount_mode) {
					/* Sync the file system and wait for it to be done. */
					$timed_cmd	= "/usr/sbin/zpool sync ".escapeshellarg($pool_name)." 2>/dev/null";
					timed_exec($timeout, $timed_cmd, true);
				} else {
					/* Time out so sync command doesn't get stuck. */
					$timed_cmd	= "/usr/sbin/zpool sync ".escapeshellarg($pool_name)." 2>/dev/null";
					timed_exec($timeout, $timed_cmd);
				}
			} else if ((! $unmount_mode) && (! $smb) && (! $nfs)) {
				/* Sync the file system and wait for it to be done. */
				$timed_cmd	= "/bin/sync -f ".escapeshellarg($dir)." 2>/dev/null";
				timed_exec($timeout, $timed_cmd);
			} else {
				/* Time out so sync command doesn't get stuck. */
				$timed_cmd	= "/bin/sync -f ".escapeshellarg($dir)." 2>/dev/null";
				timed_exec($timeout, $timed_cmd);
			}
		}

		if ($zfs) {
			/* Clear readonly flag. */
			$timed_cmd	= "/usr/sbin/zfs set readonly=off ".escapeshellarg($pool_name)." 2>/dev/null";
			timed_exec(3, $timed_cmd, true);

			/* Unmount zfs file system. */
			$cmd = ("/usr/sbin/zfs unmount ".escapeshellarg($dir)." 2>&1");
		} else {
			/* The umount flags are set depending on the unmount conditions. */
			$cmd = "/sbin/umount ".$unmount_type.$unmount_mode.escapeshellarg($dir)." 2>&1";
		}

		unassigned_log("Unmount cmd: ".$cmd);

		if (($zfs) && (! $pool_name)) {
			$o = "Warning: Cannot determine Pool Name of '".$dev."'";
		} else {
			/* Check to see if the device really unmounted. */
			/* The device and mount point both need to be unmounted. */
			if (($zfs) && ($pool_name)) {
				$mounted_dev	= $pool_name;
			} else {
				$mounted_dev	= $dev;
			}

			/* For hard disks be sure the mount point is not busy. */
			if ((! $smb) && (! $nfs) && (! $root) && (! wait_for_mountpoint_idle($dir, 300))) {
				unassigned_log("Mountpoint '".$dir."' is still busy - unmount deferred.");
				$unmounted = false;
			} else {
				$o = timed_exec($timeout, $cmd);
				usleep(250 * 1000);

				$unmounted = wait_for_unmounted($mounted_dev, $dir);
			}

			if ($unmounted) {
				if (is_dir($dir)) {
					/* Remove the mount point. */
					@rmdir($dir);

					/* Remove the legacy symlink on /mnt/disks/. */
					$link = $paths['usb_mountpoint']."/".basename($dir);
					if (is_link($link)) {
						@unlink($link);
					}
				}

				if ((! $smb) && (! $nfs) && (! $root)) {
					/* If the file activity plugin is installed and ud is enabled, restart the file activity. */
					if (file_exists("/boot/config/plugins/file.activity/file.activity.cfg")) {
						$file_activity_cfg	= @parse_plugin_cfg("file.activity");
					}
					$file_activity_enabled	= $file_activity_cfg['INCLUDE_UD'] ?? "no";

					/* Restart file activity. */
					if ($file_activity_enabled == "yes") {
						run_file_activity();
					}
				}

				/* Remove saved pool devices if this is a btrfs pooled device. */
				if ($info['fstype'] == "btrfs") {
					MiscUD::get_pool_devices($dir, true);
				}

				unassigned_log("Successfully unmounted '".($dev ? $dev : $dir)."'");

				$rc = true;
			}
		}

		if (! $rc) {
			unassigned_log("Unmount of '".($dev ? $dev : $dir)."' failed: '".$o."'"); 
		} else if ($zfs) {
			$timed_cmd	= "/usr/sbin/zpool export ".escapeshellarg($pool_name)." 2>/dev/null";
			timed_exec(3, $timed_cmd, true);
		}
	} else {
		if (($zfs) && (! $pool_name)) {
			unassigned_log("Cannot determine Pool Name of '".$dev."'");
		} else {
			unassigned_log("Cannot unmount '".($dev ? $dev : $dir)."'. UD did not mount the device or it was not properly unmounted.");
		}
	}

	if (($rc) && ($info['fstype'] == "crypto_LUKS")) {
		/* Close the luks device. */
		MiscUD::luks_close_device($info['device']);
	}

	return $rc;
}

#########################################################
############		SHARE FUNCTIONS			#############
#########################################################
/* Is the samba share on? */
function config_shared($serial, $part, $usb = false) {
	$share		= get_config($serial, "share.{$part}");
	$auto_usb	= get_config("Config", "automount_usb");

	return (($share == "yes") || ($usb && $auto_usb == "yes")); 
}

/* Toggle samba share on/off. */
function toggle_share($serial, $part, $status) {
	$new 	= ($status == "true") ? "yes" : "no";
	set_config($serial, "share.{$part}", $new);

	return ($new == "yes");
}

/* Add mountpoint to samba shares. */
function add_smb_share($dir, $recycle_bin = false, $fat_fruit = false) {
	global $paths, $var, $users, $ud_config;

	/* Get the current UD configuration. */
	$config							= $ud_config["Config"];

	/* Initialize some settings to make sure they are defined. */
	$SMB_Sharing					= $config['SMB_Sharing'] ?? "";
	$config['force_user']			= $config['force_user'] ?? "";
	$config['hidden_share']			= $config['hidden_share'] ?? "";

	/* Force user setting. */
	$force_user 					= ($config['force_user'] == "yes") ? "\n\tforce User = nobody" : "";

	/* Get the time machine settings. */
	$config['time_machine']			= $config['time_machine'] ?? "";
	$time_machine 					= ($config['time_machine'] == "yes") ? "\n\tfruit:time machine = yes" : "";
	$Config['time_mach_vol_size']	= $config['time_mach_vol_size'] ?? "";
	$time_mach_vol_size				= (($config['time_machine'] == "yes") && ($config['time_mach_vol_size'])) ? "\n\tfruit:time machine max size = ".intval($config['time_mach_vol_size'])."M" : "";

	/* Set whether or not the share is browseable and set browseable setting. */
	$hidden_share					= ($SMB_Sharing == "hidden") ? "\n\tbrowseable = no" : "\n\tbrowseable = yes";

	/* Is the Mac OS interoperability setting on? */
	$enable_fruit					= ($var['enableFruit'] == "yes");

	/* Add mountpoint to samba shares. */
	if (($var['shareSMBEnabled'] != "no") && ($SMB_Sharing != "no")) {
		/* Remove special characters from share name. */
		$share_name		= str_replace( array("(", ")"), "", basename($dir));

		/* Initialize the vfs_objects variable with the dirsort option. */
		$vfs_objects	= "vfs objects = dirsort";

		/* Add the Mac OS stuff if enabled. */
		if ($enable_fruit) {
			if (! $fat_fruit) {
				/* See if the smb-fruit.conf from the /boot/config/ folder. */
				$fruit_file = "/boot/config/smb-fruit.conf";
				if (file_exists($fruit_file)) {
					$fruit_file_settings = explode("\n", file_get_contents($fruit_file));
				} else {
					/* Use the smb-fruit.conf from the /etc/samba/ folder. */
					$fruit_file = "/etc/samba/smb-fruit.conf";
					if (file_exists($fruit_file)) {
						$fruit_file_settings = explode("\n", file_get_contents($fruit_file));
					} else {
						$vfs_objects	.= " catia fruit streams_xattr";
						$fruit_file_settings = array( $vfs_objects );
					}

					/* Set up time machine parameters. */
					if ($config['time_machine'] == "yes") {
						$fruit_file_settings[] = $time_machine;
						$fruit_file_settings[] = $time_mach_vol_size;
						$fruit_file_settings[] = "\n\tfruit:metadata = stream";
					}
				}
			} else {
				/* For fat and exfat file systems. */
				$vfs_objects		.= " catia fruit";
				$fruit_file_settings = array( $vfs_objects );
			}

			/* Apply the fruit settings. */
			$vfs_objects	= "";
			foreach ($fruit_file_settings as $line) {
				/* Remove comment lines. */
				if (($line) && (strpos($line, "#") === false)) {
					if (strpos($line, "vfs objects =") === 0) {
						/* Add 'dirsort' to vfs objects. */
						$line = preg_replace('/(vfs objects = )/', '$1dirsort ', $line, 1);
					}

					$vfs_objects .= "\n\t".$line;
				}
			}
		} else {
			$vfs_objects	= "\n\t".$vfs_objects;
		}

		if (($SMB_Sharing == "yes") || ($SMB_Sharing == "hidden")) {
			$read_users		= [];
			$write_users	= [];
			$valid_users	= array_keys($users);;

			/* Remove the root user. */
			$valid_users	= array_diff($valid_users, ["root"]);

			/* Get the valid users from the UD config, and create an array of read and write users. */
			$invalid_users = array_filter($valid_users, function ($v) use ($config, &$read_users, &$write_users) {
				switch ($config["smb_$v"]) {
					case "read-only":
						$read_users[] = $v;
						break;
					case "read-write":
						$write_users[] = $v;
						break;
					default:
						return $v;
				}
			});

			/* Remove the invalid users. */
			$valid_users		= array_diff($valid_users, $invalid_users);

			/* File name case settings. */
			$case_setting		= (($config["case_names"] === 'force') || ((! $config["case_names"]))) ? "auto" : $config["case_names"];
			$case_names			= "\n\tcase sensitive = ".$case_setting."\n\tpreserve case = yes\n\tshort preserve case = yes";

			/* Add the valid users and their access. */
			if (count($valid_users)) {
				$valid_users	= "\n\tvalid users = ".implode(' ', $valid_users);
				$write_users	= count($write_users) ? "\n\twrite list = ".implode(' ', $write_users) : "";
				$read_users		= count($read_users) ? "\n\tread list = ".implode(' ', $read_users) : "";
				$share_cont		= "[{$share_name}]\n\tcomment = {$share_name}\n\tpath = {$dir}{$hidden_share}{$force_user}{$valid_users}{$write_users}{$read_users}{$vfs_objects}{$case_names}";
			} else {
				$share_cont 	= "[{$share_name}]\n\tpath = {$dir}{$hidden_share}\n\tinvalid users = @users";
				unassigned_log("Warning: No valid smb users defined. Share '{$dir}' cannot be accessed with smb.");
			}
		} else {
			$share_cont = "[{$share_name}]\n\tpath = {$dir}\n\tread only = No\n\tguest ok = Yes{$force_user}{$vfs_objects}";
		}

		if (! is_dir($paths['smb_usb_shares'])) {
			@mkdir($paths['smb_usb_shares'], 0755, true);
		}
		$share_conf = preg_replace("#\s+#", "_", realpath($paths['smb_usb_shares'])."/".$share_name.".conf");

		unassigned_log("Adding SMB share '{$share_name}'.");

		@file_put_contents($share_conf, $share_cont);
		if (! (new MiscUD)->exist_in_file($paths['smb_unassigned'], $share_conf)) {
			$c		= (is_file($paths['smb_unassigned'])) ? @file($paths['smb_unassigned'], FILE_IGNORE_NEW_LINES) : [];
			$c[]	= "include = $share_conf";

			/* Do some cleanup. */
			$smb_unassigned_includes = array_unique(preg_grep("/include/i", $c));
			foreach($smb_unassigned_includes as $key => $inc) {
				if (! is_file(parse_ini_string($inc)['include'])) {
					unset($smb_unassigned_includes[$key]);
				}
			} 
			$c		= array_merge(preg_grep("/include/i", $c, PREG_GREP_INVERT), $smb_unassigned_includes);
			$c		= preg_replace('/\n\s*\n\s*\n/s', PHP_EOL.PHP_EOL, implode(PHP_EOL, $c));
			@file_put_contents($paths['smb_unassigned'], $c);

			/* Add the [global] tag to the end of the share file. */
			@file_put_contents($share_conf, "\n[global]\n", FILE_APPEND);

			/* Only proceed if Samba is running */
			$timed_cmd		= "/usr/bin/pgrep -x smbd >/dev/null 2>&1";
			timed_exec(0, $timed_cmd, true, $ret_code);

			if ($ret_code === 0) {
				$timed_cmd	= "/usr/bin/smbcontrol all reload-config 2>&1";
				timed_exec(10, $timed_cmd, true);
				sleep(1);

				/* Make sure wsdd2 is running. */
				$timed_cmd	= "/usr/bin/pgrep -x wsdd2 >/dev/null 2>&1";
				timed_exec(0, $timed_cmd, true, $ret_code);

				if ($ret_code != 0) {
					sleep(1);

					/* Start wsdd2 using Unraid's system script if not already running */
					$timed_cmd	= "/etc/rc.d/rc.wsdd2 start >/dev/null 2>&1 &";
					timed_exec(0, $timed_cmd, true);
				}
			}

			/* If the recycle bin plugin is installed, add the recycle bin to the share. */
			if ($recycle_bin) {
				/* Get the current UD configuration. */
				$config			= $ud_config["Config"];

				/* Initialize some settings to make sure they are defined. */
				$SMB_Sharing	= $config['SMB_Sharing'] ?? "";

				if (file_exists("/boot/config/plugins/recycle.bin/recycle.bin.cfg")) {
					$recycle_bin_cfg	= @parse_plugin_cfg("recycle.bin");
				}
				$recycle_bin_enabled	= $recycle_bin_cfg['INCLUDE_UD'] ?? "no";

				/* Reconfigure the recycle bin. */
				if (($var['shareSMBEnabled'] != "no") && ($SMB_Sharing != "no") && ($recycle_bin_enabled == "yes")) {
					run_recycle_bin(true, $share_name);
				}
			}
		}
	} else {
		unassigned_log("Warning: Unassigned Devices are not set to be shared with SMB.");
	}

	return true;
}

/* Remove mountpoint from samba shares. */
function remove_smb_share($dir, $recycle_bin = false) {
	global $paths, $var, $ud_config;

	/* Remove special characters from share name */
	$share_name = str_replace( array("(", ")"), "", basename($dir));
	$share_conf = preg_replace("#\s+#", "_", realpath($paths['smb_usb_shares'])."/".$share_name.".conf");
	if (is_file($share_conf)) {
		unassigned_log("Removing SMB share '".$share_name."'.");
		@unlink($share_conf);
	}

	if (MiscUD::exist_in_file($paths['smb_unassigned'], $share_conf)) {
		$c = (is_file($paths['smb_unassigned'])) ? @file($paths['smb_unassigned'], FILE_IGNORE_NEW_LINES) : [];

		/* Do some cleanup. */
		$smb_unassigned_includes = array_unique(preg_grep("/include/i", $c));
		foreach($smb_unassigned_includes as $key => $inc) {
			if (! is_file(parse_ini_string($inc)['include'])) {
				unset($smb_unassigned_includes[$key]);
			}
		} 
		$c = array_merge(preg_grep("/include/i", $c, PREG_GREP_INVERT), $smb_unassigned_includes);
		$c = preg_replace('/\n\s*\n\s*\n/s', PHP_EOL.PHP_EOL, implode(PHP_EOL, $c));
		@file_put_contents($paths['smb_unassigned'], $c);

		/* Only proceed if Samba is running */
		$timed_cmd		= "/usr/bin/pgrep -x smbd >/dev/null 2>&1";
		timed_exec(0, $timed_cmd, true, $ret_code);

		if ($ret_code === 0) {
			$timed_cmd	= "/usr/bin/smbcontrol all close-share ".escapeshellarg($share_name)." 2>&1";
			timed_exec(10, $timed_cmd, true);

			$timed_cmd	= "/usr/bin/smbcontrol all reload-config 2>&1";
			timed_exec(10, $timed_cmd, true);

			/* Make sure wsdd2 is running. */
			$timed_cmd	= "/usr/bin/pgrep -x wsdd2 >/dev/null 2>&1";
			timed_exec(0, $timed_cmd, true, $ret_code);

			if ($ret_code != 0) {
				sleep(1);

				/* Start wsdd2 using Unraid's system script if not already running */
				$timed_cmd	= "/etc/rc.d/rc.wsdd2 start >/dev/null 2>&1 &";
				timed_exec(0, $timed_cmd, true);
			}
		}

		/* If the recycle bin plugin is installed, add the recycle bin to the share. */
		if ($recycle_bin) {
			/* Get the current UD configuration. */
			$config			= $ud_config["Config"];

			/* Initialize some settings to make sure they are defined. */
			$SMB_Sharing	= $config['SMB_Sharing'] ?? "";

			if (file_exists("/boot/config/plugins/recycle.bin/recycle.bin.cfg")) {
				$recycle_bin_cfg	= @parse_plugin_cfg("recycle.bin");
			}
			$recycle_bin_enabled	= $recycle_bin_cfg['INCLUDE_UD'] ?? "no";

			/* Reconfigure the recycle bin. */
			if (($var['shareSMBEnabled'] != "no") && ($SMB_Sharing != "no") && ($recycle_bin_enabled == "yes")) {
				run_recycle_bin(false, $share_name);
			}
		}
	}

	return true;
}

/* Add a mountpoint to NFS shares. */
function add_nfs_share($dir, $fs_type = "nfs") {
	global $var;

	/* If NFS is enabled and export setting is 'yes' then add NFS share. */
	if (($var['shareNFSEnabled'] == "yes") && ($fs_type != "nfs")) {
		if (get_config("Config", "NFS_Export") == "yes") {
			$reload = false;

			/* Get a lock so file changes can be made. */
			$lock_file		= get_file_lock("exportfs");

			foreach (array("/etc/exports", "/etc/exports-") as $file) {
				$c = (is_file($file)) ? @file($file, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) : [];

				/* Extract all fsid values already in the file */
				$existing_fsid = [];
				foreach ($c as $line) {
					if (preg_match('/-fsid=(\d+)/', $line, $matches)) {
						$existing_fsid[] = (int)$matches[1];
					}
				}

				/* Generate a unique fsid */
				$fsid = 200;
				while (in_array($fsid, $existing_fsid)) {
					$fsid++;
				}

				$nfs_sec = get_config("Config", "NFS_Security");
				if ($nfs_sec == "private") {
					$nfs_rule = get_config("Config", "nfs_rule");
					$sec = ($nfs_rule) ? explode(";", $nfs_rule) : ["*(rw,sec=sys,insecure,anongid=100,anonuid=99,no_root_squash)"];
				} else {
					$sec = ["*(rw,sec=sys,insecure,anongid=100,anonuid=99,all_squash)"];
				}

				/* Ensure fsid does not already exist in the file */
				$new_entries = [];
				foreach ($sec as $security) {
					if ($security) {
						$new_entry = "\"{$dir}\" -fsid={$fsid},async,no_subtree_check {$security}";

						/* Only add if the fsid is not already in the file */
						if (! preg_grep("/-fsid={$fsid}\b/", $c)) {
							$new_entries[] = $new_entry;
						}
					}
				}

				if ($new_entries) {
					$c = array_merge($c, $new_entries);
					$c[] = ""; /* Ensure a newline at the end */
					@file_put_contents($file, implode(PHP_EOL, $c));
					$reload = true;
				}
			}

			/* Release the file lock. */
			release_file_lock($lock_file);

			if ($reload) {
				unassigned_log("Adding NFS share '".$dir."'.");
				$timed_cmd	= "/usr/sbin/exportfs -ra 2>/dev/null";
				timed_exec(3, $timed_cmd, true);
			}
		} else {
			unassigned_log("Warning: Unassigned Devices are not set to be shared with NFS.");
		}
	}

	return true;
}

/* Remove a mountpoint from NFS shares. */
function remove_nfs_share($dir, $file_type = "nfs") {

	if ($file_type != "nfs") {
		/* Remove this disk from the exports file. */
		$reload = false;

		/* Get a lock so file changes can be made. */
		$lock_file		= get_file_lock("exportfs");

		foreach (array("/etc/exports","/etc/exports-") as $file) {
			if ( MiscUD::exist_in_file($file, $dir) && strlen($dir)) {

				/* Read the contents of the file into an array. */
				$fileLines	= file($file, FILE_IGNORE_NEW_LINES);

				$updatedLines = array_filter($fileLines, function($line) use ($dir) {
					return (strpos($line, $dir) === false);
				});

				/* Add a final empty line. */
				$updatedLines[]	= "";

				/* Combine the updated lines into a single string. */
				$updatedContent = implode("\n", $updatedLines);

				/* Write the updated content back to the file. */
				file_put_contents($file, $updatedContent);

				$reload	= true;
			}
		}

		/* Release the file lock. */
		release_file_lock($lock_file);

		if ($reload) {
			unassigned_log("Removing NFS share '".$dir."'.");
			$timed_cmd	= "/usr/sbin/exportfs -ra 2>/dev/null";
			timed_exec(3, $timed_cmd, true);
		}
	}

	return true;
}

/* Remove all samba and NFS shares for mounted devices. */
function remove_shares() {
	/* Disk mounts */
	foreach (get_unassigned_disks() as $name => $disk) {
		foreach ($disk['partitions'] as $p) {
			$info = get_partition_info($p);

			if ( $info['mounted'] ) {
				remove_smb_share($info['mountpoint'], (! $info['read_only']));
				remove_nfs_share($info['mountpoint'], $info['fstype']);
			}
		}
	}

	/* SMB Mounts */
	foreach (get_samba_mounts() as $name => $info) {
		if ( $info['mounted'] ) {
			remove_smb_share($info['mountpoint']);
			remove_nfs_share($info['mountpoint'], $info['fstype']);
		}
	}

	/* ISO File Mounts */
	foreach (get_iso_mounts() as $name => $info) {
		if ( $info['mounted'] ) {
			remove_smb_share($info['mountpoint']);
			remove_nfs_share($info['mountpoint'], $info['fstype']);
		}
	}
}

/* Reload disk, samba and NFS shares. */
function reload_shares() {
	/* Disk mounts */
	foreach (get_unassigned_disks() as $name => $disk) {
		foreach ($disk['partitions'] as $p) {
			$info = get_partition_info($p);
			if ( $info['mounted'] && $info['shared'] ) {
				$fat_fruit = (($info['fstype'] == "vfat") || ($info['fstype'] == "exfat"));
				add_smb_share($info['mountpoint'], (! $info['read_only']), $fat_fruit);
				add_nfs_share($info['mountpoint'], $info['fstype']);
			}
		}
	}

	/* SMB Mounts */
	foreach (get_samba_mounts() as $name => $info) {
		if ( ($info['mounted']) && ($info['smb_share']) ) {
			add_smb_share($info['mountpoint'], $info['fstype'] == "root");
			add_nfs_share($info['mountpoint'], $info['fstype']);
		}
	}

	/* ISO File Mounts */
	foreach (get_iso_mounts() as $name => $info) {
		if ( $info['mounted'] ) {
			add_smb_share($info['mountpoint']);
			add_nfs_share($info['mountpoint'], $info['fstype']);
		}
	}
}

#########################################################
############		SAMBA FUNCTIONS			#############
#########################################################
/* Get samba mount configuration parameter. */
function get_samba_config($source, $variable) {
	global $samba_config;

	return $samba_config[$source][$variable] ?? "";
}

/* Set samba mount configuration parameter. */
function set_samba_config($source, $variable, $value) {
	global $samba_config;

	/* Verify we have a serial number. */
	if ($source) {
		/* Make file changes. */
		$samba_config[$source][$variable] = $value;
		save_ini_file(SAMBA_MOUNT, $samba_config);

		$rc	= (isset($samba_config[$source][$variable]));
	} else {
		$rc	= false;
	}

	return $rc;
}

function encrypt_data($data) {
    $key	= get_config("Config", "key");
    $iv		= get_config("Config", "iv");

	if ((! $key) || (! $iv)) {
		/* Get a lock so file changes can be made. */
		$lock_file		= get_file_lock("encrypt");

		if (! $key || strlen($key) != 32) {
			$key = substr(base64_encode(openssl_random_pseudo_bytes(32)), 0, 32);
			set_config("Config", "key", $key);
		}

		if (! $iv || strlen($iv) != 16) {
			$iv = substr(base64_encode(openssl_random_pseudo_bytes(16)), 0, 16);
			set_config("Config", "iv", $iv);
		}

		/* Release the file lock. */
		release_file_lock($lock_file);
	}

    /* Encrypt the data using aes-256-cbc (ensure mode and padding are specified). */
    $encrypted = openssl_encrypt($data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);

    /* Base64 encode the encrypted data. */
    $value = base64_encode($encrypted);

    return $value;
}

function decrypt_data($data) {
    $key = get_config("Config", "key");
    $iv  = get_config("Config", "iv");

    /* Base64 decode before decryption. */
    $encrypted_data = base64_decode(stripslashes($data));

    /* Decrypt the data using aes-256-cbc. */
    $decrypted = openssl_decrypt($encrypted_data, 'aes-256-cbc', $key, OPENSSL_RAW_DATA, $iv);

    /* Ensure the decrypted data is UTF-8 encoded. */
    if (! mb_check_encoding($decrypted, 'UTF-8')) {
        unassigned_log("Warning: Data is not UTF-8 encoded");
        $decrypted = "";
    }

    return $decrypted;
}

/* Is the samba mount set for auto mount? */
function is_samba_automount($serial) {
	$auto	= get_samba_config($serial, "automount");

	return ($auto == "yes");
}

/* Is the samba mount set to share? */
function is_samba_share($serial) {
	$smb_share	= get_samba_config($serial, "smb_share");

	return ($smb_share == "yes");
}

/* Is disable mount enabled. */
function is_samba_disable_mount($serial) {
	$disable_mount	= get_samba_config($serial, "disable_mount");

	return ($disable_mount == "yes");
}

/* Is the samba mount set to read only? */
function is_samba_read_only($serial) {
	$smb_readonly	= get_samba_config($serial, "read_only");

	return ($smb_readonly == "yes");
}

/* Is the samba mount set to read only? */
function is_samba_encrypted($serial) {
	$smb_encrypt	= get_samba_config($serial, "encryption");

	return ($smb_encrypt == "yes");
}

/* Get all defined samba and NFS remote shares. */
function get_samba_mounts() {
	global $paths, $samba_config, $default_tld, $local_tld;

	$return			= [];

	/* Get all the samba devices from the configuration. */
	$samba_mounts	= $samba_config;
	if (is_array($samba_mounts)) {
		ksort($samba_mounts, SORT_NATURAL | SORT_FLAG_CASE);

		/* Get all the samba mounts. */
		foreach ($samba_mounts as $device => $mount) {
			/* Convert the device to a safe name samba device. */
			$safe_device				= safe_name($device, false);
			$mount['device']			= $device;
			if ($device) {
				$mount['name']			= $safe_device;
				$mount['mountpoint']	= $mount['mountpoint'] ?? "";
				$mount['ip']			= $mount['ip'] ?? "";
				$mount['protocol']		= $mount['protocol'] ?? "";
				$mount['path']			= $mount['path'] ?? "";
				$mount['share']			= $mount['share'] ?? "";
				$mount['share']			= safe_name($mount['share'], false);

				/* Set the mount point and file system. */
				switch ($mount['protocol']) {
					case "NFS":
						$mount['fstype']	= "nfs";
						$path				= $mount['share'];
						break;

					case "ROOT":
						$mount['fstype']	= "root";
						$root_type			= $mount['share'] == "user" ? "Shares-Pools" : "Shares-NoPools";
						$path				= $mount['mountpoint'] ? $mount['mountpoint'] : $root_type;
						break;

					default:
						$mount['fstype']	= "cifs";
						$path				= $mount['share'];
						break;
				}

				/* This is the mount device for checking for an invalid configuration. */
				$dev_check				= ($mount['fstype'] == "nfs") ? $mount['ip'].":".$mount['path'] : "//".$mount['ip'].(($mount['fstype'] == "cifs") ? "/" : "") .$mount['path'];

				/* Remove the 'local' and 'default' tld reference as they are unnecessary. */
				if (! MiscUD::is_ip($mount['ip'])) {
					$dev_check			= str_replace( array(".".$local_tld, ".".$default_tld), "", $dev_check);
				}

				/* Is the remote server on line? */
				$mount['alive']			= is_samba_server_online($mount['ip'], $mount['protocol']);

				/* Is read only enabled? */
				$mount['read_only']		= is_samba_read_only($mount['name']);

				/* Is auto mount enabled? */
				$mount['automount']		= is_samba_automount($mount['name']);

				/* Is smb and nfs sharing enabled? */
				$mount['smb_share']		= is_samba_share($mount['name']);

				/* Is the mount button set disabled? */
				$mount['disable_mount']	= is_samba_disable_mount($mount['name']);

				if ($mount['fstype'] == "root") {
					$mount['mountpoint'] = $paths['root_mountpoint']."/".$path;
				} else {
					/* Determine the mountpoint for this remote share. */
					if (! $mount['mountpoint']) {
						$mount_ip			= str_replace( array(".".$local_tld, ".".$default_tld), "", $mount['ip']);

						/* Deal with ipv6 addresses. */
						$mount_ip			= str_replace(array('::', ':'), '_', $mount_ip);

						$mount['mountpoint'] = $paths['remote_mountpoint']."/".$mount_ip."_".basename($path);
					} else {
						$path = basename($mount['mountpoint']);
						$mount['mountpoint'] = $paths['remote_mountpoint']."/".$path;
					}
				}

				/* Deal with IPv6 addresses. */
				if (MiscUD::is_ipv6($mount['ip'])) {
					/* Find the interface that has this link-local address. */
					$mount_ip	= "[".$mount['ip']."]";
				} else {
					$mount_ip	= $mount['ip'];
				}

				/* This is the device that is actually mounted based on the protocol and is used to check mounted status. */
				$mount['mount_dev']		= ($mount['fstype'] == "nfs") ? $mount_ip.":".$mount['path'] : (($mount['fstype'] == "cifs") ? "//".$mount_ip."/".$mount['path'] : $mount['mountpoint']);

				/* Check for mounting/unmounting state. */
				$mount_device			= safe_name(basename($mount['ip'])."_".basename(dirname($mount['path']))."_".basename($mount['path']), true, true);

				$mount['mounting']		= MiscUD::get_mount_state($mount_device, 'mounting');
				$mount['unmounting']	= MiscUD::get_mount_state($mount_device, 'unmounting');

				/* Is remote share mounted? */
				if ($mount['fstype'] != "root") {
					$mount['mounted']		= is_mounted($mount['mount_dev'], $mount['mountpoint'], false);
				} else {
					$mount['mounted']		= is_mounted("", $mount['mount_dev'], false);
				}

				/* Is the remote share mounted read only? */
				$mount['remote_read_only']	= $mount['mounted'] ? is_mounted_read_only($mount['mountpoint']) : false;

				/* Check that the device built from the ip and path is consistent with the config file device. */
				$check_device			= safe_name($dev_check, false);

				/* Remove dollar signs in device.  Windows uses a '$' to indicate a hidden folder. */
				$check_device			= str_replace("$", "", $check_device);

				/* If this is a legacy samba mount or is misconfigured, indicate that it should be removed and added back. */
				if ($mount['fstype'] == "root") {
					$mount['invalid']	= false;
				} else {
					$mount['invalid']	= (($safe_device != $device) || ($safe_device != $check_device) || (($mount['alive']) && ($mount['protocol'] == "NFS") && (! check_remote_nfs_path($mount['ip'], $mount['path']))));
				}

				/* Is the mount point accessible? */
				$is_accessible			= ($mount['mounted'] && $mount['alive']) ? MiscUD::is_mount_accessible($mount['mountpoint']) : false;

				/* Get the disk size, used, and free stats. */
				$stats					= get_device_stats($mount['mountpoint'], $mount['mounted'], ($mount['alive'] && $is_accessible));
				$mount['size']			= $stats[0]*1024;
				$mount['used']			= $stats[1]*1024;
				$mount['avail']			= $stats[2]*1024;

				/* Set owner as if the remote share is being hot plugged. */
				$mount['owner']			= "user";

				/* If the device size is zero, or the mount point is not accessible, the remote mount is effectively offline. */
				$mount['available'] = ($mount['mounted'] ? ($mount['size'] != 0 && $is_accessible) : $mount['alive']);

				$mount['command']		= get_samba_config($mount['device'], "command");
				$mount['enable_script']	= $mount['command'] ? get_samba_config($mount['device'], "enable_script") : "false";
				$mount['encryption']	= is_samba_encrypted($mount['device']);
				$mount['cifs_uid']		= get_samba_config($mount['device'], "cifs_uid");
				$mount['cifs_gid']		= get_samba_config($mount['device'], "cifs_gid");
				$mount['cifs_cache']	= get_samba_config($mount['device'], "cifs_cache");
				$mount['prog_name']		= basename($mount['command'], ".sh");
				$mount['user_command']	= get_samba_config($mount['device'], "user_command");
				$mount['common_cmd']	= get_config("Config", "common_cmd");
				$mount['logfile']		= ($mount['prog_name']) ? $paths['device_log'].$mount['prog_name'].".log" : "";
				$mount['running']		= ($mount['mounted']) ? ((is_script_running($mount['command'])) || (is_script_running($mount['user_command'], true))) : false;

				/* Add to return array. */
				$return[]				= $mount;
			}
		}
	} else {
		unassigned_log("Error: unable to get the samba mounts.");
	}

	return $return;
}

/*
 * Attempt an SMB mount using an optional vers= and other extra params.
 * Returns true on success, false on failure.
 */
function smb_try_mount($fs, $dir, $dev, $log_dev, $ro, $extra_params, $cifs_cache, $cifs_uid, $cifs_gid, $cifs_actimeo, $credentials) {
	$rc		= false;
	$o		= '';

	$params	= sprintf(get_mount_params($fs, $dir, $ro, ''), $extra_params, $cifs_cache, $cifs_uid, $cifs_gid, $cifs_actimeo, $credentials);
	$cmd	= "/sbin/mount -t ".escapeshellarg($fs)." -o ".$params." ".escapeshellarg($dev)." ".escapeshellarg($dir);

	$proto	= 'default';
	if (preg_match('/(?:^|,)vers=([0-9.]+)/', $extra_params, $m)) {
		$proto = $m[1];
	}

	unassigned_log("Mount SMB share '".$log_dev."' using SMB ".$proto." protocol.");
	unassigned_log("Mount SMB command: ".$cmd);

	$o = timed_exec(30, $cmd." 2>&1");

	/* If auth/network hard-failed, don't keep cycling versions. */
	if ((strpos($o, "Permission denied") !== false) || (strpos($o, "Network is unreachable") !== false)) {
		$rc = false;
	} else {
		$rc = wait_for_mounted($dev);
	}

	return $rc;
}

/* Mount a remote samba or NFS share. */
function do_mount_samba($info) {
	global $paths, $var;

	$rc				= false;

	/* If the remote server is not online, run the ping update and see if ping status needs to be refreshed. */
	if (! $info['alive']) {
		/* Update the remote server ping status. */
		$timed_cmd	= DOCROOT."/plugins/".UNASSIGNED_PLUGIN."/scripts/get_ud_stats is_online ".escapeshellarg($info['ip'])." ".escapeshellarg($info['protocol']);
		timed_exec(0, $timed_cmd, true);

		/* See if the server is online now. */
		$info['alive'] = is_samba_server_online($info['ip'], $info['protocol']);
	}

	/* If the remote share is available, mount it. */
	if ($info['alive']) {
		$dir		= $info['mountpoint'];
		$fs			= $info['fstype'];
		$ro			= $info['read_only'];
		$dev		= $info['mount_dev'];

		/* Remove the ipv6 indicators from device in the log message. */
		$log_dev	= str_replace(array('[', ']'), '', $dev);

		if (! $info['mounted']) {
			/* Create the mount point and set permissions. */
			if (! is_dir($dir)) {
				@mkdir($dir, 0777, true);
				@chown($dir, 99);
				@chgrp($dir, 100);
			}

			if ($fs == "nfs") {
				if ($var['shareNFSEnabled'] == "yes") {
					if (check_remote_nfs_path($info['ip'], $info['path'])) {
						$params	= get_mount_params($fs, $dev, $ro);
						$nfs	= get_config("Config", "NFS_Version") == "4" ? "nfs4" : "nfs";
						$cmd	= "/sbin/mount -t ".escapeshellarg($nfs)." -o ".$params." ".escapeshellarg($dev)." ".escapeshellarg($dir);

						unassigned_log("Mount NFS command: ".$cmd);

						/* Mount the remote share. */
						$o		= timed_exec(30, $cmd." 2>&1");
						if ($o) {
							unassigned_log("NFS mount failed: '".$o."'.");
						}
					} else {
						unassigned_log("Warning: The remote path has changed and the NFS share '".$log_dev."' cannot be mounted.");
					}
				} else {
					unassigned_log("Warning: NFS must be enabled in 'Settings->NFS' to mount NFS remote shares.");
				}
			} else if ($var['shareSMBEnabled'] != "no") {
				/*
				 * Mount SMB with a version fallback list.
				 */

				/* Create the credentials file. */
				$credentials_file	= "{$paths['credentials']}_".basename($dir);
				@file_put_contents("$credentials_file", "username=".($info['user'] ? $info['user'] : 'guest')."\n");
				@file_put_contents("$credentials_file", "password=".decrypt_data($info['pass'])."\n", FILE_APPEND);
				@file_put_contents("$credentials_file", "domain=".$info['domain']."\n", FILE_APPEND);

				/* Change credentials file permissions. */
				@chmod($credentials_file, 0600);

				/* Credentials file parameter. */
				$credentials	= "credentials=".escapeshellarg($credentials_file);

				/* Get uid and gid settings. */
				$cifs_uid		= $info['cifs_uid'];
				$cifs_gid		= $info['cifs_gid'];
				$cifs_uid		= (is_numeric($cifs_uid) && (int)$cifs_uid > 0 && (int)$cifs_uid <= 65535) ? (int)$cifs_uid : 99;
				$cifs_gid		= (is_numeric($cifs_gid) && (int)$cifs_gid > 0 && (int)$cifs_gid <= 65535) ? (int)$cifs_gid : 100;
				$cifs_cache		= $info['cifs_cache'] ? $info['cifs_cache'] : "strict";
				$cifs_actimeo	= $cifs_cache == "loose" ? "15" : "1";

				/*
				 * Build versions-to-try:
				 * - If SMB_Version != "yes": try default (no vers=) first
				 * - Always try 3.1.1, 3.0, 2.1, 2.0
				 * - Optionally try 1.0 only if enabled in options
				 */
				$versions		= [];

				/* Add default negotiation if option is set. */
				if (get_config("Config", "SMB_Version") != "yes") {
					/* Default negotiation - no version specified. */
					$versions[] = null;
				}
				$versions[]		= "3.1.1";
				$versions[]		= "3.0";
				$versions[]		= "2.1";
				$versions[]		= "2.0";

				/* Optional SMB1 fallback based on the configuration setting. */
				$allow_smb1		= (get_config("Config", "SMB1_Fallback") == "yes");
				if ($allow_smb1) {
					$versions[] = "1.0";
				}

				/* Try mounting each SMB version until a successful mount occurs. */
				$mounted	= false;
				for ($i = 0; $i < count($versions) && (! $mounted); $i++) {
					$v		= $versions[$i];

					$ver	= ($v === null) ? "" : ",vers=".$v;

					/* Build extra mount params for this attempt. */
					$mounted_encrypt = false;

					if ($info['encryption']) {
						/*
						 * Allow seal on:
						 * - default negotiation (no vers=), and
						 * - explicit SMB 3.x versions.
						 */
						if ($v === null || (strpos($v, '3.') === 0)) {
							$extra_params		= $ver.",seal";
							$mounted_encrypt	= true;
						} else {
							$extra_params		= $ver;
						}
					} else {
						$extra_params = $ver;
					}

					$mounted = smb_try_mount($fs, $dir, $dev, $log_dev, $ro, $extra_params, $cifs_cache, $cifs_uid, $cifs_gid, $cifs_actimeo, $credentials);

					/* What version actually mounted. */
					$mounted_ver	= $mounted ? $v : "";
				}

				/* Get rid of credentials file. */
				MiscUD::shred_file($credentials_file);
			} else {
				unassigned_log("Warning: SMB must be enabled in 'Settings->SMB' to mount SMB remote shares.");
			}

			/* Did the share successfully mount? */
			if (is_mounted($dev, $dir)) {
				$symlink	= $paths['usb_mountpoint']."/".basename($dir);
				$target		= $dir;

				if ((get_config("Config", "symlinks") == "yes") && (dirname($dir) == $paths['remote_mountpoint'])) {
					/* Remove existing symlink or file with same name. */
					if (is_link($symlink) || file_exists($symlink)) {
						unlink($symlink);
					}

					/* Create legacy symlink. */
					symlink($target, $symlink);
				}

				unassigned_log("Successfully mounted '".$log_dev."' on '".$dir."'.");

				/*
				 * Post-mount warnings.
				 * Assumes $mounted_ver holds the negotiated version string or null for default.
				 * Assumes $info['encryption'] reflects user intent.
				 */

				/* Warn if SMB 1.0 was used. */
				if (($fs == "smb") && ($mounted_ver === "1.0")) {
					unassigned_log("Warning: SMB 1.0 was used for '".$log_dev."'. SMB 1.0 is insecure and should be avoided.");
				}

				/* Warn if encryption was requested but not applied. */
				if (($info['encryption']) && (! $mounted_encrypt)) {
					if ($mounted_ver === null) {
						unassigned_log("Warning: SMB encryption was requested for '".$log_dev."', but encryption could not be enabled with the negotiated SMB protocol.");
					} else {
						unassigned_log("Warning: SMB encryption was requested for '".$log_dev."', but SMB encryption is not available with SMB ".$mounted_ver.".");
					}
				}

				$rc = true;
			} else {
				unassigned_log("Remote Share '".$log_dev."' failed to mount.");
				@rmdir($dir);
			}
		} else {
			unassigned_log("Remote Share '".$log_dev."' is already mounted.");
		}
	} else {
		unassigned_log("Remote Server '".$info['ip']."' is offline and remote share '".$info['path']."' cannot be mounted."); 
	}

	return $rc;
}

/* Toggle samba auto mount on/off. */
function toggle_samba_automount($source, $status) {
	global $samba_config;

	/* Verify we have a source. */
	if ($source) {
		/* Make file changes. */
		$samba_config[$source]["automount"] = ($status == "true") ? "yes" : "no";
		save_ini_file(SAMBA_MOUNT, $samba_config);

		$rc	= ($samba_config[$source]["automount"] == "yes");
	} else {
		$rc	= false;
	}

	return $rc;
}

/* Toggle samba share on/off. */
function toggle_samba_share($source, $status) {
	global $samba_config;

	/* Verify we have a source. */
	if ($source) {
		/* Make file changes. */
		$samba_config[$source]["smb_share"] = ($status == "true") ? "yes" : "no";
		save_ini_file(SAMBA_MOUNT, $samba_config);

		$rc	= ($samba_config[$source]["smb_share"] == "yes");
	} else {
		$rc	= false;
	}

	return $rc;
}

/* Toggle hide mount on/off. */
function toggle_samba_disable_mount($source, $status) {
	global $samba_config;

	/* Verify we have a source. */
	if ($source) {
		/* Make file changes. */
		$samba_config[$source]["disable_mount"] = ($status == "true") ? "yes" : "no";
		save_ini_file(SAMBA_MOUNT, $samba_config);

		$rc	= ($samba_config[$source]["disable_mount"] == "yes");
	} else {
		$rc	= false;
	}

	return $rc;
}

/* Toggle samba read only on/off. */
function toggle_samba_readonly($source, $status) {
	global $samba_config;

	/* Verify we have a source. */
	if ($source) {
		/* Make file changes. */
		$samba_config[$source]['read_only'] = ($status == "true") ? "yes" : "no";
		save_ini_file(SAMBA_MOUNT, $samba_config);

		$rc	= ($samba_config[$source]["read_only"] == "yes");
	} else {
		$rc	= false;
	}

	return $rc;
}

/* Remove the samba remote mount configuration. */
function remove_config_samba($source) {
	global $samba_config;

	/* Remove samba configuraton if it exists. */
	if ( isset($samba_config[$source]) ) {
		unassigned_log("Removing configuration '".$source."'.");

		$command	= $samba_config[$source]['command'] ?? "";
		if (($command) && (is_file($command))) {
			@unlink($command);
			unassigned_log("Removing device script '".$command."'.");
		}

		unset($samba_config[$source]);

		/* Resave the samba config. */
		save_ini_file(SAMBA_MOUNT, $samba_config);
	}

	return (! isset($samba_config[$source]));
}

#########################################################
############		ISO FILE FUNCTIONS		#############
#########################################################
/* Get the iso file configuration parameter. */
function get_iso_config($source, $variable) {
	global $iso_config;

	return $iso_config[$source][$variable] ?? "";
}

/* Set an iso file configuration parameter. */
function set_iso_config($source, $variable, $value) {
	global $iso_config;

	/* Verify we have a serial number. */
	if ($source) {
		/* Make file changes. */
		$iso_config[$source][$variable] = $value;
		save_ini_file(ISO_MOUNT, $iso_config);

		$rc	= (isset($iso_config[$source][$variable]));
	} else {
		$rc	= false;
	}

	return $rc;
}

/* Is the iso file set to auto mount? */
function is_iso_automount($serial) {
	$auto		= get_iso_config($serial, "automount");

	return ($auto == "yes");
}

/* Get all ISO moints. */
function get_iso_mounts() {
	global $paths, $iso_config;

	/* Create an array of iso file mounts and set paramaters. */
	$return			= [];

	$iso_mounts		= $iso_config;

	/* Sort the iso mounts. */
	ksort($iso_mounts, SORT_NATURAL | SORT_FLAG_CASE);

	if (is_array($iso_mounts)) {
		foreach ($iso_mounts as $device => $mount) {
			$mount['device']			= $device;
			if ($mount['device']) {
				$mount['fstype']		= "loop";
				$mount['automount'] 	= is_iso_automount($mount['device']);
				$mount['mountpoint']	= $mount['mountpoint'] ?? "";
				$mount['share']			= $mount['share'] ?? "";
				$mount['file']			= $mount['file'] ?? "";

				if (! $mount['mountpoint']) {
					$mount["mountpoint"] = $paths['usb_mountpoint']."/".$mount['share'];
				} else {
					$path = basename($mount['mountpoint']);
					$mount["mountpoint"] = $paths['usb_mountpoint']."/".$path;
				}

				/* Remove special characters. */
				$mount_device			= safe_name(dirname($mount['device'])."_".basename($mount['device']), true, true);

				/* Check mounting and unmounting status. */
				$mount['mounting']		= MiscUD::get_mount_state($mount_device, 'mounting');
				$mount['unmounting']	= MiscUD::get_mount_state($mount_device, 'unmounting');

				/* Is the ios file mounted? */
				$mount['mounted']		= is_mounted("", $mount['mountpoint'], false);

				/* If this is a legacy iso mount indicate that it should be removed. */
				$safe_device			= safe_name($mount['file']);
				$mount['invalid']		= (basename($safe_device) != $device);
	
				$mount['alive']			= $mount['mounted'] || is_file($mount['file']);
				$stats					= get_device_stats($mount['mountpoint'], $mount['mounted'], $mount['alive']);
				$mount['size']			= $stats[0]*1024;
				$mount['used']			= $stats[1]*1024;
				$mount['avail']			= $stats[2]*1024;

				/* Set owner as if the iso image is being hot plugged. */
				$mount['owner']			= "user";

				$mount['command']		= get_iso_config($mount['device'],"command");
				$mount['enable_script']	= $mount['command'] ? get_iso_config($mount['device'],"enable_script") : "false";
				$mount['prog_name']		= basename($mount['command'], ".sh");
				$mount['user_command']	= get_iso_config($mount['device'],"user_command");
				$mount['common_cmd']	= get_config("Config", "common_cmd");
				$mount['logfile']		= ($mount['prog_name']) ? $paths['device_log'].$mount['prog_name'].".log" : "";
				$mount['running']		= ($mount['mounted']) ? ((is_script_running($mount['command'])) || (is_script_running($mount['user_command'], true))) : false;

				/* Add to the iso mounts array. */
				$return[] = $mount;
			}

		}
	} else {
		unassigned_log("Error: unable to get the ISO mounts.");
	}

	return $return;
}

/* Mount ISO file. */
function do_mount_iso($info) {
	global $paths;

	$rc = false;
	$file	= $info['file'];
	$dir	= $info['mountpoint'];

	if (is_file($file)) {
		if (! $info['mounted']) {
			@mkdir($dir, 0777, true);

			$cmd = "/sbin/mount -ro loop ".escapeshellarg($file)." ".escapeshellarg($dir);
			unassigned_log("Mount iso cmd: ".$cmd);
			$o = timed_exec(15, $cmd." 2>&1");
			if (wait_for_mounted("", $dir)) {
				unassigned_log("Successfully mounted '".$file."' on '".$dir."'.");

				$rc = true;
			} else {
				@rmdir($dir);

				unassigned_log("Warning: Mount of '".$file."' failed: '".$o."'");
			}
		} else {
			unassigned_log("ISO file '".$file."' is already mounted.");
		}
	} else {
		unassigned_log("ISO file '".$file."' is missing and cannot be mounted.");
	}

	return $rc;
}

/* Toggle iso file automount on/off. */
function toggle_iso_automount($source, $status) {
	global $iso_config;

	/* Verify we have a serial number. */
	if ($source) {
		/* Make file changes. */
		$iso_config[$source]["automount"] = ($status == "true") ? "yes" : "no";
		save_ini_file(ISO_MOUNT, $iso_config);

		$rc	= ($iso_config[$source]["automount"] == "yes");
	} else {
		$rc	= false;
	}

	return $rc;
}

/* Remove ISO configuration. */
function remove_config_iso($source) {
	global $iso_config;

	/* Remove the iso cofiguration. */
	if ( isset($iso_config[$source]) ) {
		unassigned_log("Removing ISO configuration '".$source."'.");

		$command	= $iso_config[$source]['command'] ?? "";
		if (($command) && (is_file($command))) {
			@unlink($command);

			unassigned_log("Removing device script '".$command."'.");
		}

		unset($iso_config[$source]);

		/* Save new iso config. */
		save_ini_file(ISO_MOUNT, $iso_config);
	}

	return (! isset($iso_config[$source]));

}


#########################################################
############		DISK FUNCTIONS			#############
#########################################################
/* Get an array of all unassigned disks. */
function get_unassigned_disks() {
	global $unraid_disks;

	/* Initialize arrays. */
	$ud_disks		= [];
	$devicePaths	= [];

	/* Get all devices by id and eliminate any duplicates. */
	$allDevices = array_filter(listFile("/dev/disk/by-id"), function($p) {
		/* Skip WWN entries */
		return strpos(basename($p), 'wwn-') !== 0;
	});

	foreach (array_unique($allDevices) as $physicalDevice) {
		$realPath = realpath($physicalDevice);

		/* Only /dev/sd*, /dev/hd*, and /dev/nvme* devices. */
		if (array_reduce(["/dev/sd", "/dev/hd", "/dev/nvme"], function ($carry, $substring) use ($realPath) {
			return $carry || strpos($realPath, $substring) !== false;
		}, false)) {
			$devicePaths[$realPath] = $physicalDevice;
		}
	}

	ksort($devicePaths, SORT_NATURAL | SORT_FLAG_CASE);

	/* Create the array of unassigned devices. */
	foreach ($devicePaths as $path => $device) {
		/* Check if $device is not empty and doesn't contain "part" in its name. */
		if ($device && strpos($device, 'part') === false) {
			/* Check if $path is not in $unraid_disks */
			if (! in_array($path, $unraid_disks, true)) {
				/* Check if $path is not in the 'device' field of any array in $ud_disks. */
				if (! in_array($path, array_map(function ($ar) {
						return $ar['device'];
					}, $ud_disks), true)) {

					/* Get partitions matching the pattern "$device.*-part\d+". */
					$partitions = array_values(preg_grep("|$device.*-part\d+|", $devicePaths));

					/* Sort partitions using natural order. */
					natsort($partitions);

					/* Add entry to $ud_disks. */
					$ud_disks[$device] = array("device" => $path, "partitions" => $partitions);
				}
			}
		} else {
			$partitions	= [];
		}
	}

	return $ud_disks;
}

/* Get all the disk information for each disk device. */
function get_all_disks_info() {
	/* Get all the unassigned disks. */
	$ud_disks = get_unassigned_disks();

	/* If there are unassigned disks, get all disk information from udev. */
	if (is_array($ud_disks)) {
		/* Go through each disk and get the information for each. */
		foreach ($ud_disks as $key => $disk) {
			/* Get the disk info. */
			$disk_info			= $key ? get_disk_info($key) : [];

			/* Only get disk parameters if they are defined. */
			if ($disk_info) {
				/* Add as a UD device. */
				$dev			= basename(realpath($key));

				/* Set the disk size from the lsblk array. */
				$disk['size']	= $dev ? intval(get_disk_size($dev)) : 0;

				/* Get all this disks partitions. */
				$disk			= array_merge($disk, $disk_info);

				/* If the disk is clearing, partitions are not valid. */
				if ($disk['clearing']) {
					$disk['partitions']	= [];
				}

				$disk['zvol']	= [];

				/* Get all the partitions and additional settings. */
				if ($disk['partitions']) {
					foreach ($disk['partitions'] as $k => $p) {
						if ($p) {
							$disk['partitions'][$k]	= get_partition_info($p);

							/* If this is a zfs disk, see if there are any zfs volumes. */
							if ($disk['partitions'][$k]['fstype'] == "zfs") {
								/* Get any zfs volumes. */
								$disk['zvol']		= array_merge($disk['zvol'], get_zvol_info($disk['partitions'][$k]));
							}
						}
					}
				}

				/* Remove the original UD entry and add the new UD reference. */
				unset($ud_disks[$key]);
				$disk['path']			= $key;

				/* Set the ud_dev to the current value in the devs.ini file. */
				$disk['ud_dev']			= get_disk_dev($disk['device']);

				/* Use the devX designation or the sdX if there is no devX designation for disk device sorting. */
				$unassigned_dev			= $disk['unassigned_dev'] ?: ($disk['ud_dev'] ?: basename($disk['device']));

				/* If there is already a devX that is the same, use the disk device sdX designation. */
				if ((is_dev_device($unassigned_dev)) && (array_key_exists($unassigned_dev, $ud_disks))) {
					/* Get the sdX device designation. */
					$unassigned_dev		= basename($disk['device']);
				}

				/* See if any partitions have a file system. */
				$disk['file_system']	= in_array(true, array_map(function($partition) {
					return ! empty($partition['fstype']);
				}, $disk['partitions']), true);

				/* Any partitions mounted? */
				$disk['mounted']		= array_reduce($disk['partitions'], function ($carry, $partition) {
					return $carry || $partition['mounted'];
				}, false);

				/* Was the disk unmounted properly? */
				$disk['not_unmounted']	= array_reduce($disk['partitions'], function ($carry, $partition) {
					return $carry || $partition['not_unmounted'];
				}, false);

				/* Mark all partitions as mounting if the disk is mounting. */
				if ($disk['mounting']) {
					/* Loop through partitions and set 'mounting' to true. */
					foreach ($disk['partitions'] as &$partition) {
						$partition['mounting'] = true;
					}

					/* Check if 'mounting' is true in the zvol and set for zvols. */
					if (isset($disk['zvol'])) {
						foreach ($disk['zvol'] as &$zvol) {
							$zvol['mounting'] = true;
						}
					}
				} else {
					/* Get the mounting states of disks and all partitions. */
					$disk['mounting']		= (
						in_array(true, array_map(function($partition) {
							return $partition['mounting'];
						}, $disk['partitions']), true) ||

						in_array(true, array_map(function($zvol) {
							return $zvol['mounting'];
						}, $disk['zvol']), true)
					);
				}

				/* Mark any partitions as unmounting if the disk is unmounting. */
				if ($disk['unmounting']) {
					/* Loop through partitions and set 'unmounting' to true. */
					foreach ($disk['partitions'] as &$partition) {
						$partition['unmounting'] = true;
					}

					/* Check if 'unmounting' is true in the zvol and set for zvols. */
					if (isset($disk['zvol'])) {
						foreach ($disk['zvol'] as &$zvol) {
							$zvol['unmounting'] = true;
						}
					}
				} else {
					/* Get the unmounting states of disks and all partitions. */
					$disk['unmounting'] 	= (
						in_array(true, array_map(function($partition) {
							return $partition['unmounting'];
						}, $disk['partitions']), true) ||

						in_array(true, array_map(function($zvol) {
							return $zvol['unmounting'];
						}, $disk['zvol']), true)
					);
				}

				/* Is a partition script running? */
				$disk['running']		= array_reduce($disk['partitions'], function ($carry, $partition) {
					return $carry || $partition['running'];
				}, false);

				/* Device is disabled unless a partition is found with a valid file system. */
				$disk['disable']		= (! $disk['file_system']);

				/* Is this a pool disk? */
				$disk['pool_disk']		= array_reduce($disk['partitions'], function ($carry, $partition) {
					return $carry || $partition['pool'];
				}, false);

				/* Check that udev matches the file system on the disk. */
				$disk['not_udev']		= array_reduce($disk['partitions'], function ($carry, $partition) {
					return $carry || $partition['not_udev'];
				}, false);

				/* Add this device as a UD device. */
				$ud_disks[$unassigned_dev] = $disk;
			} else {
				/* Remove the original UD entry; disk is being hot plugged - wait until udev settles. */
				unset($ud_disks[$key]);
			}
		}
	} else {
		/* There was a problem getting the unassigned disks array. */
		unassigned_log("Error: unable to get unassigned disks.");
		$ud_disks = [];
	}

	/* Sort the unassigned devoces in natural order. */
	ksort($ud_disks, SORT_NATURAL | SORT_FLAG_CASE);

	return $ud_disks;
}

/**
 * Get or update cached udev information for a device.
 *
 * This function maintains a persistent cache of udev properties in order
 * to avoid repeated udevadm queries during device scans and hotplug
 * processing.
 *
 * Operation:
 * - All access is serialized using the "udev" file lock.
 * - When a udev event is supplied, the cache is updated immediately.
 * - "remove" events delete all cached entries matching the device serial
 *   number because Linux may assign a different sdX name when the device
 *   is reattached.
 * - When no udev event is supplied, the cached entry is returned if
 *   available.
 * - If the device is not cached, udevadm is queried and the cache is
 *   refreshed.
 * - Newly discovered devices request a deferred hotplug apply so Unraid
 *   can process the updated device state.
 * - A throttled diagnostic copy of the cache is maintained for Unraid
 *   diagnostics.
 *
 * @param string $dev  Device path or device name.
 * @param array|null $udev Optional udev event properties.
 *
 * @return array Cached udev properties or an empty array if unavailable.
 */
 function get_udev_info($dev, $udev = null) {
	global $paths;

	$rc			= [];
	$device		= safe_name($dev);
	$start_time	= microtime(true);

	/* Acquire a lock and log lock error after 10 seconds if lock was not acquired. */
	if ($lock_file = get_file_lock("udev", 10.0)) {
		try {
			/* Read the current udev state. */
			$state = [];

			if (is_file($paths['state'])) {
				$parsed = @parse_ini_file($paths['state'], true, INI_SCANNER_RAW);

				if ($parsed !== false) {
					$state = $parsed;
				}
			}

			/* Update the udev state from a udev event. */
			if (isset($udev)) {
				$serial	= $udev['ID_SERIAL'] ?? "";
				$action	= $udev['ACTION'] ?? "";

				unassigned_log("Debug: Update udev info for ".$serial.".", $GLOBALS['UDEV_DEBUG']);

				/* If there is no serial number, the disk has a problem and don't add it to the udev data. */
				if ($serial) {
					if ($action != "remove") {
						/* Remove proxy environment variables that are added to php environment variables. */
						unset($udev['http_proxy'], $udev['https_proxy'], $udev['no_proxy']);

						$state[$device] = $udev;
					} else {
						unassigned_log("Debug: Remove udev info for ".$serial.".", $GLOBALS['UDEV_DEBUG']);

						/* Remove all entries for this serial number because the sdX device name can change when reattached. */
						$state = array_filter($state, function($item) use ($serial) {
							return (($item['ID_SERIAL'] ?? "") !== $serial);
						});
					}

					$ini	= null;
					$saved	= save_ini_file($paths['state'], $state, true, $ini);

					/* Keep a throttled copy of udev for Unraid diagnostics. */
					if (($saved) && ($ini !== null)) {
						$diag_update_interval = 60;
						$write_diag = ((! is_file($paths['diag_state'])) || ((time() - filemtime($paths['diag_state'])) > $diag_update_interval));

						if ($write_diag) {
							@file_put_contents($paths['diag_state'], $ini);
						}
					}

					$rc = $udev;
				} else {
					unassigned_log("Debug: No serial id for ".$device.".", $GLOBALS['UDEV_DEBUG']);
				}
			} else if (array_key_exists($device, $state)) {
				$rc = $state[$device];
			} else {
				/* Refresh the udev state from udevadm when it is not already cached. */
				$timed_cmd	= "/sbin/udevadm info --query=property --path $(/sbin/udevadm info -q path -n ".escapeshellarg($device)." 2>/dev/null) 2>/dev/null";
				$dev_state	= @parse_ini_string(timed_exec(10, $timed_cmd), false, INI_SCANNER_RAW);

				if (is_array($dev_state)) {
					unassigned_log("Debug: Refresh udev info for ".$device.".", $GLOBALS['UDEV_DEBUG']);

					$state[$device] = $dev_state;

					$ini	= null;
					$saved	= save_ini_file($paths['state'], $state, true, $ini);

					/* Keep a throttled copy of udev for Unraid diagnostics. */
					if (($saved) && ($ini !== null)) {
						$diag_update_interval = 60;
						$write_diag = ((! is_file($paths['diag_state'])) || ((time() - filemtime($paths['diag_state'])) > $diag_update_interval));

						if ($write_diag) {
							@file_put_contents($paths['diag_state'], $ini);
						}
					}

					$rc = $state[$device];

					/* Request Unraid to handle a hotplug event for the next UI refresh. */
					request_hotplug_apply();
				}
			}
		} finally {
			/* Log long lock hold times for debugging. */
			$elapsed = microtime(true) - $start_time;

			if ($elapsed > 0.5) {
				unassigned_log("Debug: get_udev_info() held udev lock for ".round($elapsed, 3)." seconds on '".$device."'.", $GLOBALS['UDEV_DEBUG']);
			}

			/* Release the file lock. */
			release_file_lock($lock_file);
		}
	} else {
		unassigned_log("Failed to acquire udev lock for '".$device."'. Udev state was not updated.");
	}

	return $rc;
}

/* Get information on specific disk device. */
function get_disk_info($dev) {
	global $unraid_disks;

	/* Get all the disk information for this disk device. */
	$disk		= [];
	$attrs		= (isset($_ENV['DEVTYPE']) && (strpos($dev, '/dev/disk/') === 0)) ? get_udev_info($dev, $_ENV) : get_udev_info($dev, null);
	if ($attrs) {
		$disk['device']	= realpath($dev);
		if ($disk['device'] !== false) {
			$disk['serial']				= get_disk_id($disk['device'], trim($attrs['ID_SERIAL']));
			$disk['serial_short']		= $attrs['ID_SCSI_SERIAL'] ?? ($attrs['ID_SERIAL_SHORT'] ?? "");
			$disk['id_bus']				= $attrs['ID_BUS'] ?? "";
			$disk['fstype']				= $attrs['ID_FS_TYPE'] ?? "";
			$disk['ud_dev']				= get_disk_dev($disk['device']);
			$disk['ud_device']			= is_dev_device($disk['ud_dev']);
			$disk['unassigned_dev']		= get_config($disk['serial'], "unassigned_dev");
			$disk['ud_unassigned_dev']	= is_dev_device($disk['unassigned_dev']);
			$disk['ssd']				= is_disk_ssd($disk['device']);
			$rw							= get_disk_reads_writes($disk['ud_dev'], $disk['device']);
			$disk['reads']				= $rw[0];
			$disk['writes']				= $rw[1];
			$disk['read_rate']			= $rw[2];
			$disk['write_rate']			= $rw[3];
			$disk['spinning']			= is_disk_spinning($disk['ud_dev']);
			$usb						= (isset($attrs['ID_BUS']) && ($attrs['ID_BUS'] == "usb"));
			$disk['automount']			= is_automount($disk['serial'], $usb);
			$disk['disable_mount']		= is_disable_mount($disk['serial']);
			$disk['temperature']		= get_temp($disk['ud_dev'], $disk['spinning']);
			$disk['command']			= get_config($disk['serial'], "command.1");
			$disk['enable_script']		= $disk['command'] ? get_config($disk['serial'], "enable_script.1") : "false";
			$disk['user_command']		= get_config($disk['serial'], "user_command.1");
			$disk['common_cmd']			= get_config("Config", "common_cmd");
			$disk['show_partitions']	= (get_config($disk['serial'], "show_partitions") == "no") ? false : true;
			$disk['array_disk']			= $disk['device'] ? in_array($disk['device'], $unraid_disks, true) : false;
			$disk['pass_through']		= is_pass_through($disk['serial']);
			$disk['formatting']			= MiscUD::get_mount_state(basename($disk['device']), 'formatting');
			$disk['clearing']			= MiscUD::get_mount_state(basename($disk['device']), 'clearing');
			$disk['mounting']			= MiscUD::get_mount_state(basename($disk['device']), 'mounting');
			$disk['unmounting']			= MiscUD::get_mount_state(basename($disk['device']), 'unmounting');

			/* Are there any preclearing operations going on? */
			if (! $disk['fstype']) {
				$disk['preclearing']	= is_preclear_running($disk['device']);
			} else {
				$disk['preclearing']	= false;
			}

			/* Get the hostX from the DEVPATH so we can re-attach a disk. */
			if ($attrs['DEVPATH']) {
				MiscUD::save_device_host($disk['serial'], $attrs['DEVPATH']);
			}
		}
	}

	return $disk;
}

/* Get partition information. */
function get_partition_info($dev) {
	global $paths;

	$partition	= [];
	$attrs		= (isset($_ENV['DEVTYPE']) && (strpos($dev, '/dev/disk/') === 0)) ? get_udev_info($dev, $_ENV) : get_udev_info($dev, null);
	if (($attrs) && ($attrs['DEVTYPE'] ?? "" == "partition")) {
		$partition['device']			= realpath($dev);
		if ($partition['device'] !== false) {
			$partition['serial_short']		= $attrs['ID_SCSI_SERIAL'] ?? ($attrs['ID_SERIAL_SHORT'] ?? "");
			$partition['serial']			= isset($attrs['ID_SERIAL']) ? get_disk_id($partition['device'], trim($attrs['ID_SERIAL'])) : "";
			$partition['uuid']				= $attrs['ID_FS_UUID'] ?? "";

			/* Get partition number */
			preg_match_all("#(.*?)(\d+$)#", $partition['device'], $matches);
			$partition['part']				= $matches[2][0] ?? "";
			$partition['disk']				= (isset($matches[1][0])) ? MiscUD::base_device($matches[1][0]) : "";

			/* Get the physical disk label or generate one based on the vendor id and model or serial number. */
			if (isset($attrs['ID_FS_LABEL'])){
				$partition['label']			= safe_name($attrs['ID_FS_LABEL']);
				$partition['disk_label']	= $partition['label'];
			} else {
				if (isset($attrs['ID_VENDOR']) && isset($attrs['ID_MODEL'])){
					$partition['label']		= sprintf("%s %s", safe_name($attrs['ID_VENDOR']), safe_name($attrs['ID_MODEL']));
				} else {
					$partition['label']		= safe_name($attrs['ID_SERIAL_SHORT'] ?? "");
				}
				$all_disks					= array_unique(array_map(function($ar){return realpath($ar);}, listFile("/dev/disk/by-id")));
				$partition['label']			= (isset($partition['label']) && (isset($matches[1][0])) && (count(preg_grep("%".$matches[1][0]."%i", $all_disks)) > 2)) ? $partition['label']."-part".$matches[2][0] : $partition['label'];
				$partition['disk_label']	= "";
			}

			/* Any partition with an 'UNRAID' label is an array disk. */
			$partition['array_disk']		= ($partition['label'] == "UNRAID");

			/* Get the file system type. */
			$partition['fstype']			= safe_name($attrs['ID_FS_TYPE'] ?? "");
			$partition['fstype']			= ($partition['fstype'] == "zfs_member") ? "zfs" : $partition['fstype'];

			/* Get the mount point from the configuration and if not set, create a default mount point. */
			$partition['mountpoint']		= get_config($partition['serial'], "mountpoint.{$partition['part']}");
			if (! $partition['mountpoint']) { 
				$partition['mountpoint']	= preg_replace("%\s+%", "_", sprintf("%s/%s", $paths['usb_mountpoint'], $partition['label']));
			}

			/* crypto_LUKS file system. */
			/* The device is /dev/mapper/... for all luks devices. */
			if ($partition['fstype'] == "crypto_LUKS") {
				$partition['luks']			= $partition['device'];
				$partition['device']		= "/dev/mapper/".safe_name(basename($partition['mountpoint']));
				$dev						= $partition['luks'];
			} else {
				$partition['luks']			= "";
				$dev						= $partition['device'];
			}

			/* This is the file system reported by lsblk. */
			$partition['file_system']		= ($partition['fstype']) ? part_fs_type($partition['device']) : "";

			/* Check for udev and lsblk file system type matching. If not then udev is not reporting the correct file system. */
			$partition['not_udev']			= ($partition['fstype'] != "crypto_LUKS") ? ($partition['fstype'] != $partition['file_system']) : false;

			/* Get the partition mounting and unmounting status. */
			$partition['mounting']			= MiscUD::get_mount_state(basename($dev), 'mounting');
			$partition['unmounting']		= MiscUD::get_mount_state(basename($dev), 'unmounting');

			/* Set up all disk parameters and status. */
			$partition['pass_through']		= is_pass_through($partition['serial']);

			/* Is the disk mount point mounted? */
			/* If the partition doesn't have a file system, it can't possibly be mounted by UD. */
			$partition['mounted']			= ((! $partition['pass_through']) && ($partition['fstype'])) ? is_mounted("", $partition['mountpoint'], false) : false;

			/* is the partition mounted read only. */
			$partition['part_read_only']	= ($partition['mounted']) ? is_mounted_read_only($partition['mountpoint']) : false;

			/* Is this a btrfs pooled disk. */
			if ($partition['mounted'] && $partition['fstype'] == "btrfs") {
				/* Get the members of a pool if this is a pooled disk. */
				$pool_devs					= MiscUD::get_pool_devices($partition['mountpoint']);

				/* Find the anchor device (devid 1) for the pool. */
				$timed_cmd	= "/sbin/btrfs fi show ".escapeshellarg($partition['mountpoint'])." | awk '$1==\"devid\" && $2==1 {print \$NF}'";
				$anchor		= timed_exec(5, $timed_cmd);

				/* Remove the anchor device from the pool list. */
				if ($anchor && in_array($anchor, $pool_devs, true)) {
					$key = array_search($anchor, $pool_devs, true);
					unset($pool_devs[$key]);
					$pool_devs = array_values($pool_devs); /* Reindex for consistency. */
				}

				/* This is a secondary pool member if not the anchor member. */
				$partition['pool']			= in_array($partition['device'], $pool_devs, true);
			} else {
				$partition['pool']			= false;
			}

			/* See if this is a zfs file system. */
			$zfs							= ($partition['file_system'] == "zfs");

			/* Get the pool name for a zfs device if it is mounted. */
			$partition['pool_name']			= (($partition['mounted']) && ($zfs)) ? MiscUD::zfs_pool_name("", $partition['mountpoint']) : "";

			/* Does this disk have any zfs compatibility issues? */
			$partition['zfs_indicator']		= get_config($partition['serial'], "zfs_indicator.{$partition['part']}");

			/* If the disk mount point is mounted, we need to verify it is also mounted by device. */
			/* If it is not, then the disk was probably removed before being properly unmounted. */
			/* Or the user has several disks with the same mount point. */
			/* If the disk is part of a btrfs pool, ignore the not unmounted check. */
			if (($partition['mounted']) && (! $partition['pool'])) {
				/* Not unmounted is a check that the disk is mounted by mount point but not by device. */
				/* The idea is to catch the situation where a disk is removed before being unmounted. */
				if ($zfs) {
					$partition['not_unmounted']	= $partition['pool_name'] ? (! is_mounted($partition['pool_name'], "", false)) : false;
				} else {
					$partition['not_unmounted']	= (! is_mounted($partition['device'], "", false));
				}
			} else {
				$partition['not_unmounted']		= false;
			}


			/* Is the disable mount button switch on? */
			$partition['disable_mount']	= is_disable_mount($partition['serial']);

			$stats						= get_device_stats($partition['mountpoint'], $partition['mounted'], $partition['mounted'], $partition['file_system']);
			$partition['size']			= $stats[0]*1024;
			$partition['used']			= $stats[1]*1024;
			$partition['avail']			= $stats[2]*1024;

			$partition['owner']			= (isset($_ENV['DEVTYPE'])) ? "udev" : "user";
			$partition['read_only']		= is_read_only($partition['serial']);
			$usb						= (isset($attrs['ID_BUS']) && ($attrs['ID_BUS'] == "usb"));
			$partition['shared']		= config_shared($partition['serial'], $partition['part'], $usb);
			$partition['compression']	= get_config($partition['serial'], "compress_option.{$partition['part']}");
			$partition['command']		= get_config($partition['serial'], "command.{$partition['part']}");
			$partition['user_command']	= get_config($partition['serial'], "user_command.{$partition['part']}");
			$partition['common_cmd']	= get_config("Config", "common_cmd");
			$partition['enable_script']	= $partition['command'] ? get_config($partition['serial'], "enable_script.{$partition['part']}") : "false";
			$partition['prog_name']		= basename($partition['command'], ".sh");
			$partition['logfile']		= ($partition['prog_name']) ? $paths['device_log'].$partition['prog_name'].".log" : "";
			$partition['running']		= ($partition['mounted']) ? ((is_script_running($partition['command'])) || (is_script_running($partition['user_command'], true))) : false;

			/* Values not needed but must exist for make_mount_button() on the partition. */
			$partition['ud_device']		= true;
			$partition['formatting']	= false;
			$partition['clearing']		= false;
			$partition['preclearing']	= false;
		}
	}

	return $partition;
}

/* Get zfs volume info if the partition has any zvols. */
function get_zvol_info($disk) {
	$zvol = [];

	/* Pre-checks */
	if (! (get_config("Config", "zvols") == "yes" && $disk['fstype'] == "zfs" && $disk['mounted'])) {
		return $zvol;
	}

	$serial		= $disk['serial'];
	$zpool_name	= $disk['pool_name'];
	$base_dir	= "/dev/zvol/".$zpool_name;

	/* Read the zvol directory. */
	$list = @scandir($base_dir);
	if (! is_array($list)) {
		return $zvol;
	}

	foreach ($list as $entry) {
		/* Skip . and .. and anything starting with '.' */
		if ($entry[0] === '.') {
			continue;
		}

		$q = $base_dir.'/'.$entry;

		/* Skip non-existent or non-device entries (symlinks are allowed) */
        /* realpath() returns false for broken links; keep original path for device name. */
		$device = realpath($q);
		if ($device === false) {
			continue;
		}

		$vol	= $entry;

		/* This is used as a lookup for fsck get parameters from config file. */
		$zvol[$vol]['volume']		= $zpool_name.".".$entry;

		$zvol[$vol]['serial']		= $serial;
		$zvol[$vol]['part']			= $vol;
		$zvol[$vol]['pool_name']	= $zpool_name;
		$zvol[$vol]['device']		= $device;

		/* Replace glob($q."-part*") with fast scandir() prefix search. */
		$zvol[$vol]['active'] = true;
		$part_prefix = $entry."-part";

		if (is_array($list)) {
			foreach ($list as $p) {
				if (strncmp($p, $part_prefix, strlen($part_prefix)) === 0) {
					$zvol[$vol]['active'] = false;	/* Partition exists -> not active */
					break;
				}
			}
		}

		$zvol[$vol]['mountpoint']	= $disk['mountpoint'].".".$entry;
		$zvol[$vol]['mounted']		= is_mounted("", $zvol[$vol]['mountpoint'], false);
		$zvol[$vol]['mounting']		= MiscUD::get_mount_state(basename($device), 'mounting');
		$zvol[$vol]['unmounting']	= MiscUD::get_mount_state(basename($device), 'unmounting');
		$zvol[$vol]['fstype']		= "zvol";

		/* Determine filesystem type */
		$zvol[$vol]['file_system'] = part_fs_type($device);

		$zvol[$vol]['zfs_read_only'] = is_mounted_read_only($zvol[$vol]['mountpoint']);

		/* Disk statistics */
		$stats					= get_device_stats($zvol[$vol]['mountpoint'], $zvol[$vol]['mounted'], $zvol[$vol]['active'], true);
		$zvol[$vol]['size']		= $stats[0] * 1024;
		$zvol[$vol]['used']		= $stats[1] * 1024;
		$zvol[$vol]['avail']	= $stats[2] * 1024;

		$zvol[$vol]['read_only']	= is_read_only($serial, true, $vol);
		$zvol[$vol]['pass_through']	= is_pass_through($serial, $vol);
		$zvol[$vol]['disable_mount']= is_disable_mount($serial, $vol);

		/* Required placeholder values for make_mount_button() */
		$zvol[$vol]['array_disk']	= false;
		$zvol[$vol]['not_unmounted']= false;
		$zvol[$vol]['not_udev']		= false;
		$zvol[$vol]['ud_device']	= true;
		$zvol[$vol]['running']		= false;
		$zvol[$vol]['command']		= "";
		$zvol[$vol]['user_command']	= "";
		$zvol[$vol]['compression']	= "";
	}

	return $zvol;
}

/* Get the check file system command based on disk file system. */
function get_fsck_commands($fs, $dev, $type = "ro") {
	switch ($fs) {
		case 'vfat':
			$cmd = array('ro'=>'/sbin/fsck.vfat -n %s', 'rw'=>'/sbin/fsck -a %s');
			break;

		case 'ntfs':
			$cmd = array('ro'=>'/bin/ntfsfix -n %s', 'rw'=>'/bin/ntfsfix -b -d %s');
			break;

		case 'hfsplus':
			$cmd = array('ro'=>'/usr/sbin/fsck.hfsplus -l %s', 'rw'=>'/usr/sbin/fsck.hfsplus -y %s');
			break;

		case 'xfs':
			$cmd = array('ro'=>'/sbin/xfs_repair -n %s', 'rw'=>'/sbin/xfs_repair -e %s', 'log'=>'/sbin/xfs_repair -e -L %s');
			break;

		case 'zfs':
			$cmd = array('ro'=>'/usr/sbin/zpool scrub -w %s');
			break;

		case 'ext4':
			$cmd = array('ro'=>'/sbin/fsck.ext4 -vn %s', 'rw'=>'/sbin/fsck.ext4 -v -f -p %s');
			break;

		case 'exfat':
			$cmd = array('ro'=>'/usr/local/sbin/ud-exfat/fsck.exfat -n %s', 'rw'=>'/usr/sbin/fsck.exfat %s');
			break;

		case 'btrfs':
			$cmd = array('ro'=>'/sbin/btrfs scrub start -B -R -d %s', 'rw'=>'/sbin/btrfs scrub start -B -R -d %s');
			break;

		case 'reiserfs':
			$cmd = array('ro'=>'/sbin/reiserfsck --check %s', 'rw'=>'/sbin/reiserfsck --fix-fixable %s');
			break;

		default:
			$cmd = array('ro'=>false, 'rw'=>false);
			break;
	}

	return !empty($cmd[$type]) ? sprintf($cmd[$type], $dev) : "";
}

/* Check for a duplicate share name when changing the mount point and mounting disks. */
function check_for_duplicate_share($dev, $mountpoint, $mounting = false) {
	global $var, $paths;

	$rc					= true;
	$mountpoint_upper	= strtoupper($mountpoint);

	/* Get all SMB share names from the shares state file. */
	$smb_config			= @parse_ini_file($paths['shares_state'], true) ?: [];
	$smb_shares			= array_map('strtoupper', array_keys($smb_config));

	/* Get all disk names from the disks state file. */
	$disks_config		= @parse_ini_file($paths['disks_state'], true) ?: [];
	$disk_names			= array_map('strtoupper', array_keys($disks_config));

	/* Get Unraid reserved share names. */
	$reserved_names		= [];
	foreach (explode(",", $var['reservedNames'] ?? "") as $name) {
		$name = strtoupper(trim($name));

		if ($name !== "") {
			$reserved_names[] = $name;
		}
	}

	/* Get all UD shares except shares for this device. */
	$ud_shares			= [];
	$share_names		= MiscUD::get_json($paths['share_names']);
	$share_names		= is_array($share_names) ? $share_names : [];

	foreach ($share_names as $device => $name) {
		$devs = explode(",", $device);

		if (! in_array($dev, $devs, true)) {
			$ud_shares[] = strtoupper($name);
		}
	}

	/* If mounting a device, ignore its own existing share name if it is not currently mounted. */
	if (($mounting) && (! is_mounted("", $mountpoint))) {
		$key = array_search($mountpoint_upper, $ud_shares, true);

		if ($key !== false) {
			unset($ud_shares[$key]);
		}
	}

	/* Merge all names that cannot be used as a UD mount point. */
	$shares = array_merge($smb_shares, $disk_names, $reserved_names, $ud_shares);

	/* See if the share name is already being used. */
	if (in_array($mountpoint_upper, $shares, true)) {
		unassigned_log("Error: Device '".$dev."' mount point '".$mountpoint."' - mount point name is reserved or already used by an array share, pool, disk share, or unassigned device!");
		$rc = false;
	}

	return $rc;
}

/* Change disk mount point and update the physical disk label. */
function change_mountpoint($serial, $partition, $dev, $fstype, $mountpoint) {
	global $paths;

	$rc			= true;
	$new_mount	= $paths['usb_mountpoint']."/".$mountpoint;

	$change_disk_label = function($dev, $fstype, $mountpoint) {
		$rc = true;

		switch ($fstype) {
			case 'xfs':
				$timed_cmd = "/usr/sbin/xfs_admin -L ".escapeshellarg($mountpoint)." ".escapeshellarg($dev)." 2>/dev/null";
				timed_exec(20, $timed_cmd);
				break;

			case 'btrfs':
				$timed_cmd = "/sbin/btrfs filesystem label ".escapeshellarg($dev)." ".escapeshellarg($mountpoint)." 2>/dev/null";
				timed_exec(20, $timed_cmd);
				break;

			case 'zfs':
				$pool_name = MiscUD::zfs_pool_name($dev);

				if ($pool_name) {
					$device_dir = dirname($dev);

					$timed_cmd = "/usr/sbin/zpool export ".escapeshellarg($pool_name)." 2>&1";
					timed_exec(10, $timed_cmd, true);
					sleep(1);

					$timed_cmd = "/usr/sbin/zpool import -d ".escapeshellarg($device_dir)." -N ".escapeshellarg($pool_name)." ".escapeshellarg($mountpoint)." 2>&1";
					timed_exec(10, $timed_cmd, true);
					sleep(1);

					$timed_cmd = "/usr/sbin/zpool export ".escapeshellarg($mountpoint)." 2>&1";
					timed_exec(10, $timed_cmd, true);
				} else {
					unassigned_log("Warning: Cannot determine ZFS pool name on device '".basename($dev)."'.");
					$rc = false;
				}
				break;

			case 'ext4':
				$timed_cmd = "/sbin/tune2fs -L ".escapeshellarg($mountpoint)." ".escapeshellarg($dev)." 2>/dev/null";
				timed_exec(20, $timed_cmd);
				break;

			case 'ntfs':
				$mountpoint = substr($mountpoint, 0, 31);
				$timed_cmd = "/sbin/ntfslabel ".escapeshellarg($dev)." ".escapeshellarg($mountpoint)." 2>/dev/null";
				timed_exec(20, $timed_cmd);
				break;

			case 'vfat':
				$mountpoint = substr(strtoupper($mountpoint), 0, 10);
				$timed_cmd = "/sbin/fatlabel ".escapeshellarg($dev)." ".escapeshellarg($mountpoint)." 2>/dev/null";
				timed_exec(20, $timed_cmd);
				break;

			case 'exfat':
				if (is_executable("/usr/local/sbin/ud-exfat/exfatlabel")) {
					$mountpoint = substr(strtoupper($mountpoint), 0, 11);
					$timed_cmd = "/usr/local/sbin/ud-exfat/exfatlabel ".escapeshellarg($dev)." ".escapeshellarg($mountpoint)." 2>/dev/null";
					timed_exec(20, $timed_cmd);
				} else {
					unassigned_log("Warning: 'exfatlabel' is not installed.");
					$rc = false;
				}
				break;

			default:
				unassigned_log("Warning: Cannot change the disk label on device '".basename($dev)."'.");
				$rc = false;
				break;
		}

		return $rc;
	};

	if ($mountpoint) {
		$rc = check_for_duplicate_share($dev, $mountpoint);

		if ($rc) {
			$mountpoint = safe_name(basename($mountpoint));

			if ($fstype == 'crypto_LUKS') {
				$timed_cmd = "/sbin/cryptsetup config ".escapeshellarg($dev)." --label ".escapeshellarg($mountpoint)." 2>/dev/null";
				timed_exec(20, $timed_cmd);

				$pass = decrypt_data(get_config($serial, "pass"));
				$mapper = $mountpoint;
				$mapper_device = "/dev/mapper/".$mapper;

				if (MiscUD::luks_open_device($dev, $mapper, $pass)) {
					$mapper_fstype = part_fs_type($mapper_device, false, true);
					$rc = $change_disk_label($mapper_device, $mapper_fstype, $mountpoint);

					MiscUD::luks_close_device($mapper);
				} else {
					$rc = false;
				}
			} else {
				$rc = $change_disk_label($dev, $fstype, $mountpoint);
			}

			if ($rc) {
				$mountpoint = $paths['usb_mountpoint']."/".$mountpoint;
				set_config($serial, "mountpoint.{$partition}", $new_mount);
			}
		}

		sleep(1);
	} else {
		set_config($serial, "mountpoint.".$partition, $new_mount);
	}

	return $rc;
}

/* Change samba mount point. */
function change_samba_mountpoint($dev, $mountpoint) {
	global $paths;

	$rc = true;

	if ($mountpoint) {
		$rc = check_for_duplicate_share($dev, $mountpoint);
		if ($rc) {
			set_samba_config($dev, "mountpoint", $mountpoint);
		}
	} else {
		unassigned_log("Cannot change mount point! Mount point is blank.");
		$rc = false;
	}

	return $rc;
}

/* Change iso file mount point. */
function change_iso_mountpoint($dev, $mountpoint) {
	global $paths;

	$rc = true;

	if ($mountpoint) {
		$rc = check_for_duplicate_share($dev, $mountpoint);
		if ($rc) {
			set_iso_config($dev, "mountpoint", $mountpoint);
		} else {
		}
	} else {
		unassigned_log("Cannot change mount point! Mount point is blank.");
		$rc = false;
	}

	return $rc;
}

/* Change the disk UUID. */
function change_UUID($dev) {
	global $paths, $var;

	$rc			= "";
	$fs_type	= "";
	$serial		= "";
	$luks		= "";

	/* Locate disk info */
	foreach (get_all_disks_info() as $d) {
		if ($d['device'] == $dev) {
			$fs_type	= $d['partitions'][0]['fstype'];
			$serial		= $d['partitions'][0]['serial'];
			$luks		= $d['partitions'][0]['luks'];
			break;
		}
	}

	/* nvme disk partitions are 'p1', not '1'. */
	$device = get_partition_designation($dev);

	/* UUID change helper */
	$change_uuid = function($fs, $target) {
		$rc			= "";
		$timed_cmd	= "";

		switch ($fs) {
			case 'xfs':
				$timed_cmd	= "/usr/sbin/xfs_admin -U generate ".escapeshellarg($target);
				$rc			= timed_exec(60, $timed_cmd);
				break;

			case 'btrfs':
				$timed_cmd	= "/sbin/btrfstune -uf ".escapeshellarg($target);
				$rc			= timed_exec(60, $timed_cmd);
				break;

			case 'ext4':
				$timed_cmd	= "/sbin/tune2fs -U random ".escapeshellarg($target);
				$rc			= timed_exec(60, $timed_cmd);
				break;

			case 'ntfs':
				$timed_cmd	= "/sbin/ntfslabel --new-serial=random  ".escapeshellarg($target);
				$rc			= timed_exec(60, $timed_cmd);
				break;

			default:
				$rc	= "Cannot change UUID on a '".$fs."' file system";
				break;
		}

		return $rc;
	};

	/* Deal with crypto_LUKS disks */
	if ($fs_type == "crypto_LUKS") {
		/* Update LUKS UUID first. */
		$uuid		= trim(file_get_contents("/proc/sys/kernel/random/uuid"));
		$ret_code	= 0;

		$timed_cmd	= "/usr/bin/printf 'YES\n' | /sbin/cryptsetup luksUUID --uuid ".escapeshellarg($uuid)." ".escapeshellarg($device);
		timed_exec(20, $timed_cmd, true, $ret_code);

		if ($ret_code == 0) {
			$verify_code	= 0;
			$timed_cmd		= "/sbin/cryptsetup luksUUID ".escapeshellarg($device);
			$luks_uuid		= timed_exec(10, $timed_cmd, true, $verify_code);

			if (($verify_code != 0) || ($luks_uuid != $uuid)) {
				unassigned_log("Warning: LUKS UUID update verification failed on '".$device."'.");
			} else {
				unassigned_log("LUKS UUID changed to ".$luks_uuid);
			}
		} else {
			unassigned_log("Warning: LUKS UUID update failed on '".$device."', return code: ".$ret_code.".");
		}

		/* Open LUKS */
		$pass			= decrypt_data(get_config($serial, "pass"));
		$mapper			= basename($luks)."_UUID";
		$mapper_device	= "/dev/mapper/".$mapper;
		if (! MiscUD::luks_open_device($luks, $mapper, $pass)) {
			$rc = false;
		} else {
			/* Change UUID inside mapper filesystem */
			$inner_fs	= part_fs_type($mapper_device, false, true);

			$rc = $change_uuid($inner_fs, $mapper_device);

			/* Close LUKS */
			MiscUD::luks_close_device($mapper);
		}
	} else {
		/* Non-encrypted filesystem */
		$rc = $change_uuid($fs_type, $device);
	}

	sleep(2);

	/* Show the result of the UUID change operation */
	if ($rc) {
		unassigned_log("Changed partition UUID on '".$device."' with result: ".$rc);
	}
}

/**
 * Determine if a ZFS pool has all features enabled (fully upgraded).
 *
 * @param string $pool_name Name of the ZFS pool
 * @return bool True if fully upgraded, false if upgrade is needed
 */
function is_upgraded_ZFS_pool($pool_name) {
	$needs_upgrade = false;

	/* First, try feature@all. */
	$cmd_features = "/usr/sbin/zpool get -H feature@all ".escapeshellarg($pool_name)." 2>/dev/null";
	$output_features = timed_exec(3, $cmd_features, true);

	if ($output_features !== false && strlen(trim($output_features)) > 0) {
		$lines = is_array($output_features) ? $output_features : explode("\n", trim($output_features));
		foreach ($lines as $line) {
			$cols = preg_split('/\s+/', trim($line));
			if (isset($cols[2]) && $cols[2] === 'disabled') {
				$needs_upgrade = true;
				break;
			}
		}
	} else {
		/* Fallback: parse zpool status if feature@all is empty. */
		$cmd_status = "/usr/sbin/zpool status ".escapeshellarg($pool_name)." 2>/dev/null";
		$output_status = timed_exec(3, $cmd_status, true);

		if ($output_status !== false && strlen(trim($output_status)) > 0) {
			$lines = is_array($output_status) ? $output_status : explode("\n", trim($output_status));
			foreach ($lines as $line) {
				if (stripos($line, 'features are not enabled') !== false) {
					$needs_upgrade = true;
					break;
				}
			}
		}
	}

	/* true if fully upgraded, false if upgrade is needed. */
 	return (! $needs_upgrade);
}

/* Upgrade the ZFS pool fully, including any remaining features. */
function upgrade_ZFS_pool($pool_name) {
	/* Safety limit in case of unexpected behavior. */
  	$max_attempts	= 3;
	$attempt		= 0;

	while (! is_upgraded_ZFS_pool($pool_name) && $attempt < $max_attempts) {
		$attempt++;
		$timed_cmd = "/usr/sbin/zpool upgrade ".escapeshellarg($pool_name);
		timed_exec(10, $timed_cmd, true);

		unassigned_log("ZFS pool '{$pool_name}' upgrade attempt {$attempt} completed.");

		/* Pause to let ZFS settle. */
 		sleep(2);
	}

	if (is_upgraded_ZFS_pool($pool_name)) {
		unassigned_log("ZFS pool '{$pool_name}' is fully upgraded.");
	} else {
		unassigned_log("ZFS pool '{$pool_name}' upgrade incomplete after {$max_attempts} attempts!");
	}
}
?>
