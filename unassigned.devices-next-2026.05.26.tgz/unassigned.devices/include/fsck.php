<?php
/*
Copyright (C) 2016-2026 Dan Landon
Licensed under the Unassigned Devices - Next Personal Use License v1.0
See LICENSE.md for full license terms.
*/

/* Load the UD library file if it is not already loaded. */
require_once("plugins/unassigned.devices/include/lib.php");

readfile('logging.htm');

/* Write text to the pop up dialog. */
function write_log($string) {
	if ($string) {
		$string = str_replace("\n", "<br>", $string);
		$string = str_replace('"', "\\\"", trim($string));
		echo "<script>addLog(\"{$string}\");</script>";
		@flush();
	}
}

/* Main entry point. */
if ( isset($_GET['device']) && isset($_GET['fs']) ) {
	$device		= htmlspecialchars(urldecode($_GET['device']));
	$fs			= htmlspecialchars(urldecode($_GET['fs']));
	$check_type	= htmlspecialchars(urldecode($_GET['check_type'] ?? 'ro'));
	$luks		= htmlspecialchars(urldecode($_GET['luks']));
	$serial		= htmlspecialchars(urldecode($_GET['serial']));
	$mountpoint	= htmlspecialchars(urldecode($_GET['mountpoint'] ?? ""));
	$mounted	= is_mounted("", $mountpoint);
	$rc_check	= 0;
	$rc			= true;

	/* If the disk format is encrypted, we need to open the luks device. */
	if (($fs == "crypto_LUKS") && (! $mounted)) {
		write_log("Opening crypto_LUKS device '".htmlspecialchars($luks)."'...<br>");

		/* Open the luks device. */
		$pass	= decrypt_data(get_config($serial, "pass"));
		if (! MiscUD::luks_open_device($luks, $device, $pass)) {
			write_log("luksOpen: device failed to open.<br>");
			$rc = false;
		}
	}

	/* If there was no error from the luks open command or the disk is not encrypted, go ahead with the file check. */
	$file_system = $rc ? part_fs_type($device, false, true) : "";

	/* Display the file system. */
	write_log("File System: $file_system<br><br>");

	/* If this is a zfs device, and part_fs_type did not find the file system, use fs. */
	if (! $file_system) {
		$file_system = $fs;
	}

	/* A BTRFS file system scrub is done on the mountpoint, not the physical device. */
	if ($file_system == "btrfs") {
		$device		= $mountpoint;
	}

	/* If all is good, perform the file system check or scrub. */
	if ($rc) {
		if ($file_system) {
			/* If the file system is btrfs or zfs, we will do a scrub. */
			if (($file_system == "btrfs") || ($file_system == "zfs")) {
				if ($mounted) {
					write_log(_('Executing file system scrub:'));
				}
			} else {
				write_log(_('Executing file system check:'));
			}

			/* Get the file system check command based on the file system. */
			if ($file_system == "zfs") {
				if ($mounted) {
					$pool_name	= MiscUD::zfs_pool_name("", $mountpoint);
					$command	= get_fsck_commands($file_system, escapeshellarg($pool_name), $check_type)." 2>&1";
				} else {
					$command	= "";
				}
			} else if (($file_system != "btrfs") || (($file_system == "btrfs") && ($mounted))) {
				$command		= get_fsck_commands($file_system, escapeshellarg($device), $check_type)." 2>&1";
			} else {
				$command		= "";
			}

			/* If the command is defined, execute the command. */
			if ($command) {
				write_log($command."<br>");

				/* Execute the fsck command and pipe it to $proc. */
				$proc = popen($command, 'r');
				$already_running	= false;
				while (! feof($proc)) {
					$line = fgets($proc);
					if ($line === false) {
						break;
					}
					write_log($line);

					/* Check if scrub is already running */
					if ((($file_system == "btrfs") && (stripos($line, 'Scrub is already running') !== false)) || (($file_system == "zfs") && (stripos($line, 'currently scrubbing') !== false))) {
						$already_running = true;
					}
				}

				/* Show the results of the zfs scrub. */
				if (($file_system == "zfs")  && (! $already_running)) {
					$command = "/usr/sbin/zpool status ".escapeshellarg($pool_name);
					/* Execute the status command and pipe it to $proc. */
					$proc = popen($command, 'r');
					while (! feof($proc)) {
						$line = fgets($proc);
						if ($line === false) {
							break;
						}
						write_log($line);
					}
				}

				/* Close $proc and get the process error code. */
				$rc_check = pclose($proc);
			}
		} else {
			if ($fs == "crypto_LUKS") {
				write_log(_('Cannot determine file system on an encrypted disk')."!<br>");
			}
			$rc_check = 0;
		}
	}

	/* Close the device if it is encrypted. */
	if (($fs == "crypto_LUKS") && (! $mounted)) {
		write_log("Closing crypto_LUKS device '".htmlspecialchars($luks)."'...<br>");

		MiscUD::luks_close_device($device);
	}
}

/* Btrfs file systems have to be mounted to scrub them. */
if ((($file_system == "btrfs") || ($file_system == "zfs")) && (! $mounted)) {
	write_log("<br>"._('A btrfs or zfs file system has to be mounted to be scrubbed')."!<br>");
} else {
	/* Check the fsck return code and process the return code. */
	if (($rc_check != 0) && (! $already_running)) {
		if ((($file_system == "xfs") && ($rc_check == 1)) || (($file_system != "xfs") && ($file_system != "zfs"))) {
			write_log("<br>"._('File system corruption detected')."!<br>");
			write_log("<center><button type='button' onclick='document.location=\"/plugins/".UNASSIGNED_PLUGIN."/include/fsck.php?device={$device}&fs={$fs}&luks={$luks}&serial={$serial}&check_type=rw&type="._('Done')."\"'>"._('Run with Correct flag')."</button></center>");
		} else if (($file_system == "xfs") && ($rc_check == 2)) {
			write_log("<br>"._('Dirty log detected')."!<br>");
			write_log("<center><button type='button' onclick='document.location=\"/plugins/".UNASSIGNED_PLUGIN."/include/fsck.php?device={$device}&fs={$fs}&luks={$luks}&serial={$serial}&check_type=log&type="._('Done')."\"'>"._('Force Log Zeroing')."</button></center>");
			write_log("<br>"._('Note: While there is some risk, if it is not possible to first mount the filesystem to clear the log, zeroing it is the only option to try and repair the filesystem, and in most cases it results in little or no data loss').".&nbsp;&nbsp;");
		} else if (($file_system == "xfs") && ($rc_check == 4)){
			write_log("<br>"._('File system corruption fixed')."!<br>");
		} 
	} else if ($file_system == "xfs") {
		write_log("<br>"._('No file system corruption detected')."!<br>");
	}
}
?>
