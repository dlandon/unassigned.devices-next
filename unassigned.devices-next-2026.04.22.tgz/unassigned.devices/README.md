**Unassigned Devices - Next**

This plugin uses UDEV to automatically mount and share disks that are not part of your Unraid array. Available devices are listed under the **Main->Unassigned Devices** tab.

You can also mount remote SMB and NFS shares hosted on other servers.

**Note:** CIFS/SMB and NFS remote mounts are only as reliable as the network and remote server. Unassigned Devices manages the mounts but cannot guarantee stability across LAN, VPN, or internet interruptions.

Originally developed and maintained by Dan Landon.

Project repository, documentation, and license information are available on GitHub.
