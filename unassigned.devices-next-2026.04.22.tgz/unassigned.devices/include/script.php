<?php
/*
Copyright (C) 2016-2026 Dan Landon
Licensed under the Unassigned Devices - Next Personal Use License v1.0
See LICENSE.md for full license terms.
*/

/* Load the UD library file if it is not already loaded. */
require_once("plugins/unassigned.devices/include/lib.php");

/* add translations */
require_once(DOCROOT."/webGui/include/Translations.php");

readfile('logging.htm');

function write_log($string) {
	if ($string) {
		$string = str_replace("\n", "<br \>", $string);
		$string = str_replace('"', "\\\"", trim($string));
		echo "<script>addLog(\"{$string}\");</script>";
		@flush();
	}
}

if ( isset($_GET['device']) && isset($_GET['type']) ) {
	$device = htmlspecialchars(urldecode($_GET['device']));
	$info = get_partition_info($device, true);
	$command = execute_script($info, 'ADD', true);
	if ($command != "") {
		$command = $command." 2>&1";
		putenv("OWNER=udev");
		write_log(_("Executing").": ".basename($command)."<br><br>");
		$proc = popen($command, 'r');
		while (! feof($proc)) {
			write_log(fgets($proc));
		}
	} else if ($command !== false) {
		echo _("No script file to execute")."!";
	} else {
		echo _("Script is already running")."!";
	}
}
?>
