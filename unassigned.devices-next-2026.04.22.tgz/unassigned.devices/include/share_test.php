<?php
/*
Copyright (C) 2026 Dan Landon
Licensed under the Unassigned Devices - Next Personal Use License v1.0
See LICENSE.md for full license terms.
*/

/* 
 *  Execute get_ud_stats Command to test remote server
 */

/* Define our plugin name. */
if (!defined('DOCROOT')) {
	define('DOCROOT', $_SERVER['DOCUMENT_ROOT'] ?: '/usr/local/emhttp');
}

$share_path = htmlspecialchars(urldecode($_POST['share_path']));

/* Execute the get_ud_stats command to check SMB and NFS on a remote server. */
$command = DOCROOT."/plugins/unassigned.devices/scripts/get_ud_stats remote_share_test ".escapeshellarg($share_path);

echo shell_exec($command);
?>
