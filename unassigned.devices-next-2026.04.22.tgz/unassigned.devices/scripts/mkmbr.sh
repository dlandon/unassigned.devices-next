#!/bin/bash
#
#
# Copyright (C) 2026 Dan Landon
# Licensed under the Unassigned Devices - Next Personal Use License v1.0
# See LICENSE.md for full license terms.
#

#
# Write an Unraid-compatible MBR + preclear signature.
#
# usage: mkmbr.sh /dev/sdX [start_sector]

device="$1"
start_sector="${2:-64}"

#
# Read disk size (512-byte sectors)
#
blocks_512=$(/sbin/blockdev --getsz "$device" 2>/dev/null)

write_signature() {
	local disk="$device"
	local disk_blocks="$blocks_512"
	local max_mbr_blocks=$(/bin/printf "%d" 0xFFFFFFFF)
	local size1=0
	local size2=0
	local part_start="$start_sector"
	local part_size=$((disk_blocks - part_start))
	local sig=""

	#
	# Handle very large disks (same logic as original mkmbr)
	#
	if [ "$disk_blocks" -ge "$max_mbr_blocks" ]; then
		size1=$(/bin/printf "%d" 0x00020000)
		size2=$(/bin/printf "%d" 0xFFFFFF00)
		part_start=1
		part_size=$(/bin/printf "%d" 0xFFFFFFFF)
	fi

	#
	# Zero first MBR block
	#
	/bin/dd if=/dev/zero of="$disk" bs=512 count=1 >/dev/null 2>&1

	#
	# Build 16-byte Unraid signature (4 words little-endian)
	#
	for val in $size1 $size2 $part_start $part_size ; do
		hexword=$(/bin/printf "%08x" "$val")
		byte1=${hexword:6:2}
		byte2=${hexword:4:2}
		byte3=${hexword:2:2}
		byte4=${hexword:0:2}
		sig="${sig}\\x$byte1\\x$byte2\\x$byte3\\x$byte4"
	done

	#
	# Insert 16-byte signature at offset 446
	#
	/bin/printf "$sig" | /bin/dd of="$disk" bs=1 seek=446 count=16 >/dev/null 2>&1

	#
	# ----- Partition Entry (matches original Unraid mkmbr) -----
	#

	#
	# Boot flag = 0x00
	#
	echo -ne "\x00" | /bin/dd of="$disk" bs=1 seek=446 count=1 >/dev/null 2>&1

	#
	# Dummy CHS start = 00 02 00
	#
	echo -ne "\x00\x02\x00" | /bin/dd of="$disk" bs=1 seek=447 count=3 >/dev/null 2>&1

	#
	# Partition type = 0x83
	#
	echo -ne "\x83" | /bin/dd of="$disk" bs=1 seek=450 count=1 >/dev/null 2>&1

	#
	# Dummy CHS end = FE FF FF
	#
	echo -ne "\xFE\xFF\xFF" | /bin/dd of="$disk" bs=1 seek=451 count=3 >/dev/null 2>&1

	#
	# LBA start (4 bytes LE)
	#
	part_start_hex=$(printf "%08x" "$part_start")
	echo -ne "\x${part_start_hex:6:2}\x${part_start_hex:4:2}\x${part_start_hex:2:2}\x${part_start_hex:0:2}" \
		| dd of="$disk" bs=1 seek=454 count=4 >/dev/null 2>&1

	#
	# LBA length (4 bytes LE)
	#
	part_size_hex=$(printf "%08x" "$part_size")
	echo -ne "\x${part_size_hex:6:2}\x${part_size_hex:4:2}\x${part_size_hex:2:2}\x${part_size_hex:0:2}" \
		| dd of="$disk" bs=1 seek=458 count=4 >/dev/null 2>&1

	#
	# Boot signature 55 AA
	#
	echo -ne "\x55\xAA" | /bin/dd of="$disk" bs=1 seek=510 count=2 >/dev/null 2>&1
}

write_signature

echo "MBR written to $device (start_sector=${start_sector}, partition_size=${part_size})"
