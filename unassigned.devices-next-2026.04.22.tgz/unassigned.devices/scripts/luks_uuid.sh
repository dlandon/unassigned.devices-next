#!/bin/bash
#
#
# Copyright (C) 2016-2026 Dan Landon
# Licensed under the Unassigned Devices - Next Personal Use License v1.0
# See LICENSE.md for full license terms.
#

#
# Change luks device UUID
#
uuid=`/bin/cat /proc/sys/kernel/random/uuid`

/sbin/cryptsetup luksUUID --uuid=$uuid $1 <<<'YES\n'
