#!/bin/bash
#
# Copyright (C) 2016-2026 Dan Landon
# Licensed under the Unassigned Devices - Next Personal Use License v1.0
# See LICENSE.md for full license terms.
#

plugin="unassigned.devices"

#
# Be sure all directories in the ram tmpfs file system exist.
#
/usr/bin/mkdir -p \
	/tmp/"$plugin"/logs \
	/tmp/"$plugin"/config \
	/tmp/"$plugin"/scripts \
	/tmp/"$plugin"/diagnostics \
	/tmp/"$plugin"/credentials \
	/tmp/"$plugin"/authentication \
	/tmp/"$plugin"/luks_pass

/usr/bin/chmod 755 \
	/tmp/"$plugin" \
	/tmp/"$plugin"/logs \
	/tmp/"$plugin"/config \
	/tmp/"$plugin"/scripts \
	/tmp/"$plugin"/diagnostics

/usr/bin/chmod 700 \
	/tmp/"$plugin"/credentials \
	/tmp/"$plugin"/authentication \
	/tmp/"$plugin"/luks_pass
	
#
# Copy config files to ram tmpfs.
#
/usr/bin/rm -f /tmp/"$plugin"/config/*.cfg
/usr/bin/cp /boot/config/plugins/"$plugin"/*.cfg /tmp/"$plugin"/config/ 2>/dev/null

#
# Clear run status, ping, size used and free, and udev device stats.
#
/usr/local/emhttp/plugins/"$plugin"/scripts/get_ud_stats clear_stats
