#!/bin/bash
#
# Copyright 2015-2020 Guilherme Jardim
#
# Copyright (C) 2022-2026 Dan Landon
# Licensed under the Unassigned Devices Preclear - Next Personal Use License v1.0
# See LICENSE.md for full license terms.
#

LC_CTYPE=C
export LC_CTYPE

#
# Run the preclear controller at a lower priority.
# Long-running worker commands are also wrapped with PRECLEAR_PRIORITY_CMD below.
#
PRECLEAR_NICE_LEVEL=10
PRECLEAR_IONICE_CLASS=2
PRECLEAR_IONICE_LEVEL=7

renice -n "$PRECLEAR_NICE_LEVEL" -p $$ >/dev/null 2>&1

PRECLEAR_PRIORITY_CMD="nice -n $PRECLEAR_NICE_LEVEL"
if command -v ionice >/dev/null 2>&1; then
	ionice -c "$PRECLEAR_IONICE_CLASS" -n "$PRECLEAR_IONICE_LEVEL" -p $$ >/dev/null 2>&1
	PRECLEAR_PRIORITY_CMD="nice -n $PRECLEAR_NICE_LEVEL ionice -c $PRECLEAR_IONICE_CLASS -n $PRECLEAR_IONICE_LEVEL"
fi

#
# Version
#
version="2.0.02"
#
# Change Log
# 1.0.23
# Change file references on flash from preclear.disk to unassigned.devices.preclear.
# Change log file to /var/log/preclear/preclear.log.
# Cleaned up code with tabs instead of spaces for readability.
# Fixed head stress holding up pre-read status.
# Lots of tmux adjustments.
# Stop logging everything to the syslog.  Way too chatty!
#
# 1.0.24
# Fix preclear status to right justify the preclear results.
# Fix integer error on notify check.
#
# 1.0.25
# Only write resume file to flash when absolutely necessary.
# Fix diff calculation when POS is H/M/S notation.
#
# 1.0.26
# Remove SMART assessment in SMART report.
#
#
# 1.0.27
# Prevent divide by zero when checking root free space.
#
# 1.0.28
# Double dd_hang timeout when reading and writing to disk.
#
#
# 1.0.29
# Don't read disk data into memory and check to be zero when
# doing post-read.  Disk data is read, but not confirmed
# to be zero.
#
# 1.0.30
# Increase dd_hang timeout even more when reading and writing to disk.
#
# 1.0.31
# Add date and time to preclear report.
#
# 2.0.01
# Major rewrite
#
# Fix notify messages showing duplicate information.
# Refactor disk write for better performance and error reporting.
# Refactor disk read for better performance and error reporting.
# Refactor a lot of code for robustness, reliability and to fix code issues.
#
# 2.0.02
# Adjust priorities to not overload the server on preclears
#
######################################################
##													##
##				PROGRAM FUNCTIONS					##
##													##
######################################################

DOCROOT=`grep -Po '^chdir = \K.*' /etc/php-fpm.d/www.conf 2>/dev/null`
DOCROOT="${DOCROOT:-/usr/local/emhttp}"

#
# Send messages to log
#
preclear_log() {
	local msg="$*"
	local ts

	ts="$(date +"%b %d %T")"

	if [ -z "$msg" ]; then
		while IFS= read -r msg; do
			printf "%s %s %s\n" "$ts" "$log_prefix" "$msg" >> /var/log/preclear/preclear.log
		done
	else
		printf "%s %s %s\n" "$ts" "$log_prefix" "$msg" >> /var/log/preclear/preclear.log
	fi
}

trim() {
	local var="$*"
	if [ -z "$var" ]; then
		read var;
	fi
	var="${var#"${var%%[![:space:]]*}"}"	# remove leading whitespace characters
	var="${var%"${var##*[![:space:]]}"}"	# remove trailing whitespace characters
	echo -n "$var"
}

list_unraid_disks(){
	local _result=$1
	local i=0
	#
	# Get flash disk device
	#
	unraid_disks[$i]=$(readlink -f /dev/disk/by-label/UNRAID|grep -Po "[^\d]*")

	#
	# Grab cache disks using disks.cfg file
	#
	if [ -f "/boot/config/disk.cfg" ]
	then
		while read line ; do
			if [ -n "$line" ]; then
				let "i+=1" 
				unraid_disks[$i]=$(find /dev/disk/by-id/ -type l -iname "*-$line*" ! -iname "*-part*"| xargs readlink -f)
			fi
		done < <(cat /boot/config/disk.cfg | grep 'cacheId' | grep -Po '=\"\K[^\"]*')
	fi

	#
	# Get array disks using super.dat id's
	#
	if [ -f "/var/local/emhttp/disks.ini" ]; then
		while read line; do
			disk="/dev/${line}"
			if [ -n "$disk" ]; then
				let "i+=1"
				unraid_disks[$i]=$(readlink -f $disk)
			fi
		done < <(cat /var/local/emhttp/disks.ini | grep -Po 'device="\K[^"]*')
	fi
	eval "$_result=(${unraid_disks[@]})"
}

list_all_disks(){
	local _result=$1
	for disk in $(find /dev/disk/by-id/ -type l ! \( -iname "wwn-*" -o -iname "*-part*" \))
	do
		all_disks+=($(readlink -f $disk))
	done
	eval "$_result=(${all_disks[@]})"
}

is_preclear_candidate () {
	list_unraid_disks unraid_disks
	part=($(comm -12 <(for X in "${unraid_disks[@]}"; do echo "${X}"; done|sort)	<(echo $1)))
	if [ ${#part[@]} -eq 0 ] && [ $(cat /proc/mounts|grep -Poc "^${1}") -eq 0 ]
	then
		return 0
	else
		return 1
	fi
}

#
# list the disks that are not assigned to the array. They are the possible drives to pre-clear
#
list_device_names() {
	echo "========================================"
	echo " Disks not assigned to the Unraid array "
	echo " (potential candidates for clearing)"
	echo "========================================"
	list_unraid_disks unraid_disks
	list_all_disks all_disks
	unassigned=($(comm -23 <(for X in "${all_disks[@]}"; do echo "${X}"; done|sort)	<(for X in "${unraid_disks[@]}"; do echo "${X}"; done|sort)))

	if [ ${#unassigned[@]} -gt 0 ]
	then
		for disk in "${unassigned[@]}"
		do
			if [ $(cat /proc/mounts|grep -Poc "^${disk}") -eq 0 ]
			then
				serial=$(udevadm info --query=property --path $(udevadm info -q path -n $disk 2>/dev/null) 2>/dev/null|grep -Po "ID_SERIAL=\K.*")
				echo "  ${disk} = ${serial}"
			fi
		done
	else
		echo "No un-assigned disks detected."
	fi
}

list_unassigned_disks() {
	list_unraid_disks unraid_disks
	list_all_disks all_disks
	unassigned=($(comm -23 <(for X in "${all_disks[@]}"; do echo "${X}"; done|sort)	<(for X in "${unraid_disks[@]}"; do echo "${X}"; done|sort)))

	if [ ${#unassigned[@]} -gt 0 ]
	then
		for disk in "${unassigned[@]}"
		do
			if [ $(cat /proc/mounts|grep -Poc "^${disk}") -eq 0 ]
			then
				serial=$(udevadm info --query=property --path $(udevadm info -q path -n $disk 2>/dev/null) 2>/dev/null|grep -Po "ID_SERIAL=\K.*")
				name=$(basename $disk)
				echo "$name = $serial"
			fi
		done
	fi
}

#
# Send notifications.
#
send_notify() {
	local subject="Preclear"
	local description="$1"
	local message="$2"
	local recipient="$3"
	local importance="${4:-normal}"
	local notify_script

	notify_script="${DOCROOT}/webGui/scripts/notify"

	"$notify_script" -e "Preclear on ${disk_properties[serial]}" -s "$subject" -d "$description" -m "$message" -i "$importance"
}


append() {
	local _array=$1 _array_keys="${1}_keys" _k _key;
	eval "local x=\${$_array+x}"
	if [ -z $x ]; then
		eval "declare -g -A $_array"
		eval "declare -g -a $_array_keys"
	fi
	if [ "$#" -eq "3" ]; then
		_key=$2
		el=$(printf "[$_key]='%s'" "${@:3}")
	else
		for (( i = 0; i < 1000; i++ )); do
			eval "_k=\${$_array[$i]+x}"
			if [ -z "$_k" ] ; then
				break
			fi
		done
		_key=$i
		el="[$_key]=\"${@:2}\""
	fi
	eval "$_array+=($el);$_array_keys+=($_key)";
}

array_content() {
	#
	# Return the RHS of the declare output for use with eval
	#
	local arr_name=$1
	declare -p "$arr_name" 2>/dev/null | sed -E 's/^[^=]+=//'
}

read_preclear_signature() {
	local disk=$1 i
	local mbr

	#
	# verify MBR boot area is clear
	#
	append mbr `dd bs=446 count=1 if=$disk 2>/dev/null | sum | awk '{print $1}'`

	#
	# verify partitions 2,3, & 4 are cleared
	#
	append mbr `dd bs=1 skip=462 count=48 if=$disk 2>/dev/null | sum | awk '{print $1}'`

	#
	# verify partition type byte is clear
	#
	append mbr `dd bs=1 skip=450 count=1 if=$disk 2>/dev/null | sum | awk '{print $1}'`

	#
	# verify MBR signature bytes are set as expected
	#
	append mbr `dd bs=1 count=1 skip=511 if=$disk 2>/dev/null | sum | awk '{print $1}'`
	append mbr `dd bs=1 count=1 skip=510 if=$disk 2>/dev/null | sum | awk '{print $1}'`

	for i in $(seq 446 461); do
		append mbr `dd bs=1 count=1 skip=$i if=$disk 2>/dev/null | sum | awk '{print $1}'`
	done

	echo $(declare -p mbr)
}

write_preclear_signature() {
	local disk=$1
	local disk_blocks=${disk_properties[blocks_512]} 
	local max_mbr_blocks partition_size size1=0 size2=0 sig start_sector=64 var
	let partition_size=($disk_blocks - $start_sector)
	max_mbr_blocks=$(printf "%d" 0xFFFFFFFF)
	
	preclear_log "Signature: writing signature..."

	if [ $disk_blocks -ge $max_mbr_blocks ]; then
		size1=$(printf "%d" "0x00020000")
		size2=$(printf "%d" "0xFFFFFF00")
		start_sector=1
		partition_size=$(printf "%d" 0xFFFFFFFF)
	fi

	dd if=/dev/zero bs=1 seek=462 count=48 of=$disk >/dev/null 2>&1
	dd if=/dev/zero bs=446 count=1 of=$disk	>/dev/null 2>&1
	echo -ne "\0252" | dd bs=1 count=1 seek=511 of=$disk >/dev/null 2>&1
	echo -ne "\0125" | dd bs=1 count=1 seek=510 of=$disk >/dev/null 2>&1

	awk 'BEGIN{
	printf ("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[1]),7,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[1]),5,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[1]),3,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[1]),1,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[2]),7,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[2]),5,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[2]),3,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[2]),1,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[3]),7,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[3]),5,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[3]),3,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[3]),1,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[4]),7,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[4]),5,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[4]),3,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[4]),1,2)))
	}' $size1 $size2 $start_sector $partition_size | dd seek=446 bs=1 count=16 of=$disk >/dev/null 2>&1

	local sig=$(awk 'BEGIN{
	printf ("%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c%c",
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[1]),7,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[1]),5,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[1]),3,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[1]),1,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[2]),7,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[2]),5,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[2]),3,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[2]),1,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[3]),7,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[3]),5,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[3]),3,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[3]),1,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[4]),7,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[4]),5,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[4]),3,2)),
	strtonum("0x" substr(sprintf( "%08x\n", ARGV[4]),1,2)))
	}' $size1 $size2 $start_sector $partition_size | od -An -vtu1 )

	#
	# Ensure all writes are flushed
	#
	sync
}

verify_preclear_signature() {
	local cleared
	local disk=$1
	local disk_blocks=${disk_properties[blocks_512]}
	local i
	local max_mbr_blocks
	local mbr_blocks
	local over_mbr_size
	local partition_size
	local patterns
	local -a sectors
	local start_sector 
	local patterns=("00000" "00000" "00000" "00170" "00085")
	local max_mbr_blocks=$(printf "%d" 0xFFFFFFFF)

	if [ $disk_blocks -ge $max_mbr_blocks ]; then
		over_mbr_size="y"
		patterns+=("00000" "00000" "00002" "00000" "00000" "00255" "00255" "00255")
		partition_size=$(printf "%d" 0xFFFFFFFF)
	else
		patterns+=("00000" "00000" "00000" "00000" "00000" "00000" "00000" "00000")
		partition_size=$disk_blocks
	fi

	#
	# verify MBR boot area is clear
	#
	sectors+=(`dd bs=446 count=1 if=$disk 2>/dev/null | sum | awk '{print $1}'`)

	#
	# verify partitions 2,3, & 4 are cleared
	#
	sectors+=(`dd bs=1 skip=462 count=48 if=$disk 2>/dev/null | sum | awk '{print $1}'`)

	#
	# verify partition type byte is clear
	#
	sectors+=(`dd bs=1 skip=450 count=1 if=$disk 2>/dev/null | sum | awk '{print $1}'`)

	#
	# verify MBR signature bytes are set as expected
	#
	sectors+=(`dd bs=1 count=1 skip=511 if=$disk 2>/dev/null | sum | awk '{print $1}'`)
	sectors+=(`dd bs=1 count=1 skip=510 if=$disk 2>/dev/null | sum | awk '{print $1}'`)

	for i in $(seq 446 461); do
		sectors+=(`dd bs=1 count=1 skip=$i if=$disk 2>/dev/null | sum | awk '{print $1}'`)
	done

	for i in $(seq 0 $((${#patterns[@]}-1)) ); do
		if [ "${sectors[$i]}" != "${patterns[$i]}" ]; then
			echo "Failed test 1: MBR signature is not valid, byte $i [${sectors[$i]}] != [${patterns[$i]}]"
			return 1
		fi
	done

	for i in $(seq ${#patterns[@]} $((${#sectors[@]}-1)) ); do
		if [ $i -le 16 ]; then
			start_sector="$(echo ${sectors[$i]} | awk '{printf("%02x", $1)}')${start_sector}"
		else
			mbr_blocks="$(echo ${sectors[$i]} | awk '{printf("%02x", $1)}')${mbr_blocks}"
		fi
	done

	start_sector=$(printf "%d" "0x${start_sector}")
	mbr_blocks=$(printf "%d" "0x${mbr_blocks}")

	case "$start_sector" in
		63|64)
			if [ $disk_blocks -ge $max_mbr_blocks ]; then
				partition_size=$(printf "%d" 0xFFFFFFFF)
			else
				let partition_size=($disk_blocks - $start_sector)
			fi
			;;
		1)
			if [ "$over_mbr_size" != "y" ]; then
				preclear_log "Failed test 2: GPT start sector [$start_sector] is wrong, should be [1]."
				return 1
			fi
			;;
		*)
			preclear_log "Failed test 3: start sector is different from those accepted by Unraid."
			return 1
			;;
	esac
	if [ $partition_size -ne $mbr_blocks ]; then
		preclear_log "Failed test 4: physical size didn't match MBR declared size. [$partition_size] != [$mbr_blocks]"

		return 1
	fi

	return 0
}

erase_preclear_signature() {
	local disk=$1

	preclear_log "Erasing MBR on $disk..."

	#
	# Zero out the first 512 bytes (MBR)
	#
	dd if=/dev/zero of="$disk" bs=512 count=1 conv=fsync >/dev/null 2>&1

	#
	# Ensure all writes are flushed
	#
	sync
}

maxExecTime() {
	#
	# maxExecTime prog_name disk_name max_exec_time
	#
	local exec_time=0
	local prog_name="$1"
	local disk_name
	local max_exec_time="$3"

	disk_name="$(basename "$2")"

	while IFS= read -r pid; do
		local pid_date
		local pid_child
		local pid_elapsed

		pid_date="$(stat -c %X "/proc/$pid" 2>/dev/null)"
		pid_child="$(ps -h --ppid "$pid" 2>/dev/null | grep -c .)"

		if [ -n "$pid_date" ] && [ "$pid_child" -eq 0 ]; then
			pid_elapsed=$(( $(date +%s) - pid_date ))

			if [ "$pid_elapsed" -gt "$exec_time" ]; then
				exec_time="$pid_elapsed"
			fi

			if [ "$pid_elapsed" -gt "$max_exec_time" ]; then
				preclear_log "killing ${prog_name} with pid ${pid} - probably stalled..."
				kill -9 "$pid" &>/dev/null
			fi
		fi
	done < <(
		ps ax -o pid=,cmd= |
		awk -v p="$prog_name" -v d="$disk_name" '$0 ~ p && $0 ~ "/dev/"d {print $1}'
	)

	echo "$exec_time"
}

format_number() {
	numfmt --to=si --suffix= --format='%1.1f' --round=nearest "$1" | trim
}

#
# Keep track of the elapsed time of the preread/clear/postread process
#
timer() {
	if [[ $# -eq 0 ]]; then
		date '+%s'
	else
		local stime="$1"
		local etime
		local dt

		etime="$(date '+%s')"

		if [[ -z "$stime" ]]; then
			stime="$etime"
		fi

		dt=$((etime - stime))
		format_time "$dt"
	fi
}

format_time() {
	local time="$1"
	local ds dm dh

	ds=$((time % 60))
	dm=$(((time / 60) % 60))
	dh=$((time / 3600))

	printf '%d:%02d:%02d' "$dh" "$dm" "$ds"
}

time_elapsed() {
	local id="$1"
	local mode="$2"
	local value="$3"
	local current delta
	local elapsed_var="_time_elapsed_${id}"
	local last_var="_time_elapsed_last_${id}"
	local initialized=0

	declare -n elapsed="$elapsed_var"
	declare -n last="$last_var"

	current="$(date '+%s')"

	#
	# Proper initialization check
	#
	declare -p "$elapsed_var" >/dev/null 2>&1 && initialized=1
	if [ "$initialized" -eq 0 ]; then
		elapsed=0
		last="$current"
	fi

	case "$mode" in
		paused)
			last="$current"
			;;
		set)
			elapsed="$value"
			last="$current"
			;;
		display)
			format_time "$elapsed"
			;;
		export)
			echo "$elapsed"
			;;
		*)
			delta=$((current - last))
			last="$current"
			elapsed=$((elapsed + delta))
			;;
	esac
}

dd_parse_status() {
	local output_file=$1
	local regex="([0-9]*) bytes.*copied, ([^\s]*) [^0-9]*(.*)"
	echo > "${output_file}"
	echo > "${output_file}_complete"
	while read line; do
		complete_lines=$(wc -l < "${output_file}_complete" 2>/dev/null)
		complete_lines=${complete_lines:-0}
		if [ $complete_lines -gt 30 ]; then
			echo "$(tail -n 29 "${output_file}_complete")" > "${output_file}_complete"
		fi
		echo "$line" >> "${output_file}_complete"
		if [[ $line =~ $regex ]]; then
			echo "${BASH_REMATCH[1]}|${BASH_REMATCH[2]}|${BASH_REMATCH[3]}" > "$output_file"
		fi
	done
}

get_dd_output() {
	init=$(stat -c %Z "$2")
	kill -USR1 $1 2>/dev/null
	for x in $(seq 10); do
		now=$(stat -c %Z "$2")
		if [ $init -lt $now ]; then
			cat "$2"
			return 0
		fi

		sleep 1
	done
}

is_numeric() {
	local _var=$2 _num=$3
	if [ ! -z "${_num##*[!0-9]*}" ]; then
		eval "$1=$_num"
	else
		echo "$_var value [$_num] is not a number. Please verify your command arguments.";
		exit 2
	fi
}

save_current_status() {
	local tmp_resume
	local current_op current_pos current_timer
	local main_elapsed cycle_elapsed

	#
	# Capture current operation state
	#
	current_op="${diskop[current_op]}"
	current_pos="${diskop[current_pos]}"
	current_timer="${diskop[current_timer]}"

	#
	# Capture elapsed times once
	#
	main_elapsed="$(time_elapsed main export)"
	cycle_elapsed="$(time_elapsed cycle export)"

	#
	# Create a unique temporary file
	#
	tmp_resume="$(mktemp "${all_files[resume_temp]}.XXXXXX")" || return 1

	#
	# Write all state to the temp file in a single block
	#
	{
		printf '# parsed arguments\n'
		for arg in "${!arguments[@]}"; do
			printf "%s='%s'\n" "$arg" "${arguments[$arg]}"
		done

		printf '\n# current operation\n'
		printf "current_op='%s'\n" "$current_op"
		printf "current_pos='%s'\n" "$current_pos"
		printf "current_timer='%s'\n" "$current_timer"
		printf "current_cycle='%s'\n\n" "$cycle"

		printf '# previous operations\n'
		printf "preread_average='%s'\n" "$preread_average"
		printf "preread_speed='%s'\n" "$preread_speed"
		printf "write_average='%s'\n" "$write_average"
		printf "write_speed='%s'\n" "$write_speed"
		printf "postread_average='%s'\n" "$postread_average"
		printf "postread_speed='%s'\n\n" "$postread_speed"

		printf '# current elapsed time\n'
		printf "main_elapsed_time='%s'\n" "$main_elapsed"
		printf "cycle_elapsed_time='%s'\n" "$cycle_elapsed"
	} > "$tmp_resume"

	#
	# Atomically replace the temporary resume file
	#
	mv -f "$tmp_resume" "${all_files[resume_temp]}"

	#
	# Optionally update the permanent resume file
	#
	if [ "$1" = "1" ]; then
		mkdir -p /boot/preclear_reports/
		cp -f "${all_files[resume_temp]}" "${all_files[resume_file]}"
	fi
}

write_the_disk() {
	local blkpid=${all_files[blkpid]}
	local bytes_written=0
	local bytes_dd
	local bytes_dd_current=0
	local cycle=$cycle
	local cycles=$cycles
	local current_speed=0
	local current_elapsed=0
	local dd_exit=${all_files[dd_exit]}
	local dd_flags="conv=notrunc,fsync iflag=count_bytes,nocache,fullblock oflag=seek_bytes"
	local dd_hang=0
	local dd_last_bytes=0
	local dd_pid
	local dd_output=${all_files[dd_out]}
	local disk=${disk_properties[device]}
	local disk_name=${disk_properties[name]}
	local disk_blocks=${disk_properties[blocks]}
	local disk_bytes=${disk_properties[size]}
	local disk_serial=${disk_properties[serial]}
	local last_progress=-1
	local next_notify=-1

	declare -A is_paused_by
	declare -A paused_by
	local pause=${all_files[pause]}
	local is_paused=n
	local do_pause=0

	local percent_written
	local queued=n
	local queued_file=${all_files[queued]}
	local short_test=$short_test
	local skip_initial=0
	local stat_file=${all_files[stat]}
	local tb_formatted
	local total_bytes
	local display_pid=0
	local write_bs=2097152
	local write_type_v
	local write_type=$1
	local initial_bytes=$2
	local initial_timer=$3
	local output=$4
	local output_speed=$5

	local dd_error_detected=0
	local kernel_error_detected=0
	local smart_interval=900
	local last_smart_check=0
	local now=0

	# Full paths for SMART snapshots
	local smart_prev_file="write_prev"
	local smart_current_file="write"
	local smart_delta_file="_write_delta"

	local exit_code=0

	DD_HANG_LIMIT=480

	# Take current SMART snapshot
	save_smart_info "$disk" "$smart_type" "$smart_prev_file"

	resume_timer=${!initial_timer:-0}
	time_elapsed $write_type set $resume_timer

	touch $dd_output
	touch ${dd_output}_complete

	if [ "$short_test" == "y" ]; then
		total_bytes=$(( ($write_bs * 2048 * 2) + 1 ))
	else
		total_bytes=${disk_properties[size]}
	fi

	resume_seek=${!initial_bytes:-0}
	[ "$resume_seek" -eq 0 ] && resume_seek=$write_bs

	if [ "$resume_seek" -gt 0 ]; then
		preclear_log "Continuing disk write on byte $resume_seek"
		local remaining=$(( total_bytes - resume_seek ))
		[ "$remaining" -lt 0 ] && remaining=0
		dd_seek="seek=$resume_seek count=$remaining"
	else
		dd_seek="seek=0 count=$total_bytes"
	fi

	tb_formatted=$(format_number $total_bytes)

	if [ "$write_type" == "zero" ]; then
		write_type_s="Zeroing"
		write_type_v="zeroed"
		device="/dev/zero"
		dd_cmd="$PRECLEAR_PRIORITY_CMD dd if=$device of=$disk bs=$write_bs $dd_seek $dd_flags"
	else
		write_type_s="Erasing"
		write_type_v="erased"
		pass=$(dd if=/dev/urandom bs=128 count=1 2>/dev/null | base64 -w 0)
		openssl_cmd="openssl enc -aes-256-ctr -pass pass:'${pass}' -nosalt"
		$PRECLEAR_PRIORITY_CMD $openssl_cmd < /dev/zero > ${all_files[fifo]} 2>/dev/null &
		dd_cmd="$PRECLEAR_PRIORITY_CMD dd if=${all_files[fifo]} of=${disk} bs=$write_bs $dd_seek $dd_flags iflag=fullblock"
	fi

	#
	# If there is a signature on the disk, remove it
	#
	if [ "$skip_initial" -eq 0 ]; then
		#
		# Remove the signature
		#
		erase_preclear_signature "$disk"
	fi

	$dd_cmd &> >(dd_parse_status $dd_output) & dd_pid=$!
	all_files[dd_pid]=$dd_pid

	if [ "$notify_channel" -gt 0 ] && [ "$notify_freq" -ge 3 ]; then
		report_out="${write_type_s} started on $disk_serial ($disk_name).\\nDisk temperature: $(get_disk_temp $disk "$smart_type")\\n"
		send_notify "${write_type_s} started on $disk_serial ($disk_name). Cycle $cycle of ${cycles}. " "$report_out"
	fi

	local timelapse=$(( $(timer) - 20 ))
	local current_speed_time=$(timer)
	local current_speed_bytes=0
	local current_dd_time=0

	sleep 1

	while kill -0 $dd_pid &>/dev/null; do
		#
		# update elapsed time
		#
		if [ "$is_paused" == "y" ]; then
			time_elapsed $write_type paused && time_elapsed cycle paused && time_elapsed main paused
		else
			time_elapsed $write_type && time_elapsed cycle && time_elapsed main
		fi

		#
		# Update dd output
		#
		dd_status=$(get_dd_output $dd_pid $dd_output)
		bytes_dd=$(echo -n $dd_status | cut -d '|' -f 1 | trim)
		current_dd_time=$(echo -n $dd_status | cut -d '|' -f 2 | trim)

		[ ! -z "${bytes_dd##*[!0-9]*}" ] && bytes_written=$(( $bytes_dd + $resume_seek ))
		bytes_dd_current=$bytes_dd
		let percent_written=($bytes_written*100/$total_bytes)
		[ "$percent_written" -gt 100 ] && percent_written=100

		#
		# Update elapsed time
		#
		current_elapsed=$(time_elapsed $write_type export)

		# Periodic SMART check every $smart_interval (15 minutes)
		now=$(date +%s)
		if (( now - last_smart_check >= $smart_interval )); then
			last_smart_check=$now

			# Take current SMART snapshot
			save_smart_info "$disk" "$smart_type" "$smart_current_file"

			# Skip if current snapshot is empty
			if [ ! -f "${all_files[smart_prefix]}$smart_current_file" ]; then
				preclear_log "SMART snapshot empty for $disk_name, skipping delta check."
				continue
			fi

			# Ensure previous snapshot exists
			if [ ! -f "${all_files[smart_prefix]}$smart_prev_file" ]; then
				cp -f "${all_files[smart_prefix]}$smart_current_file" "${all_files[smart_prefix]}$smart_prev_file"
				continue
			fi

			# Compare snapshots
			compare_smart "$smart_prev_file" "$smart_current_file"  "WRITE_CHECK" "$smart_delta_file"

			# Check delta for critical attributes
			if [ -f "${all_files[smart_prefix]}$smart_delta_file" ] && grep -qE "Reallocated|Pending|Offline|Failing" "${all_files[smart_prefix]}$smart_delta_file"; then
				preclear_log "Critical SMART delta detected on $disk_name, terminating write!"
				kill -9 "$dd_pid" 2>/dev/null
				exit_code=5
				break
			fi
		fi

		#
		# Calculate average speed
		#
		if [ "$current_elapsed" -gt 0 ]; then
			average_speed=$(( $bytes_written / $current_elapsed / 1000000 ))
		fi

		#
		# Calculate current speed
		#
		if [ ! -z "${current_dd_time##*[!0-9.]*}" ]; then
			local bytes_diff=$(awk "BEGIN {printf \"%.2f\",${bytes_dd_current} - ${current_speed_bytes}}")
			local time_diff=$(awk "BEGIN {printf \"%.2f\",${current_dd_time} - ${current_speed_time}}")
			if [ "${time_diff//.}" -ne 0 ]; then
				current_speed=$(awk "BEGIN {printf \"%d\",(${bytes_diff}/${time_diff}/1000000)}")
				current_speed_bytes=$bytes_dd_current
				current_speed_time=$current_dd_time
			fi
		fi

		status="Time elapsed: $(time_elapsed $write_type display) | Current speed: $current_speed MB/s | Average speed: $average_speed MB/s"
		if [ "$cycles" -gt 1 ]; then
			cycle_disp=" ($cycle of $cycles)"
		fi

		local stat_content
		local display_content
		local display_status
		if [ "$is_paused" == "y" ]; then
			if [ -f "$queue_file" ]; then
				stat_content="${write_type_s}${cycle_disp}: QUEUED"
				display_content="${write_type_s} in progress: (${percent_written}% Done) ${bold}QUEUEDS${norm}"
				display_status="** QUEUED"
			else
				stat_content="${write_type_s}${cycle_disp}: PAUSED"
				display_content="${write_type_s} in progress: (${percent_written}% Done) ${bold}PAUSED${norm}"
				display_status="** PAUSED"
			fi
		else
			stat_content="${write_type_s}${cycle_disp}: ${percent_written}% @ $current_speed MB/s ($(time_elapsed $write_type display))"
			display_content="${write_type_s} in progress: (${percent_written}% Done)"
			display_status="** $status"
		fi

		#
		# Update stat file
		#
		echo -n "$disk_name|NN|${stat_content}|$$" > $stat_file

		#
		# Update diskop with current write status
		#
		diskop+=([current_op]="$write_type" \
				 [current_pos]="$bytes_written" \
				 [current_timer]=$(time_elapsed "$write_type" export))

		#
		# Snapshot and call save_current_status in background
		#
		(
			#
			# Declare local copies of arrays in a subshell
			#
			declare -A diskop_copy
			declare -A arguments_copy

			for k in "${!diskop[@]}"; do
				diskop_copy["$k"]="${diskop[$k]}"
			done

			for k in "${!arguments[@]}"; do
				arguments_copy["$k"]="${arguments[$k]}"
			done

			#
			# Reassign to names used by save_current_status
			#
			diskop=()
			arguments=()
			for k in "${!diskop_copy[@]}"; do diskop["$k"]="${diskop_copy[$k]}"; done
			for k in "${!arguments_copy[@]}"; do arguments["$k"]="${arguments_copy[$k]}"; done

			#
			# Call in background safely
			#
			save_current_status
		) &

		#
		# detect pauses
		#
		for prog in hdparm smartctl; do
			prog_elapsed=$(maxExecTime "$prog" "$disk_name" "30")
			paused_by["$prog"]=$([ "$prog_elapsed" -gt 15 ] && echo "Pause ($prog run time: ${prog_elapsed}s)" || echo "n")
		done

		isSync=$(ps -e -o pid,command | grep -Po "\d+ [s]ync$|\d+ [s]6-sync$" | wc -l)
		paused_by["sync"]=$([ "$isSync" -gt 0 ] && echo "Pause (sync command issued)" || echo "n")
		paused_by["file"]=$([ -f "$pause" ] && echo "Pause requested" || echo "n")
		paused_by["queue"]=$([ -f "$queued_file" ] && echo "Pause requested by queue manager" || echo "n")

		#
		# resolve pause intent
		#
		do_pause=n
		for issuer in "${!paused_by[@]}"; do
			if [ "${paused_by[$issuer]}" != "n" ]; then
				do_pause=y
				[ "${is_paused_by[$issuer]}" != "y" ] && {
					preclear_log "${paused_by[$issuer]}"
					is_paused_by[$issuer]=y
				}
			else
				is_paused_by[$issuer]=n
			fi
		done

		#
		# pause/resume dd (edge-triggered)
		#
		if [ "$do_pause" == "y" ] && [ "$is_paused" == "n" ]; then
			kill -TSTP $dd_pid
			is_paused=y
			save_current_status 1
			time_elapsed $write_type && time_elapsed cycle && time_elapsed main
			preclear_log "Paused"
		elif [ "$do_pause" == "n" ] && [ "$is_paused" == "y" ]; then
			kill -CONT $dd_pid
			is_paused=n
			time_elapsed $write_type paused && time_elapsed cycle paused && time_elapsed main paused
			preclear_log "Resumed"
		fi

		#
		# Catch up the last progress if we resumed.
		#
		local decile=$(( $percent_written / 25 ))
		if [ "$last_progress" -eq -1 ]; then
			let last_progress=decile
		fi
		if [ $decile -gt $last_progress ]; then
			preclear_log "${write_type_s}: progress - ${percent_written}% $write_type_v @ $current_speed MB/s"
			last_progress=$decile
		fi

		#
		# Display refresh in the background
		#
		display_refresh display_pid "$display_content" "$display_status"

		#
		# Detect hang safely
		#
		if [[ "$bytes_dd_current" =~ ^[0-9]+$ && "$dd_last_bytes" =~ ^[0-9]+$ ]]; then
			if [ "$bytes_dd_current" -eq "$dd_last_bytes" ] && [ "$is_paused" != "y" ]; then
				let dd_hang=dd_hang+1
			else
				dd_last_bytes=$bytes_dd_current
				dd_hang=0
			fi
		else
			dd_last_bytes=$bytes_dd_current
			dd_hang=0
		fi

		#
		# Detect errors
		#
		if grep -q '^DD_ERROR:' "$dd_output"; then
			preclear_log "${write_type_s}: write failure detected on $disk_name!"
			dd_error_detected=1
		elif dmesg | tail -n 20 | grep -i "error.*$disk"; then
			preclear_log "${write_type_s}: kernel reported disk error on $disk_name!"
			kernel_error_detected=1
		fi

		#
		# Exit conditions
		#
		if [ "$dd_hang" -gt $DD_HANG_LIMIT ]; then
			exit_code=2
			break
		elif [ "$dd_error_detected" -eq 1 ]; then
			exit_code=3
			break
		elif [ "$kernel_error_detected" -eq 1 ]; then
			exit_code=4
			break
		fi

		timelapse=$(timer)

		#
		# Send mid notification
		#
		#
		# Catch up the last progress if we resumed.
		#
		if [ "$notify_channel" -gt 0 ] && [ "$next_notify" -eq -1 ]; then
			let next_notify=decile
		fi
		local decile=$(( $percent_written / 25 ))
		if [ "$notify_channel" -gt 0 ] && [ "$notify_freq" -eq 4 ] && [ "$decile" -gt "$next_notify" ] && [ "$percent_written" -ne 100 ]; then
			disktemp="$(get_disk_temp $disk "$smart_type")"
			report_out="${write_type_s} in progress on $disk_serial ($disk_name): ${percent_written}% complete.\\n"
			report_out+="Wrote $(format_number ${bytes_written}) of ${tb_formatted} @ ${current_speed} MB/s\\n"
			report_out+="Disk temperature: ${disktemp}\\n"
			report_out+="${write_type_s} Elapsed Time: $(time_elapsed $write_type display)\\n"
			report_out+="Cycle's Elapsed Time: $(time_elapsed cycle display)\\n"
			report_out+="Total Elapsed time: $(time_elapsed main display)"
			send_notify "${write_type_s} in progress on $disk_serial ($disk_name): ${percent_written}% @ ${current_speed} MB/s. Temp: ${disktemp}. Cycle ${cycle} of ${cycles}." "${report_out}"
			((next_notify+=1))
		fi

		sleep 1
	done

	if [ $exit_code -ne 0 ] && kill -0 $dd_pid &>/dev/null; then
		kill -9 $dd_pid
	fi

	wait $dd_pid
	dd_exit_code=$?

	bytes_dd=$(cat $dd_output | cut -d '|' -f 1 | trim)
	if [ ! -z "${bytes_dd##*[!0-9]*}" ]; then
		bytes_written=$(( $bytes_dd + $resume_seek ))
	fi

	#
	# Final dd exit check
	#
	[ "$dd_exit_code" -ne 0 ] && exit_code=1

	#
	# Send final notification
	#
	if [ "$notify_channel" -gt 0 ] && [ "$notify_freq" -ge 3 ] ; then
		report_out="${write_type_s} finished on $disk_serial ($disk_name).\\n"
		report_out+="Wrote $(format_number ${bytes_written}) of ${tb_formatted} @ ${average_speed} MB/s\\n"
		report_out+="Disk temperature: $(get_disk_temp $disk "$smart_type").\\n"
		report_out+="${write_type_s} Elapsed Time: $(time_elapsed $write_type display).\\n"
		report_out+="Cycle's Elapsed Time: $(time_elapsed cycle display).\\n"
		report_out+="Total Elapsed time: $(time_elapsed main display)."
		send_notify "${write_type_s} finished on $disk_serial ($disk_name). Cycle ${cycle} of ${cycles}." "$report_out"
	fi

	#
	# update elapsed time
	#
	time_elapsed $write_type && time_elapsed cycle && time_elapsed main
	current_elapsed=$(time_elapsed $write_type display)
	eval "$output='$current_elapsed @ $average_speed MB/s';$output_speed='$average_speed MB/s'"

	#
	# Set the operation exit code
	#
	all_files[op_exit]=$exit_code

	return $exit_code
}

read_the_disk() {
	#
	# local declarations
	#
	local average_speed bytes_dd current_speed current_elapsed count disktemp dd_cmd resume_skip report_out status tb_formatted
	local skip_b1 skip_b2 skip_b3 skip_p1 skip_p2 skip_p3 skip_p4 skip_p5 time_current read_type_s read_type_t read_type_v total_bytes
	local blkpid=${all_files[blkpid]}
	local current_speed=0
	local average_speed=0
	local bytes_read=0
	local bytes_dd_current=0
	local cycle=$cycle
	local cycles=$cycles
	local display_pid=0
	local dd_exit=${all_files[dd_exit]}
	local dd_flags_verify="iflag=nocache,count_bytes,skip_bytes"
	local dd_flags_read="conv=noerror iflag=nocache,count_bytes,skip_bytes"
	local dd_hang=0
	local dd_last_bytes=0
	local dd_pid
	local dd_output=${all_files[dd_out]}
	local dd_seek=""
	local disk=${disk_properties[device]}
	local disk_name=${disk_properties[name]}
	local disk_blocks=${disk_properties[blocks_512]}
	local disk_serial=${disk_properties[serial]}
	local last_progress=-1
	local next_notify=-1
	declare -A is_paused_by
	declare -A paused_by
	local pause=${all_files[pause]}
	local is_paused=n
	local do_pause=n

	local percent_read=0
	local queued_file=${all_files[queued]}
	local read_stress=$read_stress
	local short_test=$short_test
	local skip_initial=0
	local stat_file=${all_files[stat]}
	local verify_errors=${all_files[verify_errors]}
	local read_bs=2097152

	local verify=$1
	local read_type=$2
	local initial_bytes=$3
	local initial_timer=$4
	local output=$5
	local output_speed=$6

	DD_HANG_LIMIT=480
	local exit_code=0

	#
	# start time
	#
	resume_timer=${!initial_timer}
	resume_timer=${resume_timer:-0}
	time_elapsed $read_type set $resume_timer

	#
	# bytes to read
	#
	if [ "$short_test" == "y" ]; then
		total_bytes=$(( ($read_bs * 2048 * 2) + 1 ))
	else
		total_bytes=${disk_properties[size]}
	fi

	#
	# skip input if restored
	#
	resume_skip=${!initial_bytes}
	resume_skip=${resume_skip:-0}
	if [ "$resume_skip" -eq 0 ]; then resume_skip=$read_bs; fi
	if [ "$resume_skip" -gt "$read_bs" ]; then
		resume_skip=$((resume_skip - read_bs))
		preclear_log "Continuing disk read from byte $resume_skip"
		skip_initial=1
	fi

	dd_skip="skip=$resume_skip count=$(( total_bytes - resume_skip ))"

	#
	# read type labels
	#
	case "$read_type" in
		preread)
			read_type_t="Pre-read in progress:"
			read_type_s="Pre-Read"
			read_type_v="read"
			;;
		postread)
			read_type_t="Post-Read in progress:"
			read_type_s="Post-Read"
			read_type_v="verified"
			;;
		*)
			read_type_t="Verifying if disk is zeroed:"
			read_type_s="Verify Zeroing"
			read_type_v="verified"
			read_stress=n
			;;
	esac

	echo -n "${disk_name}|NN|Starting ${read_type_s}...|${script_pid}" > $stat_file
	tb_formatted=$(format_number $total_bytes)

	#
	# initial notification
	#
	if [ "$notify_channel" -gt 0 ] && [ "$notify_freq" -ge 3 ]; then
		report_out="$read_type_s started on $disk_serial ($disk_name).\\nDisk temperature: $(get_disk_temp $disk "$smart_type")\\n"
		send_notify "$read_type_s started on $disk_serial ($disk_name). Cycle $cycle of ${cycles}." "$report_out" &
	fi

	#
	# prepare dd command
	#
	if [ "$verify" == "verify" ]; then
		if [ $skip_initial -eq 0 ]; then
			preclear_log "${read_type_s}: verifying beginning of disk."
			dd_cmd="$PRECLEAR_PRIORITY_CMD dd if=$disk of=/dev/null bs=1 count=$((read_bs - 512)) skip=512 $dd_flags_verify"
			$dd_cmd 2> >(dd_parse_status $dd_output) & dd_pid=$!
			wait $dd_pid
			[ $? -ne 0 ] && { preclear_log "${read_type_s}: dd command failed -> $(cat ${dd_output}_complete)"; exit_code=1; }
		fi

		if [ $exit_code -eq 0 ]; then
			time_elapsed $read_type && time_elapsed cycle && time_elapsed main
			preclear_log "${read_type_s}: verifying the rest of the disk."
			dd_cmd="$PRECLEAR_PRIORITY_CMD dd if=$disk of=/dev/null bs=$read_bs $dd_skip $dd_flags_verify"
			$dd_cmd 2> >(dd_parse_status $dd_output) & dd_pid=$!
		fi
	else
		#
		# non-verify read
		#
		[ "$skip_initial" -eq 0 ] && { dd_skip="skip=0 count=$total_bytes"; resume_skip=0; }
		dd_cmd="$PRECLEAR_PRIORITY_CMD dd if=$disk of=/dev/null bs=$read_bs $dd_skip $dd_flags_read"
		$dd_cmd 2> >(dd_parse_status $dd_output) & dd_pid=$!
	fi

	#
	# validate dd pid
	#
	if [ -z "$dd_pid" ] || ! ps -p $dd_pid &>/dev/null; then
		preclear_log "${read_type_s}: dd command failed -> $(cat ${dd_output}_complete)"
		exit_code=1
	fi

	#
	# Start the read loop
	#
	if [ $exit_code -eq 0 ]; then
		all_files[dd_pid]=$dd_pid
		timelapse=$(( $(timer) - 20 ))
		current_speed_time=$(timer)
		current_speed_bytes=0
		current_dd_time=0

		sleep 1

		#
		# optional stress reads
		#
		if [ "$read_stress" == "y" ]; then
			dd_stress_pids=()
			for i in 1 2 3 4 5; do
				skip_b=$(( $(head -c4 /dev/urandom | od -An -tu4) % disk_blocks ))
				[ $i -eq 4 ] && skip_b=$((disk_blocks-1))  # last block
				$PRECLEAR_PRIORITY_CMD dd if=$disk of=/dev/null count=1 bs=512 skip=$skip_b iflag=direct >/dev/null 2>&1 &
				stress_pid=$!
				dd_stress_pids+=("$stress_pid")
			done
			all_files[dd_stress]="${dd_stress_pids[*]}"
		fi

		#
		# monitor loop
		#
		while kill -0 $dd_pid >/dev/null 2>&1; do
			#
			# elapsed time
			#
			if [ "$is_paused" == "y" ]; then
				time_elapsed $read_type paused && time_elapsed cycle paused && time_elapsed main paused
			else
				time_elapsed $read_type && time_elapsed cycle && time_elapsed main
			fi

			dd_status=$(get_dd_output $dd_pid $dd_output)

			#
			# parse dd output safely
			#
			bytes_dd=$(echo -n "$dd_status" | cut -d '|' -f 1 | trim)
			current_dd_time=$(echo -n "$dd_status" | cut -d '|' -f 2 | trim)
			bytes_dd_current=${bytes_dd:-0}
			bytes_read=$(( bytes_dd_current + resume_skip ))
			percent_read=$(( bytes_read * 100 / total_bytes ))
			[ "$percent_read" -gt 100 ] && percent_read=100

			dd_status=$(get_dd_output $dd_pid $dd_output)

			#
			# Calculate the current status
			#
			bytes_dd=$(echo -n "$dd_status" | cut -d '|' -f 1 | trim)
			current_dd_time=$(echo -n "$dd_status" | cut -d '|' -f 2 | trim)

			#
			# Update elapsed time
			#
			current_elapsed=$(time_elapsed $read_type export)

			#
			# Ensure bytes_read is a number
			#
			if [ ! -z "${bytes_dd##*[!0-9]*}" ]; then
				bytes_read=$(($bytes_dd + $resume_skip))
				bytes_dd_current=$bytes_dd
				let percent_read=($bytes_read*100/$total_bytes)
			fi

			#
			# Average speed
			#
			if [ $(( $current_elapsed )) -gt 0 ]; then
				average_speed=$(( $bytes_read / $current_elapsed / 1000000 ))
			fi

			#
			# Current speed
			#
			if [ -z "$current_speed" ]; then
				current_speed=$average_speed
			fi

			if [ ! -z "${current_dd_time##*[!0-9.]*}" ]; then
				local bytes_diff=$(awk "BEGIN {printf \"%.2f\",${bytes_dd_current} - ${current_speed_bytes}}")
				local time_diff=$(awk "BEGIN {printf \"%.2f\",${current_dd_time} - ${current_speed_time}}")
				if [ "${time_diff//.}" -ne 0 ]; then		
					current_speed=$(awk "BEGIN {printf \"%d\",(${bytes_diff}/${time_diff}/1000000)}")
					current_speed_bytes=$bytes_dd_current
					current_speed_time=$current_dd_time
					if [ "$current_speed" -le 0 ]; then
						current_speed=$average_speed
					fi
				fi
			fi

			#
			# Update diskop with current status
			#
			diskop+=([current_op]="$read_type" [current_pos]="$bytes_read" [current_timer]="$current_elapsed")

			#
			# Snapshot and call save_current_status in background
			#
			(
				#
				# Declare local copies of arrays in a subshell
				#
				declare -A diskop_copy
				declare -A arguments_copy

				for k in "${!diskop[@]}"; do
					diskop_copy["$k"]="${diskop[$k]}"
				done

				for k in "${!arguments[@]}"; do
					arguments_copy["$k"]="${arguments[$k]}"
				done

				#
				# Reassign to names used by save_current_status
				#
				diskop=()
				arguments=()
				for k in "${!diskop_copy[@]}"; do diskop["$k"]="${diskop_copy[$k]}"; done
				for k in "${!arguments_copy[@]}"; do arguments["$k"]="${arguments_copy[$k]}"; done

				#
				# Call in background safely
				#
				save_current_status
			) &

			status="Time elapsed: $(time_elapsed $read_type display) | Current speed: $current_speed MB/s | Average speed: $average_speed MB/s"

			#
			# save status
			#
			diskop+=([current_op]="$read_type" [current_pos]="$bytes_read" [current_timer]=$current_elapsed)
			save_current_status

			local decile=$(( percent_read / 25 ))
			[ "$last_progress" -eq -1 ] && last_progress=$decile
			if [ $decile -gt $last_progress ]; then
				preclear_log "${read_type_s}: progress - ${percent_read}% $read_type_v @ $current_speed MB/s"
				last_progress=$decile
			fi

			#
			# detect pauses
			#
			for prog in hdparm smartctl; do
				prog_elapsed=$(maxExecTime "$prog" "$disk_name" "30")
				paused_by["$prog"]=$([ "$prog_elapsed" -gt 15 ] && echo "Pause ($prog run time: ${prog_elapsed}s)" || echo "n")
			done
			isSync=$(ps -e -o pid,command | grep -Po "\d+ [s]ync$|\d+ [s]6-sync$" | wc -l)
			paused_by["sync"]=$([ "$isSync" -gt 0 ] && echo "Pause (sync command issued)" || echo "n")
			paused_by["file"]=$([ -f "$pause" ] && echo "Pause requested" || echo "n")
			paused_by["queue"]=$([ -f "$queued_file" ] && echo "Pause requested by queue manager" || echo "n")

			#
			# update pause state
			#
			do_pause=n
			for issuer in "${!paused_by[@]}"; do
				if [ "${paused_by[$issuer]}" != "n" ]; then
					do_pause=y
					[ "${is_paused_by[$issuer]}" != "y" ] && { preclear_log "${paused_by[$issuer]}"; is_paused_by[$issuer]=y; }
				else
					is_paused_by[$issuer]=n
				fi
			done

			#
			# pause/resume dd
			#
			if [ "$do_pause" == "y" ] && [ "$is_paused" == "n" ]; then
				kill -TSTP $dd_pid
				is_paused=y
				save_current_status 1
				time_elapsed $read_type && time_elapsed cycle && time_elapsed main
				preclear_log "Paused"
			elif [ "$do_pause" == "n" ] && [ "$is_paused" == "y" ]; then
				kill -CONT $dd_pid
				is_paused=n
				time_elapsed $read_type paused && time_elapsed cycle paused && time_elapsed main paused
				preclear_log "Resumed"
			fi

			#
			# status update and display
			#
			local stat_content display_content display_status
			status="Time elapsed: $(time_elapsed $read_type display) | Current speed: $current_speed MB/s | Average speed: $average_speed MB/s"
			if [ "$is_paused" == "y" ]; then
				if [ -f "$queue_file" ]; then
					stat_content="${read_type_s}${cycle_disp}: QUEUED"
					display_content="${read_type_t} (${percent_read}% Done) ${bold}QUEUED${norm}"
					display_status="** QUEUED"
				else
					stat_content="${read_type_s}${cycle_disp}: PAUSED"
					display_content="${read_type_t} (${percent_read}% Done) ${bold}PAUSED${norm}"
					display_status="** PAUSED"
				fi
			else
				stat_content="${read_type_s}${cycle_disp}: ${percent_read}% @ ${current_speed} MB/s ($(time_elapsed $read_type display))"
				display_content="${read_type_t} (${percent_read}% Done)"
				display_status="** ${status}"
			fi
			echo -n "$disk_name|NN|${stat_content}|$$" > $stat_file

			#
			# Display refresh
			#
			display_refresh display_pid "$display_content" "$display_status"

			#
			# detect hung dd
			#
			dd_last_bytes=${dd_last_bytes:-0}
			if [ "$bytes_dd_current" -eq "$dd_last_bytes" ] && [ "$is_paused" != "y" ]; then
				dd_hang=$(( dd_hang + 1 ))
			else
				dd_hang=0
				dd_last_bytes=$bytes_dd_current
			fi

			#
			# kill hung dd
			#
			[ "$dd_hang" -gt "$DD_HANG_LIMIT" ] && { 
				eval "$initial_bytes='$bytes_read';"
				eval "$initial_timer='$(time_elapsed $read_type export)';"
				cat "${dd_output}_complete" | while read l; do preclear_log "${read_type_s}: dd output: ${l}"; done
				kill -9 $dd_pid
				exit_code=2
				break
			}

			#
			# Send mid notification
			#
			#
			# Catch up the last progress if we resumed.
			#
			local decile=$(( percent_read / 25 ))
			[ "$notify_channel" -gt 0 ] && [ "$next_notify" -eq -1 ] && next_notify=$decile
			if [ "$notify_channel" -gt 0 ] && [ "$notify_freq" -eq 4 ] && [ "$decile" -gt "$next_notify" ] && [ "$percent_read" -ne 100 ]; then
				disktemp="$(get_disk_temp $disk "$smart_type")"
				report_out="${read_type_s} in progress on $disk_serial ($disk_name): ${percent_read}% complete.\\n"
				report_out+="Read $(format_number ${bytes_read}) of ${tb_formatted} @ ${current_speed} MB/s\\n"
				report_out+="Disk temperature: ${disktemp}\\n"
				report_out+="${read_type_s} Elapsed Time: $(time_elapsed $read_type display).\\n"
				report_out+="Cycle's Elapsed Time: $(time_elapsed cycle display).\\n"
				report_out+="Total Elapsed time: $(time_elapsed main display)."
				send_notify "${read_type_s} in progress on $disk_serial ($disk_name): ${percent_read}% @ ${current_speed} MB/s. Temp: ${disktemp}. Cycle ${cycle} of ${cycles}." "${report_out}" &
				((next_notify+=1))
			fi

			timelapse=$(timer)

			sleep 1
		done

		#
		# final dd exit
		#
		wait $dd_pid
		dd_exit_code=$?
		[ "$dd_exit_code" -ne 0 ] && exit_code=1

		#
		# kill all dd write processes if we encountered an error
		#
		if [ "$exit_code" -ne 0 ]; then
			for stress_pid in ${all_files[dd_stress]}; do
				[ -n "$stress_pid" ] && kill -9 "$stress_pid" 2>/dev/null
			done
			for stress_pid in ${all_files[dd_stress]}; do
				[ -n "$stress_pid" ] && wait "$stress_pid"
			done
		fi

		#
		# wait stress reads
		#
		if [ "$read_stress" == "y" ]; then
			for stress_pid in "$skip_p1" "$skip_p2" "$skip_p3" "$skip_p4" "$skip_p5"; do
				[ -n "$stress_pid" ] && wait "$stress_pid"
			done
		fi
	fi

	#
	# final notification
	#
	if [ "$notify_channel" -gt 0 ] && [ "$notify_freq" -ge 3 ] ; then
		report_out="$read_type_s finished on $disk_serial ($disk_name).\\n"
		report_out+="Read $(format_number $bytes_read) of $tb_formatted @ $average_speed MB/s\\n"
		report_out+="Disk temperature: $(get_disk_temp $disk "$smart_type").\\n"
		report_out+="$read_type_s Elapsed Time: $(time_elapsed $read_type display).\\n"
		report_out+="Cycle's Elapsed Time: $(time_elapsed cycle display).\\n"
		report_out+="Total Elapsed time: $(time_elapsed main display)."
		send_notify "$read_type_s finished on $disk_serial ($disk_name). Cycle ${cycle} of ${cycles}." "$report_out" &
	fi

	#
	# update elapsed time
	#
	time_elapsed $read_type && time_elapsed cycle && time_elapsed main
	current_elapsed=$(time_elapsed $read_type display)
	eval "$output='$current_elapsed @ $average_speed MB/s';$output_speed='$average_speed MB/s'"

	#
	# Set the operation exit code
	#
	all_files[op_exit]=$exit_code

	return $exit_code
}

draw_canvas(){
	local start=$1 height=$2 width=$3 brick="${canvas[brick]}" c
	let iniline=($height + $start)
	for line in $(seq $start $iniline ); do
		c+=$(tput cup $line 0 && echo -n $brick)
		c+=$(tput cup $line $width && echo -n $brick)
	done
	for col in $(seq $width); do
		c+=$(tput cup $start $col && echo -n $brick)
		c+=$(tput cup $iniline $col && echo -n $brick)
		c+=$(tput cup $(( $iniline - 2 )) $col && echo -n $brick)
	done
	echo -n $c
}

#
# Helper: safely refresh display in background
#
display_refresh() {
	local display_pid_var="$1"   # Name of variable holding last display PID
	shift
	local display_content="$1"   # Current display content
	shift
	local display_status_msg="$1" # Current status message
	shift

	#
	# Check if previous display process is still running
	#
	if [ -n "${!display_pid_var}" ] && [ -e "/proc/${!display_pid_var}/exe" ]; then
		return 0
	fi

	(
		#
		# Snapshot arrays used by display_status
		#
		local -A canvas_copy all_files_copy
		for k in "${!canvas[@]}"; do canvas_copy["$k"]="${canvas[$k]}"; done
		for k in "${!all_files[@]}"; do all_files_copy["$k"]="${all_files[$k]}"; done

		#
		# Assign snapshots back to expected names
		#
		canvas=()
		for k in "${!canvas_copy[@]}"; do canvas["$k"]="${canvas_copy[$k]}"; done

		all_files=()
		for k in "${!all_files_copy[@]}"; do all_files["$k"]="${all_files_copy[$k]}"; done

		#
		# Call display_status with snapshot arguments
		#
		display_status "$display_content" "$display_status_msg"
	) &

	#
	# Save the PID in the caller's variable
	#
	eval "$display_pid_var=$!"
}

draw_canvas(){
	local start=$1 height=$2 width=$3 brick="${canvas[brick]}" c
	let iniline=($height + $start)
	for line in $(seq $start $iniline ); do
		c+=$(tput cup $line 0 && echo -n $brick)
		c+=$(tput cup $line $width && echo -n $brick)
	done
	for col in $(seq $width); do
		c+=$(tput cup $start $col && echo -n $brick)
		c+=$(tput cup $iniline $col && echo -n $brick)
		c+=$(tput cup $(( $iniline - 2 )) $col && echo -n $brick)
	done
	echo -n $c
}

display_status() {
	local max=$max_steps
	local cycle=$cycle
	local cycles=$cycles
	local current="$1"
	local status="$2"
	local skip_formatting="$3"

	local width="${canvas[width]}"
	local height="${canvas[height]}"
	local smart_output="${all_files[smart_out]}"
	local wpos=4
	local hpos=1
	local step=1
	local out="${all_files[dir]}/display_out"
	local l
	local line stat clean_stat stat_num
	local output=""

	#
	# Helper function to format a line with optional stat
	#
	draw_line() {
		local line="$1"
		local stat="$2"
		local step_num="$3"

		#
		# Split stat if present
		#
		if [[ "$line" == *"|"* && "$skip_formatting" != "y" ]]; then
			stat="${line#*|}"
			line="${line%%|*}"
		fi

		#
		# Add step info
		#
		if [[ -n "$max" ]]; then
			line="Step $step_num of $max - $line"
		fi

		#
		# Clean and format stat
		#
		if [[ -n "$stat" ]]; then
			clean_stat="${stat//\*\*\([^\*]*\)\*\*/\1}"
			clean_stat="${clean_stat//\#\#\([^\#]*\)\#\#/\1}"
			if [[ "$skip_formatting" != "y" ]]; then
				stat="${stat//\*\*\([^\*]*\)\*\*/${bold}\1${norm}}"
				stat="${stat//\#\#\([^\#]*\)\#\#/${ul}\1${noul}}"
			fi
			stat_num=${#clean_stat}
		else
			stat_num=0
		fi

		#
		# Append formatted line to output
		#
		output+=$(tput cup "$l" "$wpos")
		output+="$line"
		if [[ -n "$stat" ]]; then
			output+=$(tput cup "$l" "$((width - stat_num - wpos))")
			output+="$stat"
		fi
		output+=$'\n'
		((l++))
	}

	#
	# Reset terminal unless skipped
	#
	[[ "$skip_formatting" != "y" ]] && output+=$(tput reset)

	#
	# Draw main canvas
	#
	if [[ -z "${canvas[info]}" ]]; then
		append canvas "info" "$(draw_canvas "$hpos" "$height" "$width")"
	fi
	output+="${canvas[info]}"

	#
	# Draw titles
	#
	eval "local -A title=$(array_content display_title)"
	eval "local -a title_keys=$(array_content display_title_keys)"
	for i in "${!title_keys[@]}"; do
		line="${title[$i]}"
		local line_len="${#line}"
		output+=$(tput cup $((i + 1 + hpos)) $((width / 2 - line_len / 2)))
		output+="$line"$'\n'
	done

	l=$(( ${#title[@]} + 2 + hpos ))

	#
	# Draw previous steps
	#
	eval "local -A prev=$(array_content display_step)"
	eval "local -a prev_keys=$(array_content display_step_keys)"
	for i in "${!prev_keys[@]}"; do
		line="${prev[$i]}"
		[[ -n "$line" ]] && draw_line "$line" "" "$step" && ((step++))
	done

	#
	# Draw current step if present
	#
	[[ -n "$current" ]] && draw_line "$current" "" "$step"

	#
	# Display status
	#
	[[ -n "$status" ]] && output+=$(tput cup $((height + hpos - 4)) "$wpos")$status$'\n'

	#
	# Display elapsed times
	#
	local elapsed_main=$(time_elapsed main display)
	local elapsed_cycle=$(time_elapsed cycle display)
	local footer="Total elapsed time: $elapsed_main"
	[[ -n "$elapsed_cycle" ]] && footer="Cycle elapsed time: $elapsed_cycle | $footer"
	output+=$(tput cup $((height + hpos - 1)) $((wpos * 2)))$footer$'\n'

	#
	# Display SMART output if present
	#
	if [[ -f "$smart_output" ]]; then
		local init=$((hpos + height + 2))
		if [[ -z "${canvas[smart]}" ]]; then
			append canvas "smart" "$(draw_canvas "$init" "$((height + 1))" "$width")"
		fi
		output+="${canvas[smart]}"
		output+=$(tput cup $((init + 1)) "$wpos")"${ul}S.M.A.R.T. Status (device type: $type)${noul}"$'\n'
		l=$((init + 3))
		mapfile -t smart_lines < "$smart_output"
		for ((i=0; i<${#smart_lines[@]}-1; i++)); do
			output+=$(tput cup "$l" "$wpos")"${smart_lines[i]}"$'\n'
			((l++))
		done
		output+=$(tput cup $((init + height)) "$wpos")"${smart_lines[-1]}"$'\n'
		output+=$(tput cup $((init + height)) $((wpos * 2)))"Report generated on: $(date "+%B %d, %Y at %H:%M:%S")"$'\n\n'
	else
		output+=$(tput cup $((height + hpos)) "$width")
		output+=$(tput cup $((height + hpos + 2)) 0)
	fi

	#
	# Write everything at once and display
	#
	printf "%s" "$output" > "$out"

	cat "$out"
}

ask_preclear(){
	local line
	local wpos=4
	local hpos=0
	local max=""
	local width="${canvas[width]}"
	local height="${canvas[height]}"
	eval "local -A title=$(array_content display_title)"
	eval "local -A disk_info=$(array_content disk_properties)"

	tput reset

	draw_canvas $hpos $height $width

	for (( i = 0; i <= ${#title[@]}; i++ )); do
		line=${title[$i]}
		line_num=$(echo "$line"|tr -d "${bold}"|tr -d "${norm}"|tr -d "${ul}"|tr -d "${noul}"|wc -m)
		tput cup $(($i + 1 + $hpos)) $(( $width/2 - $line_num/2	))
		echo -n "$line"
	done

	l=$((${#title[@]} + 2 + $hpos))

	if [ -n "${disk_info[family]}" ]; then
		tput cup $l $wpos && echo -n "Model Family: 	${disk_info[family]}"
		let "l+=1"
	fi
	if [ -n "${disk_info[model]}" ]; then
		tput cup $l $wpos && echo -n "Device Model:	${disk_info[model]}"
		let "l+=1"
	fi
	if [ -n "${disk_info[serial]}" ]; then
		tput cup $l $wpos && echo -n "Serial Number:	${disk_info[serial]}"
		let "l+=1"
	fi
	if [ -n "${disk_info[size_human]}" ]; then
		tput cup $l $wpos && echo -n "User Capacity:	${disk_info[size_human]}"
		let "l+=1"
	fi
	if [ -n "${disk_info[firmware]}" ]; then
		tput cup $l $wpos && echo -n "Firmware:		${disk_info[firmware]}"
		let "l+=1"
	fi
	if [ -n "${disk_info[device]}" ]; then
		tput cup $l $wpos && echo -n "Disk Device:	${disk_info[device]}"
	fi

	tput cup $(($height - 4)) $wpos && echo -n "Answer ${bold}Yes${norm} to continue:"
	tput cup $(($height - 4)) $(($wpos+24)) && read answer

	tput cup $(( $height - 1)) $wpos; 

	if [[ "$answer" == "Yes" ]]; then
		tput cup $(( $height + 2 )) 0
		return 0
	else
		echo -n "The disk will ${bold}NOT${norm} be precleared."
		tput cup $(( $height + 24 )) 0
		exit 2
	fi
}

save_smart_info() {
	local device=$1
	local type=$2
	local name=$3
	local valid_attributes=" 5 9 183 184 187 190 194 196 197 198 199 "
	local valid_temp=" 190 194 "
	local smart_file="${all_files[smart_prefix]}${name}"
	local found_temp=n
	cat /dev/null > $smart_file

	while read line; do
		attr=$(echo "$line" | cut -d'|' -f1)
		if [[ $valid_attributes =~ [[:space:]]$attr[[:space:]] ]]; then
			if [[ $valid_temp =~ [[:space:]]$attr[[:space:]] ]]; then
				if [[ $found_temp != "y" ]]; then
					echo "$line" >> $smart_file
					found_temp=y
				fi
			else
				echo "$line" >> $smart_file
			fi
		fi
	done < <(timeout -s 9 30 smartctl --attributes $type $device 2>/dev/null | sed -n "/ATTRIBUTE_NAME/,/^$/p" | \
					grep -v "ATTRIBUTE_NAME" | grep -v "^$" | awk '{ print $1 "|" $2 "|" $10}')
}

compare_smart() {
	local initial="${all_files[smart_prefix]}$1"
	local current="${all_files[smart_prefix]}$2"
	local final="${all_files[smart_final]}$4"
	local title=$3
	if [ -e "$final" -a -n "$title" ]; then
		sed -i " 1 s/$/|$title/" $final
	elif [ ! -f "$current" ]; then
		echo "ATTRIBUTE|INITIAL" > $final
		current=$initial
	else
		echo "ATTRIBUTE|INITIAL|$title" > $final
	fi

	while read line; do
		attr=$(echo "$line" | cut -d'|' -f1)
		name=$(echo "$line" | cut -d'|' -f2)
		name="${name}"
		nvalue=$(echo "$line" | cut -d'|' -f3)
		ivalue=$(cat $initial| grep "^${attr}"|cut -d'|' -f3)
		if [ "$(cat $final 2>/dev/null|grep -c "$name")" -gt "0" ]; then
			sed -i "/^$name/ s/$/|${nvalue}/" $final
		else
			echo "${name}|${ivalue}" >> $final
		fi
	done < <(cat $current)
}

output_smart() {
	local device=$1
	local type=$2
	local final="${all_files[smart_final]}$3"
	local output="${all_files[smart_out]}$4"
	local msg
	local nfinal="${final}_$(( $RANDOM * 19318203981230 + 40 ))"
	cp -f "$final" "$nfinal"
	sed -i " 1 s/$/|STATUS/" $nfinal
	local status=$(timeout -s 9 30 smartctl --attributes $type $device 2>/dev/null | sed -n "/ATTRIBUTE_NAME/,/^$/p" | \
					grep -v "ATTRIBUTE_NAME" | grep -v "^$" | awk '{print $1 "-" $2 "|" $9 }')
	while read line; do
		local attr=$(echo "$line" | cut -d'|' -f1)
		local inival=$(echo "$line" | cut -d'|' -f2)
		local lasval=$(echo "$line" | grep -o '[^|]*$')
		let diff=($((`cut -d h -f1 <<< ${lasval}`)) - $((`cut -d h -f1 <<< ${inival}`)))
		if [ "$diff" -gt "0" ]; then
			msg="Up $diff"
		elif [ "$diff" -lt "0" ]; then
			diff=$(echo "$diff" | sed 's/-//g')
			msg="Down $diff"
		else
			msg="-"
		fi
		local stat=$(echo "$status" | grep -Po "${attr}[^\s]*")
		if [[ $stat =~ FAILING_NOW ]]; then
			msg="$msg|->FAILING NOW!<-"
		elif [[ $stat =~ In_the_past ]]; then
			msg="$msg|->Failed in Past<-"
		fi
		sed -i "/^$attr/ s/$/|${msg}/" $nfinal
	done < <(cat $nfinal | tail -n +2)
	cat $nfinal | column -t -s '|' -o '	'> $output
	echo "" >> $output
	rm $nfinal
}

get_disk_temp() {
	local device=$1
	local type=$2
	local valid_temp=" 190 194 "
	local temp=0
	if [ "$disable_smart" == "y" ]; then
		echo -n "n/a"
		return 0
	fi

	while read line; do
		attr=$(echo -n "$line" | cut -d'|' -f1)
		if [[ $valid_temp =~ [[:space:]]$attr[[:space:]] ]]; then
			echo -n "$(echo -n "$line" | cut -d'|' -f3) C"
			return 0
		fi
	done < <(timeout -s 9 30 smartctl --attributes $type $device 2>/dev/null | sed -n "/ATTRIBUTE_NAME/,/^$/p" | \
					grep -v "ATTRIBUTE_NAME" | grep -v "^$" | awk '{ print $1 "|" $2 "|" $10}')
	echo -n "n/a"
}

log_smart()
{
	local disk=$1
	local smart=$2
	local id=$RANDOM
	[ "$disable_smart" != "y" ] && compare_smart	"cycle_initial_start" "" "" "_${id}"
	[ "$disable_smart" != "y" ] && save_smart_info	$disk "$smart" "${id}"
	[ "$disable_smart" != "y" ] && compare_smart	"cycle_initial_start" "${id}" "NOW" "_${id}"
	[ "$disable_smart" != "y" ] && output_smart		$disk "$smart" "_${id}" "_${id}"
	if [ -f "${all_files[smart_out]}_${id}" ]; then
		preclear_log "S.M.A.R.T.: $3"
		preclear_log "S.M.A.R.T.:"
		while read l; do 
			preclear_log "S.M.A.R.T.: ${l}"; 
		done < <(cat "${all_files[smart_out]}_${id}")
	fi
}

do_exit() {
	trap '' ERR EXIT 1 2 3 9 15

	#
	# Wait for any wait-file to disappear
	#
	while [ -f "${all_files[wait]}" ]; do 
		sleep 0.1
	done

	#
	# Kill main dd if running
	#
	dd_pid=${all_files[dd_pid]}
	[ -n "$dd_pid" ] && kill -9 "$dd_pid" 2>/dev/null

	#
	# build the array of stress PIDs
	#
	dd_stress_pids=()
	for stress_pid in ${all_files[dd_stress]}; do
		[ -n "$stress_pid" ] && dd_stress_pids+=("$stress_pid")
	done

	#
	# Kill stress reads
	#
	for stress_pid in "${dd_stress_pids[@]}"; do
		[ -n "$stress_pid" ] && kill -9 "$stress_pid" 2>/dev/null
	done
	for stress_pid in "${dd_stress_pids[@]}"; do
		[ -n "$stress_pid" ] && kill -9 "$stress_pid" 2>/dev/null
	done

	case "$1" in
		0)
			preclear_log "SIG${2} received, exiting..."
			rm -f "${all_files[pid]}" "${all_files[pause]}" "${all_files[queued]}"
			save_current_status 1
			exit 0
			;;
		1)
			preclear_log 'error encountered, exiting...'
			echo "${disk_properties[name]}|NY|Error encountered, please check the report|$$" > ${all_files[stat]}
			rm -f "${all_files[resume_file]}" "${all_files[resume_temp]}"

			sleep 2

			rm -rf "${all_files[dir]}"
			exit 1
			;;
		*)
			rm -f "${all_files[resume_file]}" "${all_files[resume_temp]}"
			rm -rf "${all_files[dir]}"
			exit 0
			;;
	esac
}

trap_with_arg() {
		func="$1" ; shift
		for sig ; do
				trap "$func $sig" "$sig"
		done
}

is_current_op() {
	if [ -n "$current_op" ] && [ "$current_op" == "$1" ]; then
		current_op=""
		return 0
	elif [ -z "$current_op" ]; then
		return 0
	else
		return 1
	fi
}

######################################################
##													##
##					INITIAL SETUP					##
##													##
######################################################
#
# PID
#
script_pid=$BASHPID

#
# Serial
#
cmd_disk=""
for arg in "$@"; do
	if [ -b "$arg" ]; then
		cmd_disk=$arg
		attrs=$(udevadm info --query=property --name="${arg}")
		serial_number=$(echo -e "$attrs" | awk -F'=' '/ID_SCSI_SERIAL/{print $2}')
		if [ -z "$serial_number" ]; then
			serial_number=$(echo -e "$attrs" | awk -F'=' '/ID_SERIAL_SHORT/{print $2}')
		fi
		break
	else
		serial_number=""
	fi
done
#
# Log prefix
#
if [ -n "$serial_number" ]; then
	syslog_prefix="preclear_disk_${serial_number}"
	log_prefix="preclear_disk_${serial_number}_${script_pid}:"
elif [[ -n "$cmd_disk" ]]; then
	syslog_prefix="preclear_disk_${cmd_disk}"
	log_prefix="preclear_disk_${script_pid}:"
else
	syslog_prefix="preclear_disk"
	log_prefix="preclear_disk_${script_pid}:"
fi

#
# Redirect errors to log
#
exec 2> >(while read err; do preclear_log "${err}"; echo "${err}"; done; >&2)

#
# Let's make sure some features are supported by BASH
#
BV=$(echo $BASH_VERSION|tr '.' "\n"|grep -Po "^\d+"|xargs printf "%.2d\n"|tr -d '\040\011\012\015')
if [ "$BV" -lt "040253" ]; then
	echo -e "Sorry, your BASH version isn't supported.\nThe minimum required version is 4.2.53.\nPlease update."
	preclear_log "Sorry, your BASH version isn't supported.\nThe minimum required version is 4.2.53.\nPlease update."
	exit 2
fi

#
# Let's verify all dependencies
#
for dep in cat awk basename blockdev comm date dd find fold getopt grep kill openssl printf readlink seq sort sum tac tmux todos tput udevadm xargs; do
	if ! type $dep >/dev/null 2>&1 ; then
		echo -e "The following dependency isn't met: [$dep]. Please install it and try again."
		preclear_log "The following dependency isn't met: [$dep]. Please install it and try again."
		exit 1
	fi
done

######################################################
##													##
##					PARSE OPTIONS					##
##													##
######################################################
#
#Defaut values
#
all_timer_diff=0
cycle_timer_diff=0
main_elapsed_time=0
cycle_elapsed_time=0
command=$(echo "$0 $@")
read_stress=y
skip_preread=y
skip_postread=y
cycles=1
append display_step ""
erase_disk=n
erase_preclear=n
initial_bytes=0
verify_preclear_only=n
refresh_period=30
append canvas 'width'	'100'
append canvas 'height' '14'
append canvas 'brick'	'#'
smart_type=auto
notify_channel=0
notify_freq=0
opts_long="frequency:,notify:,preread,postread,read-size:,write-size:,read-blocks:,test,no-stress,list,"
opts_long+="cycles:,signature,verify,no-prompt,version,preclear-only,clear-signature,format-html,erase,erase-clear,load-file:,unassigned"

OPTS=$(getopt -o f:n:sSr:w:b:tdlc:ujvomera:U \
			--long $opts_long -n "$(basename $0)" -- "$@")

if [ "$?" -ne "0" ]; then
	exit 1
fi

eval set -- "$OPTS"
#
# (set -o >/dev/null; set >/tmp/.init)
#
while true ; do
	case "$1" in
		-f|--frequency)			is_numeric notify_freq		"$1" "$2"; shift 2;;
		-n|--notify)			is_numeric notify_channel	"$1" "$2"; shift 2;;
		-s|--preread)			skip_preread=n;				shift 1;;
		-S|--postread)			skip_postread=n;			shift 1;;
		-r|--read-size)			is_numeric read_size		"$1" "$2"; shift 2;;
		-w|--write-size)		is_numeric write_size		"$1" "$2"; shift 2;;
		-b|--read-blocks)		is_numeric read_blocks		"$1" "$2"; shift 2;;
		-t|--test)				short_test=y;				shift 1;;
		-d|--no-stress)			read_stress=n;				shift 1;;
		-l|--list)				list_device_names;			exit 0;;
		-c|--cycles)			is_numeric cycles			"$1" "$2"; shift 2;;
		-u|--signature)			verify_disk_preclear=y;		shift 1;;
		-p|--verify)			verify_disk_preclear=y;		verify_zeroed=y; shift 1;;
		-j|--no-prompt)			no_prompt=y;				shift 1;;
		-v|--version)			echo "$0 version: $version"; exit 0;;
		-o|--preclear-only)		write_disk_preclear=y;		shift 1;;
		-m|--format-html)		format_html=y;				shift 1;;
		-e|--erase)				erase_disk=y;				shift 1;;
		-r|--erase-clear)		erase_preclear=y;			shift 1;;
		-a|--load-file)			load_file="$2";				shift 2;;
		-U|--unassigned)		list_unassigned_disks;		exit 0;;

		--) shift ; break ;;
		* ) echo "Internal error!" ; exit 1 ;;
	esac
done

if [ ! -b "$1" ]; then
	echo "Disk not set, please verify the command arguments."
	preclear_log "Disk not set, please verify the command arguments."
	exit 1
fi

theDisk=$(echo $1 | trim)

preclear_log "Preclear Disk Version: ${version}"

#
# Restoring session or exit if it's not possible
#
if [ -f "$load_file" ] && $(bash -n "$load_file"); then
	preclear_log "Restoring previous instance of preclear"
	. "$load_file"
	if [ "$all_timer_diff" -gt 0 ]; then
		main_elapsed_time=$all_timer_diff
		cycle_elapsed_time=$cycle_timer_diff
	fi
	if [ "$main_elapsed_time" -eq 0 ]; then
		preclear_log "Resume failed, please start a new instance of preclear"
		echo -n "$(basename $theDisk)|NN|Resume failed!|${script_pid}" > "/tmp/preclear/preclear_stat_$(basename $theDisk)"
		exit 1
	fi
fi

append arguments 'notify_freq'			"$notify_freq"
append arguments 'notify_channel'		"$notify_channel"
append arguments 'skip_preread'			"$skip_preread"
append arguments 'skip_postread'		"$skip_postread"
append arguments 'read_size'			"$read_size"
append arguments 'write_size'			"$write_size"
append arguments 'read_blocks'			"$read_blocks"
append arguments 'short_test'			"$short_test"
append arguments 'read_stress'			"$read_stress"
append arguments 'cycles'				"$cycles"
append arguments 'verify_disk_preclear'	"$verify_disk_preclear"
append arguments 'verify_zeroed'		"$verify_zeroed"
append arguments 'no_prompt'			"$no_prompt"
append arguments 'write_disk_preclear'	"$write_disk_preclear"
append arguments 'format_html'			"$format_html"
append arguments 'erase_disk'			"$erase_disk"
append arguments 'erase_preclear'		"$erase_preclear"


######################################################
##													##
##			SET DEFAULT PROGRAM VARIABLES			##
##													##
######################################################
#
# Operation variables
#
append diskop 'current_op' ""
append diskop 'current_pos' ""
append diskop 'current_timer' ""

#
# Disk properties
#
append disk_properties 'device'			"$theDisk"
append disk_properties 'size'			$(blockdev --getsize64 ${disk_properties[device]} 2>/dev/null)
append disk_properties 'block_sz'		$(blockdev --getpbsz ${disk_properties[device]} 2>/dev/null)
append disk_properties 'blocks'			$(( ${disk_properties[size]} / ${disk_properties[block_sz]} ))
append disk_properties 'blocks_512'		$(blockdev --getsz ${disk_properties[device]} 2>/dev/null)
append disk_properties 'name'			$(basename ${disk_properties[device]} 2>/dev/null)
append disk_properties 'parts'			$(grep -c "${disk_properties[name]}[0-9]" /proc/partitions 2>/dev/null)
append disk_properties 'serial_long'	$(udevadm info --query=property --name ${disk_properties[device]} 2>/dev/null|grep -Po 'ID_SERIAL=\K.*')
append disk_properties 'serial'			$(udevadm info --query=property --name ${disk_properties[device]} 2>/dev/null|grep -Po 'ID_SERIAL_SHORT=\K.*')
append disk_properties 'smart_type'		"default"

disk_controller=$(udevadm info --query=property --name ${disk_properties[device]} | grep -Po 'DEVPATH.*0000:\K[^/]*')
append disk_properties 'controller'	"$(lspci | grep -Po "${disk_controller}[^:]*: \K.*")"

if [ "${disk_properties[parts]}" -gt 0 ]; then
	for part in $(seq 1 "${disk_properties[parts]}" ); do
		let "parts+=($(blockdev --getsize64 ${disk_properties[device]}${part} 2>/dev/null) / ${disk_properties[block_sz]})"
	done
	append disk_properties 'start_sector' $(( ${disk_properties[blocks]} - $parts ))
else
	append disk_properties 'start_sector' "0"
fi

#
# Disable read_stress if preclearing a SSD
#
eval $( lsblk -nbP --nodeps -o ROTA $theDisk )
if [ "$ROTA" -eq 0 ]; then 
	preclear_log "Disk ${theDisk} is a SSD, disabling head stress test." 
	read_stress=n
fi

#
# Test suitable device type for SMART, and disable it if not found.
#
disable_smart=y
for type in "" scsi ata auto sat,auto sat,12 usbsunplus usbcypress usbjmicron usbjmicron,x test "sat -T permissive" usbjmicron,p sat,16; do
	if [ -n "$type" ]; then
		type="-d $type"
	fi
	smartInfo=$(timeout -s 9 30 smartctl --all $type $theDisk 2>/dev/null)
	if [[ $smartInfo == *"START OF INFORMATION SECTION"* ]]; then

		smart_type=$type

		if [ -z "$type" ]; then
			type='default'
		fi

		append disk_properties 'smart_type' "$type"

		if [[ $smartInfo == *"Reallocated_Sector_Ct"* ]]; then
			disable_smart=n
		fi
		
		while read line ; do
			if [[ $line =~ Model\ Family:\ (.*) ]]; then
				append disk_properties 'family' "$(echo "${BASH_REMATCH[1]}"|xargs)"
			elif [[ $line =~ Device\ Model:\ (.*) ]]; then
				append disk_properties 'model' "$(echo "${BASH_REMATCH[1]}"|xargs)"
			elif [[ $line =~ User\ Capacity:\ (.*) ]]; then
				append disk_properties 'size_human' "$(echo "${BASH_REMATCH[1]}"|xargs)"
			elif [[ $line =~ Firmware\ Version:\ (.*) ]]; then
				append disk_properties 'firmware' "$(echo "${BASH_REMATCH[1]}"|xargs)"
			elif [[ $line =~ Vendor:\ (.*) ]]; then
				append disk_properties 'vendor' "$(echo "${BASH_REMATCH[1]}"|xargs)"
			elif [[ $line =~ Product:\ (.*) ]]; then
				append disk_properties 'product' "$(echo "${BASH_REMATCH[1]}"|xargs)"
			fi
		done < <(echo -n "$smartInfo")

		if [ -z "${disk_properties[model]}" ] && [ -n "${disk_properties[vendor]}" ] && [ -n "${disk_properties[product]}" ]; then
			append disk_properties 'model' "${disk_properties[vendor]} ${disk_properties[product]}"
		fi

		append disk_properties 'temp' "$(get_disk_temp $theDisk "$smart_type")"

		break
	fi
done

preclear_log "Disk size: ${disk_properties[size]}"
preclear_log "Disk blocks: ${disk_properties[blocks]}"
preclear_log "Blocks (512 bytes): ${disk_properties[blocks_512]}"
preclear_log "Block size: ${disk_properties[block_sz]}"
preclear_log "Start sector: ${disk_properties[start_sector]}"

#
# Used files
#
append all_files 'dir'				"/tmp/.preclear/${disk_properties[name]}"
append all_files 'dd_out'			"${all_files[dir]}/dd_output"
append all_files 'dd_exit'			"${all_files[dir]}/dd_exit_code"
append all_files 'op_exit'			"${all_files[dir]}/op_exit"
append all_files 'dd_stress'		"${all_files[dir]}/dd_stress"
append all_files 'blkpid'			"${all_files[dir]}/blkpid"
append all_files 'fifo'				"${all_files[dir]}/fifo"
append all_files 'pause'			"${all_files[dir]}/pause"
append all_files 'queued'			"${all_files[dir]}/queued"
append all_files 'verify_errors'	"${all_files[dir]}/verify_errors"
append all_files 'pid'				"${all_files[dir]}/pid"
append all_files 'stat'				"/tmp/preclear/preclear_stat_${disk_properties[name]}"
append all_files 'smart_prefix'		"${all_files[dir]}/smart_"
append all_files 'smart_final'		"${all_files[dir]}/smart_final"
append all_files 'smart_out'		"${all_files[dir]}/smart_out"
append all_files 'form_out'			"${all_files[dir]}/form_out"
append all_files 'resume_file'		"/boot/preclear_reports/${disk_properties[serial]}.resume"
append all_files 'resume_temp'		"/tmp/.preclear/${disk_properties[serial]}.resume"
append all_files 'wait'				"${all_files[dir]}/wait"

mkdir -p "${all_files[dir]}"

all_files[op_exit]=0

trap_with_arg "do_exit 0" INT TERM EXIT SIGKILL

if [ ! -p "${all_files[fifo]}" ]; then
	mkfifo "${all_files[fifo]}" || exit
fi

#
# Set terminal variables
#
if [ "$format_html" == "y" ]; then
	clearscreen=`tput clear`
	goto_top=`tput cup 0 1`
	screen_line_three=`tput cup 3 1`
	bold="&lt;b&gt;"
	norm="&lt;/b&gt;"
	ul="&lt;span style=\"text-decoration: underline;\"&gt;"
	noul="&lt;/span&gt;"
elif [ -x /usr/bin/tput ]; then
	clearscreen=`tput clear`
	goto_top=`tput cup 0 1`
	screen_line_three=`tput cup 3 1`
	bold=`tput smso`
	norm=`tput rmso`
	ul=`tput smul`
	noul=`tput rmul`
else
	clearscreen=`echo -n -e "\033[H\033[2J"`
	goto_top=`echo -n -e "\033[1;2H"`
	screen_line_three=`echo -n -e "\033[4;2H"`
	bold=`echo -n -e "\033[7m"`
	norm=`echo -n -e "\033[27m"`
	ul=`echo -n -e "\033[4m"`
	noul=`echo -n -e "\033[24m"`
fi

#
# disk name
#
if [ -n "${disk_properties[serial]}" ]; then
	diskName="${disk_properties[serial]}"
else
	diskName="${disk_properties[name]}"
fi

#
# set init timer or reset timer
#
time_elapsed main set $main_elapsed_time
time_elapsed cycle set $cycle_elapsed_time

######################################################
##													##
##				MAIN PROGRAM BLOCK					##
##													##
######################################################

#
# Verify if it's already running
#
if [ -f "${all_files[pid]}" ]; then
	pid=$(cat ${all_files[pid]})
	if [ -e "/proc/${pid}" ]; then
		echo "An instance of Preclear for disk '$theDisk' is already running."
		preclear_log "An instance of Preclear for disk '$theDisk' is already running."
		trap '' EXIT
		exit 1
	else
		echo "$script_pid" > ${all_files[pid]}
	fi
else
	echo "$script_pid" > ${all_files[pid]}
fi

if ! is_preclear_candidate "$theDisk"; then
	tput reset
	echo -e "\n${bold}The disk '$theDisk' is part of Unraid's array, or is assigned as a Pool device.${norm}"
	echo -e "\nPlease choose another one from below:\n"
	list_device_names
	echo -e "\n"
	preclear_log "Disk $theDisk is part of Unraid array. Aborted."
	do_exit 1
fi

echo -n "${disk_properties[name]}|NN|Starting...|${script_pid}" > ${all_files[stat]}

if [ -z "$current_op" ] || [ ! -f "${all_files[smart_prefix]}cycle_initial_start" ]; then
	#
	# Export initial SMART status
	#
	[ "$disable_smart" != "y" ] && save_smart_info $theDisk "$smart_type" "cycle_initial_start"
fi

#
# Add current SMART status to display_smart
#
[ "$disable_smart" != "y" ] && compare_smart "cycle_initial_start"
[ "$disable_smart" != "y" ] && output_smart $theDisk "$smart_type"

######################################################
##				VERIFY PRECLEAR STATUS				##
######################################################

if [ "$verify_disk_preclear" == "y" ]; then
	max_steps=1
	if [ "$verify_zeroed" == "y" ]; then
		max_steps=2
	fi

	#
	# update elapsed time
	#
	time_elapsed main && time_elapsed cycle 

	append display_title "${ul}Unraid Server: verifying Preclear State of disk ${noul} ${bold}${disk_properties['serial']}${norm}."
	append display_title "Verifying disk '${disk_properties['serial']}' for Unraid's Preclear State."

	display_status "Verifying Unraid's signature..." ""
	preclear_log "Verifying Unraid's signature..."
	echo -n "${disk_properties[name]}|NN|Verifying Unraid's signature...|$$" > ${all_files[stat]}

	sleep 1

	if verify_preclear_signature "$theDisk"; then
		append display_step "Verifying Unraid's signature:|${bold}SUCCESS${norm}"
		preclear_log "Unraid preclear signature is valid!"
		echo -n "${disk_properties[name]}|NN|Verifying Unraid's signature successful|$$" > ${all_files[stat]}
		display_status
	else
		append display_step "Verifying Unraid's signature:|${bold}FAIL${norm}"
		echo "${disk_properties[name]}|NY|Verifying Unraid's signature failed|$$" > ${all_files[stat]}
		preclear_log "fail - Unraid preclear signature invalid!"
		display_status
		echo -e "--> RESULT: FAIL! $theDisk DOESN'T have a valid Unraid signature!!!\n\n"
		if [ "$notify_channel" -gt 0 ]; then
			send_notify "FAIL! $diskName (${disk_properties[name]}) DOESN'T have a valid Unraid signature!!!" "$diskName (${disk_properties[name]}) DOESN'T have a valid Unraid signature!!!" "" "alert"
		fi
		do_exit 1
	fi
	
	#
	# update elapsed time
	#
	time_elapsed main && time_elapsed cycle 
	
	if [ "$max_steps" -eq "2" ]; then
		display_status "Verifying if disk is zeroed..." ""

		#
		# Check current operation if restoring a previous preclear instance
		#
		if is_current_op "zeroed"; then
			#
			# Loading restored position
			#
			if [ -n "$current_pos" ]; then
				start_bytes=$current_pos
				start_timer=$current_timer
				current_pos=0
			else
				start_bytes=0
				current_timer=0
			fi

			echo -n "${disk_properties[name]}|NN|Verifying if disk is zeroed...|${script_pid}" > ${all_files[stat]}

			if read_the_disk verify zeroed start_bytes start_timer preread_average preread_speed; then
				append display_step "Verifying if disk is zeroed:|${preread_average} ${bold}SUCCESS${norm}"
				preclear_log "The disk is zeroed!"
				echo -n "${disk_properties[name]}|NN|Verifying if disk is zeroed: SUCCESS|$$" > ${all_files[stat]}
				display_status

				sleep 10
			else
				append display_step "Verifying if disk is zeroed:|${bold}FAIL${norm}"
				preclear_log "fail - the disk is NOT zeroed!"
				echo "${disk_properties[name]}|NY|Verifying if disk is zeroed: FAIL|$$" > ${all_files[stat]}
				display_status
				echo -e "--> RESULT: FAIL! $diskName ($theDisk) IS NOT zeroed!!!\n\n"
				if [ "$notify_channel" -gt 0 ]; then
					send_notify "FAIL! $diskName (${disk_properties[name]}) IS NOT zeroed!!!" "FAIL! $diskName (${disk_properties[name]}) IS NOT zeroed!!!" "" "alert"
				fi

				do_exit 1
			fi
		fi
	fi

	#
	# update elapsed time
	#
	time_elapsed main && time_elapsed cycle 
	
	if [ "$notify_channel" -gt 0 ]; then
		send_notify "Disk $diskName (${disk_properties[name]}) is precleared!" "Disk $diskName (${disk_properties[name]}) is precleared!"
	fi
	echo -n "${disk_properties[name]}|NN|The disk is Precleared!|$$" > ${all_files[stat]}
	echo -e "--> RESULT: SUCCESS! Disk ${disk_properties['serial']} is precleared!\n\n"
	do_exit
fi

######################################################
##				WRITE PRECLEAR SIGNATURE			##
######################################################

#
# Prompt user if run from the command line
#
append display_title "${ul}Unraid Server Pre-Clear of disk${noul} ${bold}$theDisk${norm}"

if [ "$no_prompt" != "y" ]; then
	ask_preclear
	tput clear
fi

if [ "$write_disk_preclear" == "y" ]; then
	write_preclear_signature "$theDisk"
	display_status "Unraid's signature written!" ""
	preclear_log "Unraid's signature written!"
	echo -n "${disk_properties[name]}|NN|Unraid's signature written!|$$" > ${all_files[stat]}

	do_exit 0
fi

######################################################
##				PRECLEAR THE DISK					##
######################################################

if [ "$erase_disk" == "y" ]; then
	op_title="Erase"
	title_write="Erasing"
	write_op="erase"
else
	op_title="Preclear"
	title_write="Zeroing"
	write_op="zero"
fi

#
# Number of times to try the current operation
#
retries=2

for cycle in $(seq $cycles); do
	#
	# Continue to next cycle if restoring new-session
	#
	if [ -n "$current_op" ] && [ "$cycle" != "$current_cycle" ]; then
		preclear_log "skipping cycle ${cycle}."
		continue
	fi

	if [ -z "$current_pos" ]; then
		time_elapsed cycle set 0
	fi

	#
	# update elapsed time
	#
	time_elapsed main && time_elapsed cycle

	#
	# Reset canvas
	#
	unset display_title
	unset display_step && append display_step ""
	append display_title "${ul}Unraid Server ${op_title} of disk${noul} ${bold}${disk_properties['serial']}${norm}"

	append display_title "Cycle ${bold}${cycle}$norm of ${cycles}"

	#
	# Adjust the number of steps
	#
	if [ "$erase_disk" == "y" ]; then
		max_steps=4

		#
		# Disable pre-read and post-read if erasing
		#
		skip_preread="y"
		skip_postread="y"
	else
		max_steps=6
	fi

	if [ "$skip_preread" == "y" ]; then
		let max_steps-=1
	fi
	if [ "$skip_postread" == "y" ]; then
		let max_steps-=1
	fi
	if [ "$erase_preclear" != "y" ]; then
		let max_steps-=1
	fi

	#
	# Export initial SMART status
	#
	[ "$disable_smart" != "y" ] && save_smart_info $theDisk "$smart_type" "cycle_${cycle}_start"

	#
	# Do a preread if not skipped
	#
	if [ "$skip_preread" != "y" ]; then
		#
		# Check current operation if restoring a previous preclear instance
		#
		if is_current_op "preread"; then

			#
			# Loading restored position
			#
			if [ -n "$current_pos" ]; then
				start_bytes=$current_pos
				start_timer=$current_timer
				current_pos=0
			else
				start_bytes=0
				current_timer=0
			fi

			#
			# Updating display status 
			#
			display_status "Pre-Read in progress:..." ''

			#
			# Saving progress	
			#
			diskop+=([current_op]="preread" [current_pos]="$start_bytes" [current_timer]="$start_timer" )
			save_current_status


			for x in $(seq 1 $retries); do
				#
				# update elapsed time
				#
				time_elapsed main && time_elapsed cycle
				preclear_log "Pre-read: pre-read verification started $x of $retries retries..."
				
				read_the_disk no-verify preread start_bytes start_timer preread_average preread_speed
				ret_val=$?
				if [ "$ret_val" -eq 0 ]; then
					append display_step "Pre-read verification:|[${preread_average}] ${bold}SUCCESS${norm}"
					preclear_log "Pre-read: pre-read verification completed!"
					display_status
					break
				elif [ "$ret_val" -eq 2 -a "$x" -lt $retries ]; then
					preclear_log "dd process hung at ${start_bytes}, killing..."
					continue
				else
					append display_step "Pre-read verification:|${bold}FAIL${norm}"
					preclear_log "Pre-read: pre-read verification failed!"
					echo "${disk_properties[name]}|NY|Pre-read failed - Aborted|$$" > ${all_files[stat]}
					send_notify "FAIL! Pre-read $diskName (${disk_properties[name]}) failed." "Pre-read $diskName (${disk_properties[name]}) failed - Aborted" "" "alert"
					echo -e "--> FAIL: Result: Pre-Read failed.\n\n"
					log_smart $theDisk "$smart_type"	"Error:"
					display_status
					wait $!

					do_exit 1
				fi
			done
		else
			append display_step "Pre-read verification:|[${preread_average}] ${bold}SUCCESS${norm}"
			display_status
		fi
	fi

	#
	# update elapsed time
	#
	time_elapsed main && time_elapsed cycle 

	#
	# Erase the disk in erase-clear op
	#
	if [ "$erase_preclear" == "y" ]; then
		#
		# Check current operation if restoring a previous preclear instance
		#
		if is_current_op "erase"; then
			#
			# Loading restored position
			#
			if [ -n "$current_pos" ]; then
				start_bytes=$current_pos
				start_timer=$current_timer
				current_pos=""
			else
				start_bytes=0
				start_timer=0
			fi

			display_status "Erasing in progress..." ''
			diskop+=([current_op]="erase" [current_pos]="$start_bytes" [current_timer]="$start_timer" )
			save_current_status

			#
			# Erase the disk
			#
			for x in $(seq 1 $retries); do
				#
				# update elapsed time
				#
				time_elapsed main && time_elapsed cycle 
				preclear_log "Erasing: erasing the disk started $x of $retries retries..."

				write_the_disk erase start_bytes start_timer write_average write_speed
				ret_val=$?
				if [ "$ret_val" -eq 0 ]; then
					preclear_log "Erasing: erasing the disk completed!"
					append display_step "Erasing the disk:|[${write_average}] ${bold}SUCCESS${norm}"
					display_status
					break
				elif [ "$ret_val" -eq 2 -a "$x" -lt $retries ]; then
					preclear_log "dd process hung at ${start_bytes}, killing..."
					continue
				else
					append display_step "Erasing the disk:|${bold}FAIL${norm}"
					preclear_log "Erasing: erasing the disk failed!"
					echo "${disk_properties[name]}|NY|Erasing failed - Aborted|$$" > ${all_files[stat]}
					send_notify "FAIL! Erasing $diskName (${disk_properties[name]}) failed." "Erasing $diskName (${disk_properties[name]}) failed - Aborted" "" "alert"
					echo -e "--> FAIL: Result: Erasing the disk failed.\n\n"
					log_smart $theDisk "$smart_type"	"Error:"
					display_status
					wait $!

					do_exit 1
				fi
			done
		else
			append display_step "Erasing the disk:|[${write_average}] ${bold}SUCCESS${norm}"
			display_status
		fi
	fi

	#
	# update elapsed time
	#
	time_elapsed main && time_elapsed cycle 

	#
	# Erase/Zero the disk
	# Check current operation if restoring a previous preclear instance
	#
	if is_current_op "$write_op"; then
		#
		# Loading restored position
		#
		if [ -n "$current_pos" ]; then
			start_bytes=$current_pos
			start_timer=$current_timer
			current_pos=""
		else
			start_bytes=0
			start_timer=0
		fi

		display_status "${title_write} in progress..." ''
		diskop+=([current_op]="$write_op" [current_pos]="$start_bytes" [current_timer]="$start_timer" )
		save_current_status

		for x in $(seq 1 $retries); do
			#
			# update elapsed time
			#
			time_elapsed main && time_elapsed cycle 
			preclear_log "${title_write}: ${title_write,,} the disk started $x of $retries retries..."

			write_the_disk $write_op start_bytes start_timer write_average write_speed
			ret_val=$?
			if [ "$ret_val" -eq 0 ]; then
				append display_step "${title_write} the disk:|[${write_average}] ${bold}SUCCESS${norm}"
				preclear_log "${title_write}: ${title_write,,} the disk completed!"
				break
			elif [ "$ret_val" -eq 2 -a "$x" -lt $retries ]; then
				preclear_log "dd process hung at ${start_bytes}, killing..."
				continue
			else
				append display_step "${title_write} the disk:|${bold}FAIL${norm}"
				preclear_log "${title_write}: ${title_write,,} the disk failed!"
				echo "${disk_properties[name]}|NY|${title_write} the disk failed - Aborted|$$" > ${all_files[stat]}
				send_notify "FAIL! ${title_write} $diskName (${disk_properties[name]}) failed." "${title_write} $diskName (${disk_properties[name]}) failed - Aborted" "" "alert"
				echo -e "--> FAIL: Result: ${title_write} $diskName (${disk_properties[name]}) failed.\n\n"
				log_smart $theDisk "$smart_type" "Error:"
				display_status
				wait $!

				do_exit 1
			fi
		done
	else
		append display_step "${title_write} the disk:|[${write_average}] ${bold}SUCCESS${norm}"
		display_status
	fi

	#
	# Write the preclear signature
	#
	if [ "$erase_disk" != "y" ]; then
		#
		# Write Unraid's preclear signature to the disk
		# Check current operation if restoring a previous preclear instance
		#
		if is_current_op "write_preclear"; then
			#
			# update elapsed time
			#
			time_elapsed main && time_elapsed cycle 

			display_status "Writing Unraid's Preclear signature to the disk..." ''
			diskop+=([current_op]="write_preclear" [current_pos]="0" [current_timer]="0" )
			save_current_status
			echo -n "${disk_properties[name]}|NN|Writing Unraid's Preclear signature|$$" > ${all_files[stat]}
			if write_preclear_signature "$theDisk"; then
				append display_step "Writing Unraid's Preclear signature:|${bold}SUCCESS${norm}"
			else
				append display_step "Writing Unraid's Preclear signature:|${bold}FAILED${norm}"
			fi
			echo -n "${disk_properties[name]}|NN|Writing Unraid's Preclear signature finished|$$" > ${all_files[stat]}
		else
			append display_step "Writing Unraid's Preclear signature:|${bold}SUCCESS${norm}"
			display_status
		fi

		#
		# Verify Unraid's preclear signature in disk
		# Check current operation if restoring a previous preclear instance
		#
		if is_current_op "read_preclear_signature"; then
			display_status "Verifying Unraid's signature..." ""
			diskop+=([current_op]="read_preclear_signature" [current_pos]="0" [current_timer]="0" )
			save_current_status
			echo -n "${disk_properties[name]}|NN|Verifying Unraid's signature|$$" > ${all_files[stat]}
			preclear_log "Verifying Unraid's signature..."

			if verify_preclear_signature "$theDisk"; then
				append display_step "Verifying Unraid's Preclear signature:|${bold}SUCCESS${norm}"
				display_status
				preclear_log "Unraid preclear signature is valid!"
				echo -n "${disk_properties[name]}|NN|Unraid's signature is valid|$$" > ${all_files[stat]}
			else
				erase_preclear_signature "$theDisk"
				append display_step "Verifying Unraid's Preclear signature:|${bold}FAIL${norm}"
				preclear_log "Unraid preclear signature is invalid!"
				echo -e "--> FAIL: Unraid's Preclear signature is invalid. \n\n"
				echo "${disk_properties[name]}|NY|Unraid's signature failed - Aborted|$$" > ${all_files[stat]}
				send_notify "FAIL! Invalid Unraid's signature on $diskName (${disk_properties[name]})." "Invalid Unraid's signature on $diskName (${disk_properties[name]}) - Aborted" "" "alert"
				log_smart $theDisk "$smart_type" "Error:"
				display_status
				wait $!

				do_exit 1
			fi
		else
			append display_step "Verifying Unraid's Preclear signature:|${bold}SUCCESS${norm}"
			display_status
		fi

		#
		# update elapsed time
		#
		time_elapsed main && time_elapsed cycle
	fi

	#
	# Do a post-read if not skipped
	#
	if [ "$skip_postread" != "y" ]; then
		#
		# Check current operation if restoring a previous preclear instance
		#
		if is_current_op "postread"; then
			#
			# Loading restored position
			#
			if [ -n "$current_pos" ]; then
				start_bytes=$current_pos
				start_timer=$current_timer
				current_pos=""
			else
				start_bytes=0
				start_timer=0
			fi

			display_status "Post-Read in progress..." ""
			diskop+=([current_op]="postread" [current_pos]="$start_bytes" [current_timer]="$start_timer" )
			save_current_status
			for x in $(seq 1 $retries); do
				#
				# update elapsed time
				#
				time_elapsed main && time_elapsed cycle
				preclear_log "Post-Read: post-read verification started $x of $retries retries..."

				read_the_disk verify postread start_bytes start_timer postread_average postread_speed
				ret_val=$?
				if [ "$ret_val" -eq 0 ]; then
					append display_step "Post-Read verification:|[${postread_average}] ${bold}SUCCESS${norm}"
					preclear_log "Post-Read: post-read verification completed!"
					display_status
					echo "${disk_properties[name]}|NY|Post-Read verification successful|$$" > ${all_files[stat]}
					break
				elif [ "$ret_val" -eq 2 -a "$x" -lt $retries ]; then
					preclear_log "dd process hung at ${start_bytes}, killing..."
					continue
				else
					append display_step "Post-Read verification:|${bold}FAIL${norm}"
					preclear_log "Post-Read: post-read verification failed!"
					echo -e "--> FAIL: Post-Read verification failed. Your drive is not zeroed.\n\n"
					echo "${disk_properties[name]}|NY|Post-Read failed - Aborted|$$" > ${all_files[stat]}
					send_notify "FAIL! Post-Read $diskName (${disk_properties[name]}) failed." "Post-Read $diskName (${disk_properties[name]}) failed - Aborted" "" "alert"
					log_smart $theDisk "$smart_type" "Error:"
					display_status
					wait $!

					do_exit 1
				fi
			done
		fi
	fi

	#
	# update elapsed time
	#
	time_elapsed main && time_elapsed cycle 

	#
	# Export final SMART status for cycle
	#
	[ "$disable_smart" != "y" ] && save_smart_info $theDisk "$smart_type" "cycle_${cycle}_end"

	#
	# Compare start/end values
	#
	[ "$disable_smart" != "y" ] && compare_smart "cycle_${cycle}_start" "cycle_${cycle}_end" "CYCLE $cycle"

	#
	# Add current SMART status to display_smart
	#
	[ "$disable_smart" != "y" ] && output_smart $theDisk "$smart_type"

	display_status '' ''
	log_smart $theDisk "$smart_type" "Cycle $cycle"

	preclear_log "Cycle: elapsed time: $(time_elapsed cycle display)"

	#
	# Send end of the cycle notification
	#
	if [ "$notify_channel" -gt 0 ] && [ "$notify_freq" -ge 1 ]; then
		if [ $cycle -eq $cycles ]; then
			description="${op_title}: Disk $diskName (${disk_properties[name]}) preclear finished!"
			report_out="Disk ${disk_properties[name]} has successfully finished it's preclear!\\n\\n"
		else
			description="${op_title}: Disk $diskName (${disk_properties[name]}) PASSED cycle ${cycle}!"
			report_out="Disk ${disk_properties[name]} has successfully finished a preclear cycle!\\n\\n"
			report_out+="Finished Cycle $cycle of $cycles cycles.\\n"
		fi
		[ "$skip_preread" != "y" ] && report_out+="Last Cycle's Pre-Read Time: $(time_elapsed preread display).\\n"
		if [ "$erase_disk" == "y" ]; then
			report_out+="Last Cycle's Erasing Time:	$(time_elapsed erase display).\\n"
		else
			report_out+="Last Cycle's Zeroing Time:	$(time_elapsed zero display).\\n"
		fi
		[ "$skip_postread" != "y" ] && report_out+="Last Cycle's Post-Read Time: $(time_elapsed postread display).\\n"
		report_out+="Last Cycle's Elapsed Time: $(time_elapsed cycle display)\\n"
		report_out+="Disk Start Temperature: ${disk_properties[temp]}\n"
		report_out+="Disk Current Temperature: $(get_disk_temp $theDisk "$smart_type")\\n"
		[ "$cycle" -lt "$cycles" ] && report_out+="\\nStarting a new cycle.\\n"

		send_notify "$description" "$report_out"
	fi
done

#
# update elapsed time
#
time_elapsed main && time_elapsed cycle
preclear_log "Preclear: total elapsed time: $(time_elapsed main display)"

if [ "${all_files[op_exit]}" -eq 0 ]; then
	echo -n "${disk_properties[name]}|NN|${op_title} Finished Successfully!|$$" > ${all_files[stat]};
else
	echo -n "${disk_properties[name]}|NN|${op_title} Failed!|$$" > ${all_files[stat]};
fi

if [ "$disable_smart" != "y" ]; then
	echo -e "--> ATTENTION: Please take a look into the SMART report above for drive health issues.\n"
fi

if [ "${all_files[op_exit]}" -eq 0 ]; then
	echo -e "--> RESULT: ${op_title} Finished Successfully!\n\n"
else
	echo -e "--> RESULT: ${op_title} Failed!\n\n"
fi

#
# Saving report
#
report="${all_files[dir]}/report"

#
# Remove resume information
#
rm -f ${all_files[resume_file]}

tmux_window="preclear_disk_${disk_properties[serial]}"
if [ "$(tmux ls 2>/dev/null | grep -c "${tmux_window}")" -gt 0 ]; then
	tmux capture-pane -t "${tmux_window}" && tmux show-buffer >$report 2>&1
else
	display_status '' '' >$report
	if [ "$disable_smart" != "y" ]; then
		echo -e "--> ATTENTION: Please take a look into the SMART report above for drive health issues.\n" >>$report
	fi
	if [ "$exit_code" -eq 0 ]; then
		echo -e "--> RESULT: ${op_title} Finished Successfully!\n\n" >>$report
	else
		echo -e "--> RESULT: ${op_title} Failed!\n\n" >>$report
	fi
	report_tmux="preclear_disk_report_${disk_properties[name]}"

	tmux new-session -d -s "${report_tmux}"
	tmux send -t "${report_tmux}" "cat '$report'" ENTER

	sleep 1

	tmux capture-pane -t "${report_tmux}" && tmux show-buffer >$report 2>&1
	tmux kill-session -t "${report_tmux}" >/dev/null 2>&1
fi

#
# Remove empty lines
#
sed -i '/^$/{:a;N;s/\n$//;ta}' $report

#
# Save report to Flash disk
#
mkdir -p /boot/preclear_reports/
date_formatted=$(date "+%Y.%m.%d_%H.%M.%S")
file_name=$(echo "preclear_report_${disk_properties[serial]}_${date_formatted}.txt" | sed -e 's/[^A-Za-z0-9._-]/_/g')
todos < $report > "/boot/preclear_reports/${file_name}"

do_exit
