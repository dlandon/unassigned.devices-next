**Unassigned Devices Preclear - Next**

This plugin provides a utility to exercise and clear disk drives before adding them to the Unraid array, or to erase them prior to disposal.

Preclear operations can be performed using the built-in **Enhanced** preclear script or by using the **Docker** option with the binhex preclear container. The binhex Docker container must be installed and running in order to use the Docker option.

Originally developed and maintained by Dan Landon.

Project repository, documentation, and license information are available on GitHub.
