#!/bin/bash
#
#
# Copyright (C) 2022-2026 Dan Landon
# Licensed under the Unassigned Devices Preclear - Next Personal Use License v1.0
# See LICENSE.md for full license terms.
#
#
# Wrapper for the binhex preclear docker container
#

fast_postread="n"
noprompt="n"

progname="preclear_disk_docker.sh"
options=$*
docker="docker exec -i -t binhex-preclear bash preclear_binhex.sh "

#
# Latest docker version
#
ver="1.22"

while getopts ":tnc:WM:m:hvDNw:r:b:AalC:VRDd:zsSfJo:" opt; do
	case $opt in
		v ) echo $progname version: $ver
			exit 0
		;;
	esac
done

shift $(($OPTIND - 1))

if [ "$1" != "" ]; then
	#
	# This is the device to be precleared
	#
	devname=$(basename $1)

	#
	# Set status file as we are starting a preclear operation
	#
	echo -n "{$devname}|NN|Starting..." > /tmp/preclear/preclear_stat_${devname}

	#
	# Copy status file to docker so it is current
	#
	docker cp /tmp/preclear/preclear_stat_${devname} binhex-preclear:/tmp/preclear_stat_${devname}
fi

$docker $options 2>/dev/null

echo -n "{$devname}|NN|Finished check Progess for details!" > /tmp/preclear/preclear_stat_${devname}
